# Abstract do artigo: 41-ProtocolGuard Detecting Protocol Non-compliance Bugs via LLM-guided Static Analysis

**Arquivo original:** 

## Abstract

Abstract—Network protocol implementations are expected
to strictly comply with their specifications to ensure reliable
and secure communications. However, the inherent ambiguity
of natural-language specifications often leads to developers’
misinterpretations, causing protocol implementations to deviate
from standard behaviors. These deviations result in subtle noncompliance bugs that can cause interoperability issues and critical
security vulnerabilities. Unlike memory corruption bugs, these
bugs typically do not exhibit explicit error behaviors, resulting
in existing bug oracles being insufficient to thoroughly detect
them. Moreover, existing works require heavy manual effort to
verify findings and analyze root causes, severely limiting their
scalability in practice.
In this paper, we present ProtocolGuard, a novel framework
that systematically detects non-compliance bugs by combining
LLM-guided static analysis with fuzzing-based dynamic verification. ProtocolGuard first extracts normative rules from protocol
specifications using a hybrid method, and performs LLM-guided
program slicing to extract code slices relevant to each rule. It then
leverages LLMs to detect semantic inconsistencies between these
rules and code logic, and dynamically verify whether these bugs
can be triggered. To facilitate bug verification, ProtocolGuard
first uses LLMs to automatically generate assertion statements
and instrument the code to turn silent inconsistencies into
observable assertion failures. Then, it produces initial test cases
that are more likely to trigger the bug with the help of LLMs
for dynamic verification. Lastly, ProtocolGuard dynamically tests
the instrumented code to confirm bug identification and generate
proof-of-concept test cases. We implemented a prototype of
ProtocolGuard and evaluated it on 11 widely-used protocol
implementations. ProtocolGuard successfully discovered 158 noncompliance bugs with high accuracy, 70 of which have been confirmed, and the majority of which can be converted into assertions
and dynamically verified. The comparison with existing state-ofthe-art tools demonstrates that ProtocolGuard outperforms them

---
*Extraído em 2026-06-12 23:54:33*
