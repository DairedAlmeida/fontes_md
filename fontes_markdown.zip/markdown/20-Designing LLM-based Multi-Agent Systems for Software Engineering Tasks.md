                                        Designing LLM-based Multi-Agent Systems for Software
                                        Engineering Tasks: Quality Attributes, Design Patterns and
                                        Rationale
                                        YANGXIAO CAI, School of Computer Science, Wuhan University, China
                                        RUIYIN LI, School of Computer Science, Wuhan University, China
                                        PENG LIANG, School of Computer Science, Wuhan University, China
                                        MOJTABA SHAHIN, School of Computing Technologies, RMIT University, Australia
                                        ZENGYANG LI, School of Computer Science, Central China Normal University, China

arXiv:2511.08475v2 \[cs.SE\] 5 Dec 2025

                                        As the complexity of Software Engineering (SE) tasks continues to escalate, Multi-Agent Systems (MASs)
                                        have emerged as a focal point of research and practice due to their autonomy and scalability. Furthermore,
                                        through leveraging the reasoning and planning capabilities of Large Language Models (LLMs), the application
                                        of LLM-based MASs in the field of SE is garnering increasing attention. However, there is no dedicated
                                        study that systematically explores the design of LLM-based MASs, including the Quality Attributes (QAs) on
                                        which designers mainly focus, the design patterns used by designers, and the rationale guiding the design of
                                        LLM-based MASs for SE tasks. To this end, we conducted a study to identify the QAs that LLM-based MASs for
                                        SE tasks focus on, the design patterns used in the MASs, and the design rationale for the MASs. We collected
                                        94 papers on LLM-based MASs for SE tasks as the source. Our study shows that: (1) Code Generation is the
                                        most common SE task solved by LLM-based MASs among ten identified SE tasks, (2) Functional Suitability
                                        is the QA on which designers of LLM-based MASs pay the most attention, (3) Role-Based Cooperation is the
                                        design pattern most frequently employed among 16 patterns used to construct LLM-based MASs, and (4)
                                        Improving the Quality of Generated Code is the most common rationale behind the design of LLM-based MASs.
                                        Based on the study results, we presented the implications for the design of LLM-based MASs to support SE
                                        tasks.
                                        CCS Concepts: • Software and its engineering → Designing software.
                                        Additional Key Words and Phrases: Multi-Agent, Software Design, Large Language Model, Software Engineer-
                                        ing Task
                                        ACM Reference Format:
                                        Yangxiao Cai, Ruiyin Li, Peng Liang, Mojtaba Shahin, and Zengyang Li. 2025. Designing LLM-based Multi-
                                        Agent Systems for Software Engineering Tasks: Quality Attributes, Design Patterns and Rationale. ACM Trans.
                                        Softw. Eng. Methodol. 0, 0, Article 0 ( 2025), 35 pages. https://doi.org/XXXXXXX.XXXXXXX

                                        1    Introduction
                                        While traditional Multi-Agent Systems (MASs) face limitations in handling complex decision-
                                        making tasks [10], Large Language Models (LLMs) can enhance the reasoning [15] and planning
                                        Authors’ Contact Information: Yangxiao Cai, yangxiaocai@whu.edu.cn, School of Computer Science, Wuhan University,
                                        Wuhan, China; Ruiyin Li, ryli_cs@whu.edu.cn, School of Computer Science, Wuhan University, Wuhan, China; Peng Liang,
                                        liangp@whu.edu.cn, School of Computer Science, Wuhan University, Wuhan, China; Mojtaba Shahin, School of Computing
                                        Technologies, RMIT University, Australia, mojtaba.shahin@rmit.edu.au; Zengyang Li, School of Computer Science, Central
                                        China Normal University, China, zengyangli@ccnu.edu.cn.

                                        Permission to make digital or hard copies of all or part of this work for personal or classroom use is granted without fee
                                        provided that copies are not made or distributed for profit or commercial advantage and that copies bear this notice and the
                                        full citation on the first page. Copyrights for components of this work owned by others than the author(s) must be honored.
                                        Abstracting with credit is permitted. To copy otherwise, or republish, to post on servers or to redistribute to lists, requires
                                        prior specific permission and/or a fee. Request permissions from permissions@acm.org.
                                        © 2025 Copyright held by the owner/author(s). Publication rights licensed to ACM.
                                        ACM 1557-7392/2025/0-ART0
                                        https://doi.org/XXXXXXX.XXXXXXX


                                                                                 ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:2 Cai et al.

capabilities of MASs \[28\]. LLM-based MASs consist of multiple
autonomous agents that collaborate through communication and
responsibility specialization to tackle complex tasks given by users and
simulate problem-solving environments \[11\]. LLM-based MASs have
demonstrated significant potential in addressing Software Engineering
(SE) tasks and have become a focal point of research and practice in SE
\[13\]. Many researchers have designed LLM-based MASs to address
specific SE tasks \[13\]. For example, Hong et al. \[14\] proposed an
LLM-based MAS named MetaGPT, which is capable of automatically
developing an entire software system. Jin et al. \[17\] proposed an
LLM-based MAS named MARE (Multi-Agents Collaboration Framework for
Requirements Engineering), which could complete the process of
requirements engineering. Effective design is paramount to the success
of LLM-based MASs, as it directly shapes key quality attributes such as
reliability, maintainability, scalability, and safety, and profoundly
influences collaborative behaviors of agents (e.g., volunteering,
conformity, and destructive actions), which in turn affect overall
task-solving efficiency among agents in MASs \[8\]. Therefore, a
principled understanding of design rationale is essential not only for
constructing high-quality MASs but also for navigating trade-offs among
competing quality attributes (e.g., correctness vs. efficiency) \[18\].
Despite the increasing interest and adoption of LLM-based MASs for
various SE tasks, no existing study has systematically investigated the
specific Quality Attributes (QAs), design patterns, and underlying
design rationale that inform their construction. To address this gap,
our goal is to identify QAs and design patterns that practitioners
prioritize when building LLM-based MASs, thereby highlighting best
practices and informing future system designs. Moreover, explicitly
articulating the design rationale is critical for transparency of design
decision-making and design knowledge transfer. In this study, we
empirically investigate quality-driven design choices in SE-focused
LLM-based MASs. Our findings offer actionable guidance for practitioners
and contribute a deeper, evidence- based understanding of how such
systems are designed to be more robust, reliable, and effective. Our
study results show that: (1) Code Generation is the most common SE task
solved by LLM- based MASs among ten identified SE tasks, (2) Functional
Suitability is the QA most frequently prioritized by the designers of
MASs, (3) Role-Based Cooperation is the most commonly adopted design
pattern among all 16 patterns we identified for MASs construction, and
(4) Improving the Quality of Generated Code is the predominant rationale
behind the design of LLM-based MASs. The analysis of QAs, design
patterns, and design rationale was conducted specifically in the context
of how LLM-based MASs are designed to complete these SE tasks, which
ensures a more coherent logical flow from problem context to
architectural analysis. The main contributions of this work:

      • We collected a comprehensive set of SE tasks solved by LLM-based MASs. Moreover, we
        identified the key QAs that received the most attention from designers.
      • We identified design patterns commonly used by designers for constructing LLM-based
        MASs to address specific SE tasks, and extracted underlying design rationale guiding their
        development.
      • We established mapping relationships among SE tasks addressed by LLM-based MASs, QAs
        considered by designers, design patterns utilized in constructing LLM-based MASs for SE
        tasks, along with the design rationale.

The rest of this paper is structured as follows: Section 2 reviews the
related work. Section 3 presents the Research Questions (RQs) and the
research process conducted in this study. Section 4 presents the results
of this study. Section 5 interprets the study results and discusses
their implica- tions. Section 6 outlines the potential threats to
validity, and Section 7 concludes this work with future research
directions.

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:3

2 Related Work In this section, we first review LLM-based MASs,
specifically constructed to address SE tasks (Section 2.1), and
introduce studies that explore the characteristics of LLM-based MASs
(Section 2.2). Then, we present the recent literature surveys that focus
on LLM-based MASs (Section 2.3). We compare recent studies with our work
to highlight the research gap (Section 2.4).

2.1 LLM-based MASs for SE Tasks As LLMs continue to evolve at a rapid
pace, SE researchers and practitioners are increasingly eager to employ
the reasoning and decision-making abilities of LLMs to support SE tasks.
To better exploit the potential of LLMs in complex, multi-step SE
workflows (particularly those requiring coordination), LLM-based MASs
have been designed to address SE tasks, such as requirements
engineering, code generation, and fault localization. Arora et al. \[2\]
developed an LLM-based MAS aimed at enhancing the efficiency and
accuracy of requirements engineering tasks. This MAS reveals the
significant potential of applying LLMs to requirements elicitation,
analysis, specification, and validation. Li et al. \[21\] proposed MAAD,
a knowledge-driven MAS specifically built for automated architecture
design. MAAD assigns the architecture design task to four role-dedicated
agents with external knowledge bases, and the four agents
collaboratively generate architecture design by decomposing a given
Software Requirements Specifications (SRS) into corresponding artifacts.
Dong et al. \[9\] designed an LLM-based MAS based on a
self-collaboration framework to achieve high-quality code generation.
Their framework enables the MAS to solve complex repository-level tasks
that are not readily solved by a single LLM agent. Pan et al. \[24\]
proposed a novel optimization pipeline for LLM-based MASs based on
self-generated textual feedback, named CodeCoR, which has a multi-phase
workflow and iterative code repair progress. Its self-reflective
mechanism can evaluate and refine the outputs of each agent. Some
LLM-based MASs are also designed to complete specific SE tasks, such as
code translation and release management. Yuan et al. \[35\] designed an
LLM- based MAS named TRANSAGENT to improve code translation accuracy
through the collaboration of four specialized agents, which could be
used in software migration, system refactoring, and cross-platform
development. By aligning the execution behavior of the source and target
programs, TRANSAGENT effectively localizes faulty code blocks, thereby
narrowing the error-fixing scope and reducing debugging complexity.
Besides MASs tailored for specific SE tasks, an increasing number of
studies have constructed LLM-based MASs to support holistic SE tasks
such as end-to-end development and end-to-end maintenance. Qian et
al. \[25\] developed an LLM-based MAS named ChatDev, which assigns
multiple agents different roles in the software development lifecycle,
such as design, coding, and testing to develop a complete software
system.

2.2 Characteristics on LLM-based MASs With the gradual adoption of
LLM-based MASs in various SE tasks, many researchers have con- ducted
empirical studies to examine their characteristics, including system
architectures, inter-agent coordination mechanisms, and evaluation
protocols. Shen et al. \[27\] designed a two-stage textual feedback
optimization pipeline for LLM-based MASs focusing on software
development. In the first stage, the MAS leverages its own failure
explanations to identify underperforming agents. In the second stage,
targeted prompt adjustments are applied to individual agents based on
these explanations. The two-stage textual feedback pipeline provides a
practical architecture pattern for runtime diagnosis and agent-level
adaptation to LLM-based MASs for software development. Cemri et
al. \[6\] selected seven open-source LLM-based MASs, and collected over
200 dialogues and execution traces, which contain the complete
interaction records among all agents within the same MAS. Their analysis
results show that MAS failures arise not only from limitations of the
integrated

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:4 Cai et al.

LLMs but also from the design of MASs. They finally proposed a two-tier
taxonomy of failure modes in LLM-based MASs. Sarkar et al. \[26\]
explored the enhancement of communication reliability and scalability in
LLM-based MASs through the application of classical design patterns,
with a specific focus on the Model Context Protocol (MCP). The study
delved into the transition from single-agent to MASs, identifying key
communication challenges such as architectural ambiguity, coordination
misalignment, and task validation. Bouzenia et al. \[4\] conducted a
focused empirical analysis of thought-action-result workflows produced
by three contemporary LLM-based MASs. They focused on a manually
annotated corpus of 120 sampled workflows unified into canonical
sequences. The authors parsed heterogeneous logs, computed
trajectory-level metrics, mined frequent action sub- sequences, and
performed open coding of semantic relations among thoughts, actions, and
results. They concluded that detecting trajectory "smells" and enforcing
alignment checks or self-critique loops are promising directions to
improve agent robustness.

2.3 Surveys on LLM-based MASs Researchers have also conducted surveys
focusing on the architecture, capabilities, and limitations of LLM-based
MASs. Liu et al. \[23\] conducted a systematic literature review to
investigate the architectural challenges of designing foundation
model-based agents. Based on the review of 57 selected academic and
industrial sources between 2023 and 2024, the authors identified 18
reusable architectural patterns that support key agent capabilities such
as goal-seeking, planning, explainability, and accountability. These
patterns were synthesized into a structured design pattern catalog,
accompanied by a decision model to guide practitioners in selecting
appropriate patterns. Their study provides holistic design knowledge for
building reliable and scalable LLM-based MASs, contributing to both
research and practice in MAS architectures. Liu et al. \[22\] collected
106 papers before July 1st, 2024, using keyword-based searches and
snowballing from DBLP and other sources to explore what SE tasks can be
solved by LLM-based agent systems and the architectural components of
these systems. They categorized the works from both SE and agent
perspectives, covering tasks like requirements engineering, code
generation, testing, and debugging, as well as agent architectures such
as planning, memory, perception, and multi-agent coordination. Their
survey identified the capabilities, design patterns, and open research
challenges on LLM-based agent frameworks, offering valuable insights for
the design and application of LLM-based agents in SE. Chen et al. \[7\]
collected 125 papers published in top artificial intelligence
conferences and some unpublished yet valuable papers from arXiv in 2023
and 2024 to provide a comprehensive and up- to-date review of LLM-based
MASs. Their research categorized LLM-MAS applications into three
domains: solving complex tasks, simulating specific scenarios, and
evaluating generative agents. For each category, the survey discussed
representative systems, open-source resources, and evaluation
benchmarks. They also identified key challenges for the development of
LLM-based MASs, including hallucinations, limited long-context handling,
communication inefficiency, and a lack of objective evaluation metrics.
Yan et al. \[33\] provided a comprehensive review of LLM-based MASs by
focusing on the pivotal role of communication between agents. They
collected 68 papers before May 2025, including domain-specific research
papers and technical papers on communication protocols, agent behaviors,
and applications of LLM-based MASs in different areas. They introduced a
structured framework that integrates system-level communication with
system-internal communication to explore how agents interact, negotiate,
and achieve collective intelligence. Yu et al. \[34\] conducted a
systematic survey to investigate trustworthiness in LLM-based agents,
selecting 175 representative papers from top AI, security, and NLP
conferences and journals published since 2023. The authors introduced a
unified conceptual framework that categorizes threats and
countermeasures along two dimensions: internal and external
trustworthiness. He et al. \[13\] investigated 71 papers before November
14th, 2024, indexed in DBLP, and conducted a systematic literature
review complemented

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:5

by empirical case studies. They assessed and characterized the current
state and potential of LLM- based MASs for SE tasks, and proposed a
comprehensive research agenda aimed at strengthening individual agent
competence and optimizing inter-agent collaboration.

2.4 Conclusive Summary With the advances in the reasoning and
decision-making capabilities of LLMs, plenty of LLM-based MASs have been
designed to solve specific SE tasks. These MASs have been applied to
various SE activities, such as requirements analysis, architecture
design, code generation, and testing, demonstrating strong potential in
simulating collaborative workflows, enabling role specialization, and
enhancing automation and decision-making in software development. In
addition, existing studies and surveys have investigated the design
principles, agent architectures, communication mechanisms, and
evaluation strategies of LLM-based MASs. These efforts provide
foundational insights for constructing more robust and generalizable MAS
frameworks for SE applications. Although various studies have been
conducted to investigate LLM-based MASs, no dedicated research has
explored how to design an effective LLM-based MAS for a specific SE
task, which QAs should be considered, which design patterns can be
employed, and the underlying rationale guiding the design of LLM-based
MASs for SE tasks. Our study aims to support designers in balancing QAs,
selecting suitable design patterns, and explaining the design with
underlying rationale when building LLM-based MASs for various SE tasks,
which act as guidance for the construction of reliable, maintainable,
scalable, and safe LLM-based MASs.

3 Study Design In this section, we present the goal and Research
Questions (RQs) (Section 3.1) formulated to investigate the design of
LLM-based MASs for SE tasks. Besides, we describe the process and
criteria for data collection (Section 3.2) and detail the procedures for
data extraction (Section 3.3) and data analysis (Section 3.4).

3.1 Research Questions The goal of this study is to understand how
LLM-based MASs for SE tasks are designed. To this end, we formulated
four Research Questions (RQs): the SE tasks addressed by LLM-based MASs
(RQ1), the quality attributes prioritized by their designers (RQ2), and
the design patterns (RQ3) and rationale (RQ4) guiding their
construction. The four RQs are addressed by following the research
process illustrated in Figure 1.

                                                                              [D1~D4: Data Items]
           RQ1      SE Tasks                                                  Data Extraction
                                                                                                        ISO/IEC25010:2023      Open Coding
                                    Model-based   Multi-agent Software Task
           RQ2 Quality Attributes                                                SE Tasks                                            &
                                      Agents       System       Solution                                                    Constant Comparison
                                                                                  Quality
                                                                                 Attributes             Related Research
           RQ3   Design Patterns
                                                                                  Design
                                                                                 Patterns 94 Research
                                                                                  Design     Papers
           RQ4 Design Rationale
                                                                                 Rationale                         Hybrid Approach
                                           Reviews        arXiv

       Research Questions                   Data Collection                     Data Extraction                  Data Analysis

            Phase 1                               Phase 2                             Phase 3                         Phase 4



                                          Fig. 1. Overview of the research process


                                            ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:6 Cai et al.

       RQ1: What SE tasks are addressed by LLM-based MASs?

Rationale: As mentioned in Section 1, LLM-based MASs have demonstrated
significant potential in addressing various SE tasks. The answer to this
RQ can provide an overall view of the SE tasks addressed by LLM-based
MASs, thereby informing and guiding the direction of future research in
this emerging domain.

       RQ2: What quality attributes are considered when designing LLM-based MASs for
       SE tasks?

Rationale: Through this RQ, we aim to explore the quality attributes
that designers of LLM-based MASs for SE tasks prioritize, thereby
identifying the specific considerations that should be handled when
designing such systems for different SE tasks.

       RQ3: What design patterns are employed for building LLM-based MASs for SE
       tasks?

Rationale: Design patterns are reusable solutions that help balance the
quality attributes of MASs. In this study, we identified the design
patterns employed in building LLM-based MASs. By analyzing these
patterns, we aim to uncover effective approaches that can be adopted
when designing LLM-based MASs for SE tasks.

       RQ4: What is the design rationale for constructing LLM-based MASs for SE tasks?

Rationale: This RQ aims to understand the rationale behind designing
LLM-based MASs for SE tasks. By examining the design rationale, we seek
to reveal the guiding principles that designers can follow when
constructing LLM-based MASs to support various SE tasks.

3.2 Data Collection To obtain reliable insights into the design of
LLM-based MASs for SE tasks, we relied on academic papers as our main
data source. We started our data collection from the papers listed in
the two recent surveys by Liu et al. \[22\] and Wang et al. \[32\],
which collect and review LLM-based agent systems for SE tasks. We
obtained 118 papers from the survey of Liu et al. \[22\] and 115 papers
from the survey of Wang et al. \[32\]. To collect relevant papers as
comprehensively as possible, we additionally performed a keyword search
in the SE category on arXiv \[31\] using the query ("large language
model" AND "agent"), retrieving papers published before 30 September
2024, when we started this study. We retained 194 papers from arXiv.
After excluding duplicate papers from the three sources (i.e., \[22\],
\[32\], and arXiv), we obtained a total of 236 papers. We set the
following criteria to select relevant papers for our research: (1) The
paper must introduce at least one multi-agent system. (2) The agent(s)
introduced in the paper must leverage LLMs to implement their functions.
(3) The agent(s) introduced in the paper must have addressed at least
one SE task. We finally obtained 94 papers (listed in Table 7 in the
Appendix: Included Studies) that served as the source for data
extraction and analysis. The information from these selected papers was
recorded in an MS file \[5\].

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:7

3.3 Data Extraction To answer the four RQs presented in Section 3.1, we
defined a set of data items for data extraction, as shown in Table 1.
The data items D1∼D4 are respectively used to extract information
regarding SE tasks, QAs, design patterns, and design rationale,
corresponding to RQ1∼RQ4. These data items can be extracted from any
section of the collected papers in our dataset, including the title,
abstract, and main text. To ensure the completeness of the extracted
information, we manually performed data extraction from the included
papers.

                         Table 1. Data items extracted and their corresponding RQs

\# Data Item Description RQ D1 SE Task The SE task addressed by the
LLM-based MAS proposed in a paper. RQ1 D2 Quality Attribute The quality
attribute(s) considered in the design of the LLM-based MAS proposed in a
paper. RQ2 D3 Design Pattern The design pattern(s) employed in the
design of the LLM-based MAS proposed in a paper. RQ3 D4 Design Rationale
The design rationale that supports the design of the LLM-based MAS
proposed in a paper. RQ4

3.3.1 Pilot Data Extraction. To examine whether all data items could be
correctly extracted from the papers included in our dataset, we
conducted a pilot data extraction. We randomly selected five papers from
our dataset to perform pilot data extraction. The first author carried
out the extraction independently and discussed the extraction results
with the second and third authors. The results indicated that the four
data items listed in Table 1 can be extracted from our dataset. Based on
the results obtained from the pilot data extraction, we reached a
consensus and established the following rules for the formal data
extraction: (1) Only one SE Task can be extracted from a paper. If
multiple SE tasks are addressed by the LLM-based MAS, we record the main
SE task. (2) If multiple Quality Attributes are considered in the design
of the LLM-based MAS in a paper, we record all the Quality Attributes.
(3) If multiple Design Patterns are employed in the design of the
LLM-based MAS in a paper, we record all the Design Patterns. (4) If more
than one Design Rationale supports the design of the LLM-based MAS in a
paper, we record all the Design Rationale. 3.3.2 Formal Data Extraction.
After the pilot extraction, the first author independently conducted the
formal data extraction based on the data items listed in Table 1. If any
issues arose during the formal data extraction process, the first author
discussed these issues with the second and third authors to resolve the
problems. Once the first author completed the formal data extraction,
the results of the extraction were reviewed by the second and third
authors. Any inconsistencies were discussed among the first three
authors to reach a consensus. The three authors conducted multiple
rounds of reviews and revisions on the formal data extraction results to
obtain the final results. The formal data extraction results were
recorded in an MS Excel file and a MAXQDA file, which are publicly
available in our dataset \[5\].

3.4 Data Analysis After completing the data extraction, we conducted
data analysis to answer the four RQs in Section 3.1. We categorized the
SE tasks to answer RQ1 based on the software development lifecycle. To
answer RQ2, we categorized the considered quality attributes based on
ISO/IEC 25010:2023 \[16\]. To address RQ3, we used a hybrid approach to
classify the employed design patterns. We first categorized the design
patterns according to the category of architecture patterns for
LLM-based agents provided by Liu et al. \[23\]. When no matching
architecture pattern existed in that category, we subsequently employed
the Open Coding and Constant Comparison methods for categorization,
which are commonly used for qualitative data analysis in SE studies
\[30\]. Additionally, we also

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:8 Cai et al.

employed the Open Coding and Constant Comparison methods to get the
category of design rationale for answering RQ4. The steps we conducted
for data analysis are as follows: (1) The first author read the full
text of each paper in the dataset and identified the SE task the
LLM-based MAS aiming to address, the quality attributes considered in
the design of the LLM-based MAS, the design patterns employed in the
design of the LLM-based MAS, and the design rationale supporting the
design of the LLM-based MAS for SE tasks. (2) For the data items that
used the Open Coding and Constant Comparison methods, the first author
compared the descriptions to identify their similarities and
differences, then grouped similar descriptions following a bottom-up
approach, which led to the formation of higher-level categories. (3)
Whenever uncertainties about the code descriptions arose, the first
author discussed these uncertainties with the second and third authors
to reach a consensus. Due to the iterative nature of Constant
Comparison, the final results were determined after several rounds of
refinement and revision. (4) The second and third authors reviewed and
verified the preliminary analysis results. If any questions or
discrepancies arose, the first three authors discussed them to reach a
final consensus and resolve the conflicts.

4 Results In this section, we report the results of the four RQs
formulated in Section 3.1. For the taxonomies of SE Task, Design
Pattern, and Design Rationale, we provide a one-tier categorization. For
the taxonomy of Quality Attribute, we provide a two-tier categorization
according to ISO/IEC 25010:2023 \[16\].

4.1 Category of SE Tasks Addressed (RQ1) Figure 2 presents the taxonomy
of SE tasks extracted from our dataset \[5\]. It can be observed that
Code Generation (47.9%) is the most common SE task that LLM-based MASs
address. In addition, LLM-based MASs are also used to solve Fault
Localization (9.6%), End-to-End Software Maintenance (8.5%), and Program
Repair (8.5%). The remaining LLM-based MASs are used to facilitate
End-to-End Software Development (7.4%), Code Review (6.4%), Software
Testing (6.4%), Requirements Engineering (3.2%), Code Translation
(1.1%), and Release Management (1.1%). It should be noted that SE tasks
were directly extracted from the included studies, and these extracted
SE tasks can exhibit compositional relationships, for example, Fault
Localization and Program Repair constitute parts of End-to-End Software
Maintenance.

                              3.2%
                       6.4%
                                                                   Code Generation (45, 47.9%)
                6.4%                                               Fault Localization (9, 9.6%)
                                                                   End-to-End Software Maintenance (8, 8.5%)
            7.4%                                                   Program Repair (8, 8.5%)
                                                 47.9%             End-to-End Software Development (7, 7.4%)
                                                                   Code Review (6, 6.4%)
            8.5%                                                   Software Testing (6, 6.4%)
                                                                   Requirements Engineering (3, 3.2%)
                                                                   Code Translation (1, 1.1%)
                   8.5%                                            Release Management (1, 1.1%)
                               9.6%



                              Fig. 2. Taxonomy of SE Tasks addressed by LLM-based MASs

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:9

                                      Table 2. SE Tasks addressed by LLM-based MASs

         SE Tasks           Example                                                  Count(%)     Studies
                                                                                                  [S1], [S7], [S9], [S11], [S12], [S15], [S20], [S23],
                            To enable LLMs to handle these real-world repo-level                  [S24], [S27], [S29], [S33], [S34], [S36], [S37], [S38],
                            code generation, we present CODEAGENT, a novel                        [S40], [S41], [S42], [S45], [S46], [S51], [S52], [S53],
     Code Generation                                                                 45 (47.9%)
                            LLM-based agent framework that employs external                       [S54], [S58], [S61], [S62], [S63], [S64], [S67], [S68],
                            tools for effective repo-level code generation. [S12]                 [S71], [S73], [S74], [S76], [S78], [S79], [S82], [S83],
                                                                                                  [S84], [S86], [S87], [S92], [S94]
                            To address the limitation, this paper presents
                                                                                                  [S4], [S16], [S19], [S25], [S26], [S35], [S49], [S75],
     Fault Localization     AGENTFL, a multi-agent system based on ChatGPT            9 (9.6%)
                                                                                                  [S77]
                            for automated fault localization. [S4]
                            In this paper, we introduce MarsCode Agent , a novel
                            framework that leverages LLMs to automatically

End-to-End Software identify and repair bugs in software code. MarsCode
8 (8.5%) \[S2\], \[S3\], \[S28\], \[S31\], \[S32\], \[S39\], \[S59\],
\[S60\] Maintenance Agent combines the power of LLMs with advanced code
analysis techniques to accurately localize faults and generate patches.
\[S31\] In this paper, we propose an automated approach for Program
Repair solving GitHub issues to autonomously achieve 8 (8.5%) \[S8\],
\[S14\], \[S17\], \[S50\], \[S69\], \[S70\], \[S89\], \[S90\] program
improvement. \[S8\] MetaGPT encodes Standardized Operating Procedures
(SOPs) into prompt sequences for more End-to-End Software streamlined
workflows, thus allowing agents with 7 (7.4%) \[S5\], \[S13\], \[S21\],
\[S57\], \[S65\], \[S81\], \[S93\] Development human-like domain
expertise to verify intermediate results and reduce errors. \[S81\] In
this paper, we present a novel approach to improving software quality
and efficiency through a Code Review 6 (6.4%) \[S6\], \[S10\], \[S44\],
\[S55\], \[S72\], \[S88\] Large Language Model (LLM)-based model
designed to review code and identify potential issues. \[S6\] The
proposed system mainly consists of three LLM-based agents responsible
for action planning, Software Testing state checking and parameter
selecting, respectively, 6 (6.4%) \[S43\], \[S47\], \[S66\], \[S80\],
\[S85\], \[S91\] and two additional modules for state sensing and case
rewriting. \[S43\] These agents engage in product experience scenarios,
through explaining their actions, observations, and Requirements
Engineering challenges. Subsequent agent interviews and 3 (3.2%)
\[S18\], \[S30\], \[S48\] analysis uncover valuable user needs,
including latent ones. \[S18\] In this work, we propose a novel
LLM-based multi-agent system TRANSAGENT, which enhances Code Translation
LLM-based code translation by fixing the syntax 1 (1.1%) \[S56\] errors
and semantic errors with the synergy between four LLM-based agents.
\[S56\] GoNoGo represents an efficient and user-friendly LLM-based
solution currently employed in our Release Management 1 (1.1%) \[S22\]
industrial partner's company to assist with software release
decision-making \[S22\]

Code Generation (45, 47.9%) denotes the SE task of automatically
producing executable source code through coordinated LLM-based MASs.
Because coding follows well-defined structures and rules, and large
public datasets that support the fine-tuning and evaluation of models
for code generation (e.g., MBPP \[3\]) are readily available, this
facilitates building, refining, and evaluating MASs that perform code
generation tasks. Consequently, code generation is the most common SE
task addressed by MASs for SE tasks. For example, Zhao et al. proposed
an LLM-based MAS named VisionCoder that "offers a cost-effective and
efficient solution for code generation" by "establishing a
tree-structured thought distribution and development mechanism" \[S1\].

Fault Localization (9, 9.6%) designates the task of using LLM-based MASs
to pinpoint locations in a codebase that are responsible for observed
failures and erroneous behavior. In an LLM-based MAS, various agents
specialize in complementary tasks such as static analysis and fault
candidate filtering. The iterative interactions between these agents
enable cross-validation of evidence used to infer which code statement
is responsible for the failure and consistent tracing of
failure-inducing code statements. The combination of the specialization
of agent roles, the coordination among agents,

                                                ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:10 Cai et al.

and the semantic reasoning capabilities of LLMs allows LLM-based MASs to
produce accurate and explainable fault localization results. For
instance, Qin et al. proposed an LLM-based MAS called AGENTFL that
simulates "the behavior of a human developer" to "localize bugs for an
entire project" \[S4\].

End-to-End Software Maintenance (8, 8.5%) is the task of automating the
lifecycle of software maintenance activities, from detecting issues to
producing and applying code changes, with LLMs providing analysis of
software artifacts and the automated modification of existing software
systems. By delegating responsibilities to specialized agents (e.g.,
fault localization, program repair, test generation, and verification),
designers of LLM-based MASs can construct automated, modular, and
scalable end-to-end maintenance workflows. For example, Liu et
al. proposed an LLM-based MAS named MarsCode Agent that "leverages LLMs
to automatically identify and repair bugs in software code" \[S31\].

Program Repair (8, 8.5%) refers to the automated process of correcting
errors and defects in software systems to restore or enhance their
functionality using LLM-based MASs. By leveraging multiple specialized
agents to jointly analyze program logic, data flow, and semantic
constraints, program repair can be carried out automatically, leading to
improvements in repair accuracy and reliability. For example, Moon et
al. proposed COFFEEPOTS, an LLM-based MAS capable of "automatically
correcting critical errors generated from code LLMs" through
"feedback-driven Preference-Optimized Tuning and Selection" \[S69\].

End-to-End Software Development (7, 7.4%) refers to build a software
system by orchestrating LLM-based MASs. By organizing specialized agents
around development activities such as require- ments elicitation,
software design, implementation, and testing, designers of MASs can
establish a comprehensive and continuous software development pipeline.
For example, Hong et al. proposed an LLM-based MAS named MetaGPT that
"encodes Standardized Operating Procedures (SOPs) into prompt sequences
for more streamlined workflows" to equip the system with "human-like
domain expertise" in software development \[S81\].

Code Review (6, 6.4%) is the automated examination of source code by
LLM-based MASs to explore defects, check adherence to coding standards,
and suggest improvements to code quality. Through the use of agents that
perform style checking, correctness validation, semantic analysis, and
reviewer suggestion generation, LLM-based MASs can provide consistent
and context-aware feedback that accelerates the code review process. For
instance, Tang et al. proposed an LLM-based MAS named CodeAgent aimed at
"automating code review" \[S44\].

Software Testing (6, 6.4%) covers automated evaluation of a system and
its components using LLM-based MASs to verify conformance with
requirements and to uncover deviations from ex- pected behavior. When
LLM-based agents cooperate in test case generation, prioritization,
oracle construction, and automated test execution, MASs can deliver
adaptive and efficient test suites that comprehensively enhance software
quality, mitigate potential risks, and bolster confidence in the system
under test. For instance, Yoon et al. proposed an LLM-based MAS named
DROIDAGENT, which is "an autonomous GUI testing agent for Android, for
semantic, intent-driven automation of GUI testing" \[S47\].

Requirements Engineering (3, 3.2%) involves a set of activities for
eliciting, specifying, validating, and managing software requirements by
leveraging LLM-based MASs to analyze requirements and maintain
traceability between requirements and related artifacts. By allocating
agents to tasks

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:11

including elicitation, conflict identification, prioritization, and
validation, designers can establish an automated and collaborative
workflow for requirements engineering that ensures traceability and
consistency between requirements and related artifacts. For example, Jin
et al. proposed an LLM-based MAS named MARE that "leverages
collaboration among LLMs throughout the entire RE process" to obtain
"high-quality requirements specifications" \[S30\].

Code Translation (1, 1.1%) denotes the task of transforming source code
from one programming language into functionally equivalent code in
another language with the assistance of LLM-based MASs. Agents
coordinate over translation outputs, including candidate target-language
code, syn- tactic structure (e.g., AST) of candidate code, API mappings,
and execution results from generated tests to ensure the quality of
translated code. For example, Yuan et al. proposed an LLM-based MAS
named TRANSAGENT that "leverages parallel data to train models for
automated code transla- tion" \[S56\].

Release Management (1, 1.1%) denotes the analysis of release-related
data to determine whether the software system has reached release
readiness and to provide the corresponding release decision. By
employing an MAS to automatically plan analytical steps and to perform
analysis over software artifacts, the generation of release decisions
can be automated. For example, Khoee et al. proposed an LLM-based MAS
named GoNoGo which "has demonstrated significant improvements in the
software release decision-making process besides saving time, improving
accessibility, reducing reliance on specialized analysts, and
accelerating overall workflow" \[S22\].

4.2 Category of Quality Attributes Considered (RQ2) As mentioned in
Section 3.1, LLM-based MASs for SE tasks involve various Quality
Attributes (QAs) that designers consider during the construction and
implementation of these MASs. In this section, we report the results of
RQ2 by following the categorization of QAs in ISO/IEC 25010:2023 \[16\].
Figure 3 and Table 3 present the results of RQ2, in which Functional
Suitability (94.7%) is the QA that is most commonly considered in the
design of LLM-based MASs to address SE tasks. Meanwhile, Performance
Efficiency (51.1%) and Maintainability (50.0%) are also considered by a
number of LLM-based MASs. The remaining QAs considered are Reliability
(36.2%), Flexibility (25.5%), Compatibility (10.6%), Security (10.6%),
and Interaction Capability (9.6%). Functional Correctness (86) Resource
Utilization (27) Modularity (46)

                                               First Author                    Functional Completeness (24)         Time Behaviour (27)                 Analysability (4)                Fault Tolerance (21)
                                 1                                                                                  Capability (11)                     Reusability (1)                  Faultlessness (13)
                                                                               Functional Appropriateness (11)
                 Identifies Quality Attributes

finds related description

                                                                           Functional Suitability (89, 94.7%)    Performance Efficiency (48, 51.1%)   Maintainability (47, 50%)          Reliability (34, 36.2%)
        2




                                                                                                    Taxonomy of Quality Attributes Considered by Designers of LLM-based Multi-Agent Systems
                  Alignment between feedback generation and code editing
                  Keep the correctness of Generated Artifacts
       3

reports S71: Maintain the "Correctness" of Generated Artifacts
Flexibility (24, 25.5%) Compatibility (10, 10.6%) Security (10, 10.6%)
Interaction Capability (9, 9.6%) Belong to "Functional Correctness"
Adaptability (16) Interoperability (8) Confidentiality (9) Operability
(5) Example of 'Functional Correctness' Scalability (12) Co-existence
(7) Integrity (1) User Engagement (5) Taxonomy Legend Quality
Characteristics Subcharacteristics Taxonomy (Number, Percentage) (Number
of Papers)

            Fig. 3. Taxonomy of Quality Attributes considered in the design of LLM-based MASs for SE Tasks

Functional Suitability (89, 94.7%) is the capacity of an LLM-based MAS
to implement functions that satisfy explicit user requirements and
requirements derived from specified conditions (e.g., task constraints).
There are three sub-Quality Attributes (sub-QAs) considered by the
designers of LLM-based MASs under Functional Suitability:

                                                                                      ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:12 Cai et al.

              Table 3. Quality Attributes considered in the design of LLM-based MASs for SE Tasks

          Quality Attribute        Sub_Quality Attribute       Studies
                                                               [S1], [S2], [S3], [S4], [S5], [S7], [S8], [S9], [S11], [S12], [S13], [S14], [S15], [S16],
                                                               [S17], [S19], [S20], [S22], [S23], [S24], [S25], [S26], [S27], [S28], [S29], [S30], [S31],
                                                               [S32], [S33], [S34], [S36], [S38], [S39], [S40], [S41], [S42], [S43], [S44], [S46], [S47],
                                    Functional Correctness     [S48], [S49], [S50], [S51], [S52], [S53], [S54], [S55], [S56], [S57], [S58], [S59], [S61],
                                                               [S62], [S63], [S64], [S65], [S66], [S67], [S68], [S69], [S70], [S71], [S72], [S73], [S74],
         Functional Suitability                                [S75], [S76], [S77], [S78], [S79], [S80], [S81], [S82], [S83], [S84], [S85], [S86], [S87],
                                                               [S88], [S89], [S90], [S91], [S92], [S93], [S94]
                                                               [S6], [S12], [S18], [S21], [S24], [S29], [S30], [S34], [S44], [S47], [S54], [S55], [S62],
                                   Functional Completeness
                                                               [S64], [S73], [S76], [S79], [S80], [S83], [S84], [S85], [S91], [S93], [S94]
                                  Functional Appropriateness   [S22], [S34], [S36], [S41], [S49], [S55], [S67], [S69], [S73], [S93], [S94]
                                                               [S2], [S4], [S6], [S8], [S18], [S19], [S20], [S25], [S28], [S35], [S36], [S37], [S39],
                                     Resource Utilization      [S40], [S45], [S46], [S47], [S48], [S49], [S58], [S63], [S64], [S68], [S81], [S87], [S88],
                                                               [S93]
         Performance Efficiency                                [S2], [S4], [S6], [S8], [S10], [S13], [S21], [S22], [S27], [S39], [S45], [S46], [S47],
                                        Time Behavior          [S49], [S55], [S56], [S58], [S60], [S65], [S73], [S80], [S81], [S82], [S87], [S90], [S91],
                                                               [S94]
                                          Capacity             [S18], [S26], [S38], [S45], [S48], [S57], [S59], [S85], [S88], [S89], [S94]
                                                               [S2], [S4], [S5], [S6], [S7], [S11], [S14], [S15], [S16], [S18], [S21], [S26], [S29],
                                                               [S30], [S31], [S32], [S36], [S38], [S43], [S44], [S47], [S49], [S51], [S55], [S56], [S59],
                                         Modularity
                                                               [S60], [S61], [S62], [S63], [S64], [S66], [S67], [S68], [S69], [S70], [S71], [S72], [S74],
            Maintainability                                    [S76], [S78], [S81], [S82], [S84], [S88], [S94]
                                        Analysability          [S6], [S67], [S92], [S94]
                                         Reusability           [S74]
                                                               [S5], [S7], [S8], [S10], [S30], [S39], [S40], [S42], [S47], [S55], [S57], [S61], [S63],
                                       Fault Tolerance
               Reliability                                     [S65], [S70], [S73], [S81], [S83], [S87], [S88], [S92]
                                        Faultlessness          [S1], [S13], [S24], [S27], [S48], [S51], [S52], [S53], [S62], [S64], [S77], [S86], [S94]
                                                               [S1], [S2], [S9], [S12], [S31], [S33], [S36], [S52], [S53], [S57], [S66], [S75], [S81],
                                         Adaptability
               Flexibility                                     [S82], [S88], [S91]
                                          Scalability          [S2], [S13], [S15], [S17], [S33], [S37], [S38], [S52], [S69], [S82], [S89], [S94]
                                       Interoperability        [S12], [S23], [S25], [S46], [S55], [S76], [S79], [S84]
             Compatibility
                                        Co-Existence           [S2], [S12], [S23], [S25], [S76], [S79], [S80]
                                       Confidentiality         [S3], [S9], [S21], [S25], [S44], [S65], [S77], [S82], [S85]
                Security
                                          Integrity            [S64]
                                      User Engagement          [S20], [S21], [S40], [S74], [S84]
         Interaction Capability
                                         Operability           [S40], [S46], [S49], [S66], [S76]




       • Functional Correctness (86, 91.5%): The capacity of an LLM-based MAS to deliver accurate
         results.
       • Functional Completeness (24, 25.5%): The capacity of an LLM-based MAS to yield full results
         when utilized by intended users.
       • Functional Appropriateness (11, 11.7%): The capacity of an LLM-based MAS to deliver functions
         that support the achievement of specified tasks and objectives.

Ensuring a system satisfies specified functional requirements and
produces correct outputs remains the primary concern for most designers
of LLM-based MASs for SE tasks. Functional Suitability, particularly
Functional Correctness, is a critical QA that needs to be considered in
the design of LLM-based MASs for SE tasks. For example, Zhang et
al. introduced "Deep Retrieval- Augmented Generation" in their LLM-based
MAS to "handle the complex inheritance relationships in exception types"
of Java language; consequently, the MAS can ensure the correctness of
exception handling \[S55\].

Performance Efficiency (48, 51.1%) is the capacity of an LLM-based MAS
to execute its functions within the designated time and performance
parameters while maintaining efficient use of resources (e.g., CPU,
memory, storage) under specified conditions. There are three sub-QAs
considered by the designers of LLM-based MASs under Performance
Efficiency:

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:13

    • Resource Utilization (27, 28.7%): The capacity of an LLM-based MAS to perform designated
      functions under specified conditions while consuming no more than the allocated amount of
      resources.
    • Time Behavior (27, 28.7%): The capacity of an LLM-based MAS to execute designated func-
      tions under specified conditions, ensuring that response time and throughput rates satisfy
      established requirements.
    • Capacity (11, 11.7%): The capacity of an LLM-based MAS to fulfill requirements for the upper
      bound of system parameters (e.g., concurrent user support).

Designers of LLM-based MASs prioritize optimizing computational resource
usage and ensuring timely system responses to the users of MASs. For
example, Tao et al. introduced a memory mechanism in the MAS for
software maintenance to reduce queries that "contain the same code
snippets as previous ones, leading to unnecessary computational costs"
\[S28\].

Maintainability (47, 50.0%) is the capacity of an LLM-based MAS to be
effectively and efficiently modified by designated maintainers, such as
corrections, enhancements, and adaptations to en- vironmental changes.
There are three sub-QAs considered by the designers of LLM-based MASs
under Maintainability: • Modularity (46, 48.9%): The capacity of an
LLM-based MAS to confine modifications to a single component, minimizing
impact on other components, with the system structured into discrete
modules and components exhibiting high cohesion and minimal coupling to
other modules and components. • Analysability (4, 4.3%): The capacity of
an LLM-based MAS to be effectively and efficiently evaluated for the
impact of proposed changes to one or more components, to diagnose
deficiencies, failure causes, and to identify components requiring
modification, incorporating mechanisms for self-analysis of faults and
generation of reports prior to failures and other events. • Reusability
(1, 1.1%): The capacity of an LLM-based MAS and its constituent agents
to be utilized as a component in multiple systems and in the development
of other assets. Designers of LLM-based MASs are willing to build
modular architectures to simplify mainte- nance, enable isolated
updates, debugging, and evolution in these systems. For example, Qin et
al. introduced an MAS called "AGENTFL" to "decompose the (code)
localization process into multiple phases" and "specialize the LLMs" in
various agents to complete fault localization. In this way, the
modularity of the MAS can be improved \[S4\].

Reliability (34, 36.2%) is the capacity of an LLM-based MAS to execute
designated functions under specified conditions for a defined duration
without interruptions and failures. There are two sub-QAs considered by
the designers of LLM-based MASs under Reliability: • Fault Tolerance
(21, 22.3%): The capability for an LLM-based MAS to function as intended
even in the presence of hardware and software faults. • Faultlessness
(13, 13.8%): The capability of an LLM-based MAS to execute defined
functions without faults during normal operation. In addition, the
conception of Faultlessness may also be extended to other QAs to reflect
the extent to which they fulfill the required needs under typical
operating conditions. Designers of LLM-based MASs place great importance
on ensuring system robustness to reduce potential failures and
unexpected errors. For example, Wu et al. introduced "a novel
interactive retrieval feature" in their MAS for code generation. If the
agent fails to retrieve relevant context, it would ask the user to
"UPDATE CONTEXT", instead of "terminating" the execution of the MAS
\[S64\].

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:14 Cai et al.

Flexibility (24, 25.5%) is the capability of an LLM-based MAS to adjust
in response to changes in requirements, usage contexts, and the system
environment. Flexibility with respect to usage context involves two
distinct aspects: the technical (e.g., software environment) and the
non-technical (e.g., physical environment). There are two sub-QAs
considered by the designers of LLM-based MASs under Flexibility:

       • Adaptability (16, 17.0%): The capability of an LLM-based MAS to be effectively and efficiently
         modified and transferred for operation in different hardware, software, and operational
         environments.
       • Scalability (12, 12.8%): The capability of an LLM-based MAS to manage increasing or decreas-
         ing workloads, and to adjust its capacity in response to fluctuations in requirements.

Designers of LLM-based MASs focus on enabling systems to adjust to
evolving requirements, dynamic runtime environments, and diverse
application contexts. For example, Hu et al. design an LLM-based MAS
called EvoMAC for code generation, which has "ability to iteratively
adapt both agents and their connections during test time for each task"
\[S53\].

Compatibility (10, 10.6%) is the capability of an LLM-based MAS to
exchange information with other systems and to carry out required
functions while operating within a shared environment and utilizing
common resources. There are two sub-QAs considered by the designers of
LLM-based MASs under Compatibility:

       • Interoperability (8, 8.5%): The capability of an LLM-based MAS to exchange information with
         other systems and to make mutual use of the exchanged information.
       • Co-Existence (7, 7.4%): The capability of an LLM-based MAS to perform required functions
         efficiently within a shared environment and using common resources, without causing
         negative effects on the operation of other systems.

Designers of LLM-based MASs place great importance on enabling seamless
communication, interaction, and integration with other systems,
platforms, and tools. For example, Zhang et al. proposed an LLM-based
MAS called CODEAGENT for code generation that "integrates five program-
ming tools, enabling interaction with software artifacts for information
retrieval, code implementation, and code testing" \[S12\].

Security (10, 10.6%) is the capability of an LLM-based MAS to safeguard
information and data by ensuring that individuals or other systems
access data according to their designated types and authorization
levels, and by resisting attacks from malicious entities, which includes
protection of both stored data and data in transmission. There are two
sub-QAs considered by the designers of LLM-based MASs under Security:

       • Confidentiality (9, 9.6%): The capability of an LLM-based MAS to ensure that data can be
         accessed exclusively by entities with appropriate authorization.
       • Integrity (1, 1.1%): The capacity of an LLM-based MAS to protect the integrity of its system
         and data against unauthorized alteration and deletion, whether due to malicious intent or
         computational error.

Protecting sensitive data and ensuring that information is accessible
only to authorized entities cannot be ignored. For example, Talebirad et
al. used "a stateless oracle agent, which can monitor each sensitive
task and decide if it is indeed malicious or not" to promise the
confidentiality of their LLM-based MAS for code generation \[S82\].

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:15

Interaction Capability (9, 9.6%) is the capacity of an LLM-based MAS
that enables specified users to exchange information through the user
interface for achieving intended tasks. There are two sub-QAs considered
by the designers of LLM-based MASs under Interaction Capability: •
Operability (5, 5.3%): The capability of an LLM-based MAS to provide
users with functions and interface features that facilitate efficient
monitoring, task control, and interaction with the agents, which is
closely associated with controllability of agent behaviors, robustness
of the MAS to user mistakes, and alignment with user expectations. •
User Engagement (5, 5.3%): The capacity of an LLM-based MAS to present
functions and information in a manner that is appealing and motivating,
thereby encouraging sustained user interaction, which encompasses system
properties that enhance user pleasure and satisfaction, such as
informative and user-friendly interface. Designers of LLM-based MASs
prioritize ensuring ease of operation and effective human--system
interaction to enhance the usability of MASs and their user experience.
For example, Josifosk et al. proposed an LLM-based MAS called Flows for
code generation, which "supports research in the design of interactions
involving humans as computational building blocks in a way that
maximizes the utility of the overall computation with minimal human
effort", to promise that the whole system is user-friendly to human
beings \[S74\].

4.3 Category of Design Patterns Employed (RQ3) As mentioned in Section
3.1, design patterns have been employed to guide the construction and
implementation of LLM-based MASs. In this section, we report the results
of RQ3 using the architecture patterns for foundation model based agents
identified by Liu et al. \[23\] as a starting point, together with the
additional design patterns identified in our study. Table 4 presents the
taxonomy of the design patterns extracted from the included studies.
Results show that Role-Based Cooperation (46.8%) is the most frequently
used design pattern by the designers of LLM-based MASs. Self-Reflection
(36.2%) is also widely used in designing LLM-based MASs for SE tasks.
The remaining design patterns employed are Tool-Agent Registry (14.9%),
Cross-Reflection (12.8%), Retrieval-Augmented Generation (RAG) (10.6%),
Human-Reflection (6.4%), Agent Adapter (5.3%), Single-Path Plan
Generator (5.3%), Prompt/Response Optimiser (4.3%), Debate-Based
Cooperation (4.3%), Layered-Based Cooperation (4.3%), Agent Evaluator
(3.2%), Multi-Path Plan Generator (3.2%), Incremental Model Querying
(3.2%), Hierarchical Coordination (3.2%), and Voting-Based Cooperation
(3.2%). Since one MAS may also use multiple design patterns, the sum of
the percentages of the design patterns exceeds 100%.

Role-Based Cooperation (44, 47.4%) is a collaborative pattern in which
each LLM-based agent adopts a distinct role that specifies functional
responsibilities and interaction protocols within the system. These
roles aim to improve overall agent performance by leveraging specialized
capabilities and ensuring efficient task allocation and coordination.
Applying Role-Based Cooperation in MAS design enables clear allocation
of responsibility to agents, enhances the scalability and adaptability
of the MAS, and supports flexible coordination strategies between
agents. For example, Dong et al. proposed an LLM-based MAS for code
generation, and assigned the agents to three roles: Analyst, Coder,
Tester \[S86\].

Self-Reflection (34, 35.8%) denotes a pattern in which certain agents
use LLM capabilities to perform introspective analysis of its own
actions, decisions, and performance. Through this process, the agents
with the reflection mechanism can identify improvement opportunities,
adapt to dynamic environments, and optimize contributions to
collaborative tasks, thereby increasing the effectiveness of cooperation
between agents. This pattern indicates that designers of LLM-based MASs
enable

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:16 Cai et al.

                        Table 4. Design Patterns used by designers of LLM-based MASs for SE tasks

         Design Pattern       Example                                                   Count(%)     Studies
                                                                                                     [S2], [S4], [S5], [S7], [S11], [S13], [S14], [S16],
                                                                                                     [S18], [S19], [S21], [S26], [S28], [S29], [S30], [S31],
                              Specifically, INTERVENOR employs two LLM-based                         [S32], [S35], [S36], [S37], [S38], [S42], [S44], [S46],

Role-Based Cooperation 44 (46.8%) agents to play different roles in code
repair. \[S78\] \[S47\], \[S49\], \[S51\], \[S55\], \[S56\], \[S57\],
\[S58\], \[S59\], \[S60\], \[S61\], \[S63\], \[S64\], \[S67\], \[S69\],
\[S71\], \[S78\], \[S81\], \[S86\], \[S93\], \[S94\] \[S1\], \[S2\],
\[S3\], \[S11\], \[S19\], \[S22\], \[S24\], \[S27\], ..., in order to
reduce hallucinations and inefficient \[S31\], \[S36\], \[S37\],
\[S38\], \[S39\], \[S42\], \[S43\], \[S45\], Self-Reflection planning,
we apply a self-reflection 34 (36.2%) \[S47\], \[S49\], \[S53\],
\[S57\], \[S58\], \[S60\], \[S62\], \[S63\], mechanism. \[S43\] \[S72\],
\[S73\], \[S74\], \[S75\], \[S79\], \[S81\], \[S87\], \[S90\], \[S91\],
\[S92\] Across five tasks with Python and WikiSearch API as tools,
Lemur-70B-Chat outperforms both \[S2\], \[S8\], \[S9\], \[S12\],
\[S25\], \[S27\], \[S75\], \[S76\], Tool-Agent Registry 14 (14.9%)
Llama-2-70B-Chat and CodeLlama-34B-INST by \[S79\], \[S80\], \[S82\],
\[S85\], \[S88\], \[S94\] large margins. \[S79\] Meanwhile, this Stderr
information is provided to the questioner, who will generate a natural
language description based on the Stderr. This natural language
description is also appended to the \[S7\], \[S13\], \[S26\], \[S41\],
\[S50\], \[S61\], \[S65\], \[S67\], Cross-Reflection 12 (12.8%) dialogue
messages. Next, both the natural language \[S69\], \[S71\], \[S74\],
\[S78\] description and the Stderr are provided as new questions to the
programmer, who will continue to modify the code. \[S7\] Furthermore, we
draw inspiration from the RAG Retrieval-Augmented (Retrieval-Augmented
Generation) approach, where \[S8\], \[S23\], \[S36\], \[S45\], \[S51\],
\[S54\], \[S55\], \[S64\], 10 (10.6%) Generation (RAG) we match similar
content from a memory pool as \[S89\], \[S94\] additional information.
\[S36\] We give the agent access to tools, including access to: Agent
Adapter 6 (6.4%) \[S6\], \[S9\], \[S22\], \[S25\], \[S27\], \[S94\] ...
\[S25\] AISD is designed to keep the user in the loop, i.e., by
repeatedly taking user feedback on use cases, Human-Reflection 5 (5.3%)
\[S20\], \[S27\], \[S40\], \[S84\], \[S94\] high-level system designs,
and prototype implementations through system testing. \[S20\] AXNav
consists of three main components that are Single-Path Plan Generator
used to prepare for, execute, and export test results: 5 (5.3%) \[S10\],
\[S15\], \[S48\], \[S66\], \[S68\] ... \[S66\] The Requirements
Engineering agent is an integral part of our engine, leveraging AI
capabilities to Prompt/Response Optimiser 4 (4.3%) \[S4\], \[S9\],
\[S21\], \[S33\] automate the generation and prioritization of software
requirements. \[S21\] To address this, we implemented a Multi-Agent
Debate-Based Cooperation Debate (MAD) mechanism to establish a loop 4
(4.3%) \[S3\], \[S35\], \[S73\], \[S83\] between generator and
validator. \[S3\] ..., we propose a layered approach for implementing
capabilities in LLM-based applications by mapping Layered-Based
Cooperation 4 (4.3%) \[S15\], \[S23\], \[S45\], \[S77\] them to the
layers and components with corresponding attributes. \[S45\] To verify
that generated fix suggestions can plausibly fix each issue, FixAlly
evaluates each code Agent Evaluator 3 (3.2%) \[S60\], \[S61\], \[S70\]
modification in its Suggestion Assessment module. \[S60\] It divides the
Vulnerability Identification phase into Multi-Path Plan Generator 40
targeted scenarios, each focused on a specific 3 (3.2%) \[S14\],
\[S23\], \[S26\] vulnerability type (as listed in our repository).
\[S26\] These patches might be from running a single SWE Incremental
Model agent multiple times or running multiple SWE 3 (3.2%) \[S4\],
\[S15\], \[S17\] Querying agents. \[S17\] Our method employs a novel
hierarchical coordination paradigm, inspired by a cognitive debugging
model, to efficiently manage cognitive Hierarchical Coordination 3
(3.2%) \[S2\], \[S34\], \[S76\] steps with minimal communication and
dynamically adjust to bug complexity through its three-level
architecture. \[S2\] Finally, the model merges and votes on all
candidate Voting-Based Cooperation solutions, selecting the
highest-voted one as the final 3 (3.2%) \[S17\], \[S31\], \[S33\] repair
solution. \[S31\]

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:17

agents to carry out introspection and to iteratively refine outputs,
which reduces errors and accommodates changing task requirements. For
instance, Hong et al. proposed an LLM-based MAS called MetaGPT for
software development, and its code agent can "improve code using its own
historical execution and debugging memory" with the help of
Self-Reflection \[S81\].

Tool-Agent Registry (14, 14.7%) refers to a centralized repository that
maintains a comprehensive and unified resource, readily accessible for
assigning appropriate tools to agents according to task requirements,
thereby enabling effective and reliable task execution. The registry
serves as an integral mechanism for agent collaboration by enabling
dynamic discovery, selection, and utilization of tools. Through this
mechanism, it improves output quality, reduces model workload and
latency, thereby enhancing the flexibility of the whole MAS. For
example, Fan et al. proposed an LLM-based MAS called ICAA for code
analysis, and set up a special "agent integrating a toolbox that
includes context-aware splitting, code retrieval, documentation
retrieval, Web search, and static code analysis tools". This agent
incorporates a "thinking--decision--action loop" to select and schedule
tools for different "sub-agents" \[S88\].

Cross-Reflection (12, 12.6%) denotes a collaborative pattern in which
each agent uses LLMs to observe, analyze, and interpret the behaviors,
decisions, and outputs of other agents in the MAS. This process allows
agents to gain insights into the strategies and performance of their
peers, enabling adaptive learning, strategic alignment, and improved
coordination between agents. It also supports error detection and
correction of artifacts generated by peer agents, reduces individual
biases of agents, and fosters collective calibration and consensus
between agents. For example, Wang et al. proposed an LLM-based MAS named
CAMEL for code generation, which uses a method "Chain of Repair" to
introduce a "Code Teacher" agent that provides feedback for "Code
Learner" to reflect upon and revise the generated code \[S67\].

Retrieval-Augmented Generation (RAG) (10, 10.5%) refers to a
collaborative pattern that inte- grates retrieval-based methods with
generative capabilities to enhance the problem-solving and
decision-making processes of agents. This pattern allows agents to
retrieve relevant information from external knowledge sources and
databases, and integrate the information seamlessly into their generated
outputs and actions. RAG enables agents to access up-to-date and
contextually appropriate data, enhancing the accuracy, relevance, and
effectiveness of their contributions to collaborative tasks. For
instance, Wu et al. proposed an LLM-based MAS called AutoGen that uses
"RAG" to enhance the quality of code generation and question answering
\[S64\].

Agent Adapter (6, 6.3%) is a pattern that enables smooth interaction and
collaboration between various agents and external tools by standardizing
communication protocols, translating data for- mats, and managing
interfaces within the MAS. This pattern allows agents to exchange
information and coordinate actions effectively, thereby improving the
overall performance and adaptability of the MAS. For example, Tufano et
al. proposed an LLM-based MAS for code generation, using a component
called "Conversation Manager", which can "parse the commands and invoke
the Tools Library", to help the agents operate the external tools
\[S9\].

Human-Reflection (5, 5.3%) refers to a collaborative pattern that human
users observe, evaluate, and provide reflective feedback on the actions,
decisions, and outputs of agents. This feedback is then utilized by the
agents to adjust their strategies, improve their performance, and
enhance their collaborative capability, thereby ensuring better
alignment with human goals and ethical

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:18 Cai et al.

considerations. For instance, Fakih et al. proposed an LLM-based MAS for
code generation that "integrates user feedback loops" into the pipeline
for agents to reflect upon \[S27\].

Single-Path Plan Generator (5, 5.3%) refers to a collaborative pattern
tasked with designing a linear and sequential plan to accomplish a
specific goal and task. Initially, a Planner agent (or a team of
cooperating Planner agents) constructs a cohesive, linear, and
executable plan to achieve a specified objective. The resulting plan
consists of a single, non-branching pathway of actions and decisions,
determined by analyzing the input data, the operational capabilities of
the involved agents, and the environmental constraints. The plan is
decomposed into constituent sub-tasks which are allocated to other
agents for cooperative execution. This pattern provides a clear global
plan that reduces coordination ambiguity and conflict among agents, and
enables efficient task decomposition and deterministic assignment of
sub-tasks which lowers negotiation overhead and improves throughput. For
example, Taeb et al. proposed an LLM-based MAS named AXNav for software
testing, which can "formulate a step-by-step plan that accomplishes the
goal" provided by the users of the MAS \[S66\].

Prompt/Response Optimiser (4, 4.3%) is a specialized pattern that
dynamically refines and en- hances the prompts provided to LLMs and
optimizes the generated responses to improve their relevance, accuracy,
and alignment with the objectives of the agent system. This pattern
employs iterative feedback loops, context analysis, and performance
metrics to fine-tune input prompts and evaluate output quality, ensuring
effective communication and coordination among agents. For instance,
Tufano et al. proposed an LLM-based MAS named AutoDev for code
generation, which can refine the prompts provided by the users "in a
predefined format" \[S9\].

Debate-Based Cooperation (4, 4.3%) denotes a collaborative pattern by
which multiple agents, leveraging the reasoning and argumentative
capabilities of LLMs, engage in structured debates to evaluate various
perspectives, challenge assumptions and converge on optimal solutions
for a given task. Each agent adopts a distinct viewpoint, presenting
arguments supported by evidence and logic, while critically assessing
the arguments of others. This pattern enhances MAS design by structuring
adversarial argumentation among agents to surface diverse perspectives,
reveal and correct errors and weak reasoning. For example, Zhang et
al. proposed an LLM-based MAS named ACFIX for software maintenance,
which introduced "Multi-Agent Debate (MAD) mechanism" between the
different agent roles \[S3\].

Layered-Based Cooperation (4, 4.3%) refers to a structured collaborative
pattern wherein agents are organized into hierarchical layers, each
layer assigned specific agent roles, tasks, and levels of abstraction
based on their capabilities. Agents within each layer leverage the
generative and reasoning capacities of LLMs to process inputs, execute
tasks, and produce outputs that are passed to subsequent layers for
further refinement and integration. This pattern separates concerns
across hierarchical abstraction levels, enabling role specialization,
modularity, and scalable coordination. For instance, Zan et al. proposed
an LLM-based MAS named CODES, which is formulated in a "Multi-Layer
Sketch" to accomplish the repository-level code generation \[S15\].

Agent Evaluator (3, 3.2%) refers to a specialized pattern, which
introduces an independent, specialized agent that systematically
conducts metric-based evaluation and governance of the performance,
decisions, and outputs of other agents in the MAS, thereby supporting
targeted remediation, quality assurance, and continuous improvement of
the MAS. For example, Huang et al. proposed an LLM-based MAS named
AgentCoder, which implements a "test agent" to evaluate

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:19

the results of code generation. "If all test cases are passed, the agent
returns the code to the human developer" \[S61\].

Multi-Path Plan Generator (3, 3.2%) denotes a specialized pattern that
generates multiple al- ternative paths and action options of agents at
each intermediate step, then assembles them into the final task
execution plan. Each plan represents a unique sequence of actions and
decisions that account for various scenarios, agent capabilities, and
environmental variables. This pattern increases the robustness and
adaptability of an LLM-based MAS by generating multiple plans that
support the selection of optimal or complementary strategies across
varying agent capabilities and environmental conditions. For example, Ma
et al. proposed an LLM-based MAS for code generation, which can generate
multiple plans to complete the code generation tasks given by users, and
the MAS "iteratively narrows down the search space and guides the agents
to focus on the most relevant area by simulating multiple workflows and
evaluating their reward score" \[S23\].

Incremental Model Querying (3, 3.2%) is a collaborative pattern in which
agents decompose complex tasks into smaller, sequential sub-queries and
iteratively query LLMs, with each query building on the outputs of prior
ones to refine understanding, integrate intermediate results, and
gradually converge toward a comprehensive and high-quality solution. For
example, Qin et al. proposed an LLM-based MAS called AGENTFL, which
adopts "a Multi-Round Dialogue strategy in the Method Review task" to
improve the efficiency of fault localization \[S4\].

Hierarchical Coordination (3, 3.2%) refers to a dynamic and scalable
collaborative pattern that employs a tiered approach to resolve the
given SE tasks. Initially, a minimal set of agents that leverage the
capabilities of LLMs collaborate through simple coordination strategies
to address a given SE task. If the task remains unsolved, the MAS can
gradually expand the collaboration framework by introducing additional
agents and tools, thereby enhancing its capacity with increased
complexity. This iterative process continues until the problem is
successfully solved or the system reaches its predefined complexity
limit. For example, Lee et al. proposed an LLM-based MAS called FixAgent
under the guidance of Hierarchical Coordination in which simple software
maintenance tasks are handled by "the simple L1 agents", while more
complex maintenance tasks trigger the incremental incorporation of
additional agents and external tools to support deeper analysis and more
sophisticated task solving \[S2\].

Voting-Based Cooperation (3, 3.2%) is a collaborative pattern in which
multiple agents, using the reasoning and evaluation capabilities of
LLMs, make collective decisions by voting on proposed actions,
strategies, and solutions. Each agent contributes its perspective based
on its role, expertise, and task analysis, and the final decision is
determined through a predefined voting protocol, such as majority rule
or weighted voting. This pattern enables democratic participation,
reduces individual bias, and promotes consensus-based outcomes, thereby
enhancing the robustness and fairness of collaborative task execution.
For instance, Li et al. proposed an LLM-based MAS that uses voting
between agents to "determine the final answer" to the code generation
task given by users \[S33\].

4.4 Category of Design Rationale (RQ4) As mentioned in Section 3.1,
LLM-based MASs are designed according to the rationale that guides their
construction to support specific SE tasks. In this section, we report
the results of RQ4. Table 5 presents the taxonomy of the design
rationale of LLM-based MASs for SE tasks extracted from the included
studies. Results show that Improving the Quality of Generated Code
(44.7%) is the most commonly used design rationale. Meanwhile,
Simulating Human Processes of Solving SE Tasks

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:20 Cai et al.

(29.8%) is also used by designers of LLM-based MASs. The remaining
design rationale includes: Optimizing Software Resource Management
(28.7%), Improving the Efficiency of Generating Software Artifacts
(24.5%), Reducing the Difficulty of Task Resolution (21.7%), Improving
the Adaptability of Agent Systems (19.1%), Enhancing the Diversity of
Generated Software Artifacts (12.8%), and Ensuring Software Security
(3.2%).

Improving the Quality of Generated Code (42, 44.7%) represents the most
frequently adopted design rationale. Code is a key artifact generated
within an LLM-based MAS, and the quality of the generated code has a
direct impact on the final product produced by LLM-based MASs for SE
tasks. Defects in generated code can propagate to subsequent artifacts
and undermine the reliability, maintainability, and overall quality of
the final software products. Therefore, designers place great emphasis
on improving code quality and adopt a variety of strategies to achieve
this goal. For example, Lei et al. proposed an LLM-based MAS for code
generation, which introduces "an interaction system comprising two
agents" (questioner and programmer) to simulate the process of
programmers writing code according to project requirements and
conducting unit tests. The MAS "uses multiple rounds of execution
feedback to check the generated code" for improving the code quality
\[S7\].

                                Table 5. Design Rationale of LLM-based MASs for SE Tasks

       Design Rationale        Example                                                  Count(%)     Studies
                                                                                                     [S1], [S5], [S6], [S7], [S11], [S12], [S13], [S24],
                               We instructed each agent to iterate with the others at
                                                                                                     [S27], [S29], [S31], [S33], [S36], [S40], [S41], [S42],
                               least three times to refine and update the code based

Improving the Quality of \[S45\], \[S46\], \[S47\], \[S49\], \[S50\],
\[S51\], \[S52\], \[S54\], on feedback from the previous agents,
ensuring a 42 (44.7%) Generated Code \[S57\], \[S58\], \[S59\], \[S60\],
\[S61\], \[S62\], \[S64\], \[S65\], thorough and collaborative
development \[S66\], \[S70\], \[S73\], \[S79\], \[S81\], \[S83\],
\[S90\], \[S91\], process. \[S13\] \[S92\], \[S93\] Specifically, iAudit
is inspired by the observation \[S2\], \[S5\], \[S7\], \[S10\], \[S11\],
\[S12\], \[S14\], \[S16\], Simulating Human that expert human auditors
first perceive what could \[S19\], \[S26\], \[S28\], \[S29\], \[S30\],
\[S35\], \[S42\], \[S44\], Processes of Solving SE 28 (29.8%) be wrong
and then perform a detailed analysis of the \[S53\], \[S55\], \[S58\],
\[S59\], \[S64\], \[S67\], \[S71\], \[S72\], Tasks code to identify the
cause. \[S16\] \[S78\], \[S81\], \[S86\], \[S87\] We posit that our
approach will considerably \[S2\], \[S4\], \[S6\], \[S8\], \[S14\],
\[S18\], \[S19\], \[S20\], Optimizing Software augment the field of
software quality assurance, \[S25\], \[S28\], \[S32\], \[S34\], \[S35\],
\[S36\], \[S37\], \[S40\], 27 (28.7%) Resource Management rendering it
more efficient, precise, and \[S45\], \[S46\], \[S47\], \[S48\],
\[S49\], \[S58\], \[S63\], \[S68\], cost-effective. \[S88\] \[S81\],
\[S87\], \[S88\] Moreover, our analysis of agent interactions within
\[S2\], \[S3\], \[S4\], \[S9\], \[S13\], \[S17\], \[S19\], \[S21\],
Improving the Efficiency of AGENTVERSE reveals the emergence of specific
23 (24.5%) \[S27\], \[S39\], \[S40\], \[S45\], \[S49\], \[S61\],
\[S62\], \[S63\], Generating Artifacts collaborative behaviors,
contributing to heightened \[S64\], \[S73\], \[S75\], \[S87\], \[S88\],
\[S90\], \[S91\] group efficiency. \[S62\] Specifically, by decomposing
the localization process into several steps and achieving FL through the
\[S1\], \[S2\], \[S4\], \[S13\], \[S14\], \[S15\], \[S20\], \[S22\],
Reducing the Difficulty of collaboration of multiple LLM-driven agents
(i.e., 20 (21.7%) \[S32\], \[S43\], \[S53\], \[S56\], \[S62\], \[S64\],
\[S69\], \[S72\], Task Resolution intelligent entities that can perceive
the \[S73\], \[S84\], \[S86\], \[S93\] environment, make decisions, and
perform actions), the advantages we expect are twofold. \[S4\] Our
proposal for dynamic process generation aims to \[S1\], \[S2\], \[S9\],
\[S12\], \[S31\], \[S33\], \[S36\], \[S37\], Improving the Adaptability
accommodate this variability, enabling a wider 18 (19.1%) \[S38\],
\[S47\], \[S52\], \[S53\], \[S57\], \[S75\], \[S76\], \[S89\], of Agent
Systems array of diverse instances to emerge and guide the \[S91\],
\[S94\] development process accordingly. \[S57\] The parallel generation
method with KMeans Enhancing the Diversity of filtering helps improve
the diversity than using \[S18\], \[S21\], \[S23\], \[S26\], \[S38\],
\[S45\], \[S48\], \[S57\], 12 (12.8%) Generated Artifacts parallel
generation only, albeit not \[S59\], \[S80\], \[S85\], \[S89\]
significantly. \[S18\] The system should be designed with robust
security Ensuring Software Security measures in place to prevent
unauthorized access or 3 (3.2%) \[S77\], \[S82\], \[S83\] misuse.
\[S82\]

Simulating Human Processes of Solving SE Tasks (28, 29.8%) is another
design rationale fre- quently employed by designers. LLM-based MASs are
inspired by human approaches to solving SE tasks, and their designs and
implementations are naturally built on this foundation. For example,

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:21

Zhang et al. proposed an LLM-based MAS named Self-Edit, which "is
inspired by the problem-solving process of human programmers" to assign
roles and tasks to agents \[S87\].

Optimizing Software Resource Management (27, 28.7%) is also a widely
considered design ratio- nale. Designers of LLM-based MASs focus on the
efficient allocation, utilization, and coordination of computational and
memory assets among autonomous agents. For example, Qin et al. proposed
an LLM-based MAS named AGENTFL decomposing the whole fault localization
process into three stages, and implemented "Document-Guided Search
strategy" and "retained only the Top-N classes that possess relatively
high method-level coverage" to significantly reduce input scale given to
agents, thereby lowering costs \[S4\].

Improving the Efficiency of Generating Software Artifacts (23, 24.5%) is
a major design rationale used to support decisions. Accelerating the
generation of artifacts and enhancing their success rate is an essential
concern when designing LLM-based MASs for SE tasks. For example, Yang et
al. proposed an LLM-based MAS for code generation, and the MAS
introduced "well-designed Agent-Computer Interfaces (ACIs)" for each
agent. The ACIs provide agents with a structured view of the runtime
environment and apply strict history management and context pruning to
supply only the minimal information relevant to the current task, which
help agents "understand the state of the application given previous
changes" and "avoid unnecessary context from prior observations",
thereby improving the efficiency of generating code \[S40\].

Reducing the Difficulty of Task Resolution (20, 21.7%) is a design
rationale considered by designers. Simplifying the resolution of SE
tasks can facilitate the design and implementation of LLM-based MASs,
enhance the quality of produced software artifacts, increase production
efficiency, and reduce the costs associated with completing SE tasks.
For instance, Qian et al. proposed an LLM-based MAS called ChatDev for
software development, which "uses a chat chain to divide each phase into
smaller sub-tasks further" and assigns simpler sub-tasks to related
agents \[S93\].

Improving the Adaptability of Agent Systems (18, 19.1%) is a commonly
utilized design rationale. Designers of LLM-based MASs for SE tasks aim
to enable these systems to operate in diverse runtime environments,
which in turn placing emphasis on enhancing the adaptability of the
MASs. For instance, Xu et al. proposed an LLM-based MAS called
Gentopia.AI for code generation, which allows agents to be built in a
"hierarchical architecture" or a "non-hierarchical architecture". This
strategy enables agents to easily call external tools, integrate
multiple LLMs, and invoke other "sub-agents as plugins", which improves
the adaptability of the MAS \[S76\].

Enhancing the Diversity of Generated Software Artifacts (12, 12.8%) is
considered by designers. Enhancing the diversity of produced artifacts
allows the selection of artifacts from a broader range, facilitating the
identification of higher-quality artifacts and increasing the likelihood
of finding optimal solutions to the SE task. For example, Ataei et
al. proposed an LLM-based MAS called Elicitron for requirements
engineering, which automatically creates multiple interviewer agents.
Each agent is configured with a distinct interviewing style and
perspective, and the dialogue context of each agent is maintained
independently, enabling the MAS to "identify a diverse set of user
needs" \[S48\].

Ensuring Software Security (3, 3.2%) cannot be ignored. The security of
LLM-based MASs for SE tasks is of paramount importance. Designers of
LLM-based MASs have incorporated specialized measures to ensure system
security. For example, Talebirad et al. proposed an LLM-based MAS for
code generation, which "addresses limitations and challenges such as
security risks". Since the

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:22 Cai et al.

MAS has the "ability to interact with files and execute code", which
introduces potential security risks. This MAS uses "a state-less oracle
agent, which can monitor each sensitive task and decide if it is indeed
malicious or not" \[S82\].

5 Discussions 5.1 Interpretations of the Results In this section, we
discuss and explain the relationship between the results of the four
RQs: SE Tasks, Quality Attributes, Design Patterns, and Design
Rationale. 5.1.1 Mapping of SE Tasks and Quality Attributes. Table 6
shows the mapping relationship between the Quality Attribute categories
and SE Task categories in designing LLM-based MASs, using abbreviations
to represent each category of SE Tasks. For example, "CG" represents
Code Generation. The full names of all SE Task categories are provided
in the note of Table 6. From the results presented in Table 6, we can
see that: Functional Suitability (89, 94.8%) is the QA considered by
most of designers. Almost every LLM-based MAS includes a design aimed at
maintaining the Functional Suitability of the MAS. In the Functional
Suitability category, Functional Correctness (86) is the most frequently
considered sub-QA, receiving the greatest attention in LLM-based MASs
for Code Generation (43). As generated code directly determines whether
a system behaves correctly, designers of LLM-based MASs for Code
Generation prioritize Functional Correct- ness to ensure outputs conform
to specifications, reduce debugging and integration costs. Besides,
Functional Correctness is considered in LLM-based MASs across all
categories of SE Tasks, indicating its paramount importance. Functional
Completeness is also considered by various designers, which is also
important in MASs for Code Generation (13). The predominance of
Functional Suitability, especially Functional Correctness, reflects the
imperative for designers to ensure that LLM-based MASs reliably produce
semantically accurate and syntactically valid artifacts across all SE
tasks. Designers of LLM-based MASs for SE tasks also highly value
Performance Efficiency (48, 51.1%). In the Performance Efficiency
category, both Resource Utilization and Time Behavior are of great
importance, in which Resource Utilization is highly valued by the
designers of MASs for Code Generation (12). Capacity is less considered
in the Performance Efficiency category. Given that LLM-based MASs have
significant computational and latency costs, designers prioritize
resource utilization and runtime behavior to ensure the performance of
MASs. In addition, tasks such as Code Generation and Fault Localization
are highly sensitive to response time: these two SE tasks represent
crucial stages in the development workflow, where high latency can
directly disrupt the overall process. Many SE tasks involve frequent
model interactions, such as repeated code completions and iterative
fault localization and patch verification. When handling a large number
of users or extensive codebases, resource efficiency becomes the primary
factor determining the scalability and economic feasibility of an MAS.
Many LLMs may impose limits on request throughput, which makes capacity
improvement difficult. Maintainability (47, 50.0%) is also a significant
QA considered by designers of LLM-based MASs for SE tasks. Within this
category, Modularity is the most valued sub-QA, receiving the greatest
attention in LLM-based MASs for Code Generation (20). The strong
emphasis on Maintainability in LLM-based MAS design for SE tasks,
especially Modularity, stems from the need to decompose complex agent
workflows into interchangeable components. Hassouna et al. \[12\]
proposed a unified modeling framework that decomposes agent workflows
into structurally clear and well-defined modules to address the lack of
modularity and composability of existing LLM-based MASs. Therefore,
implementing agents as self-contained and interchangeable modules can
improve the reusability of MASs. This form of role-level modularity
minimizes coupling, limits the propagation of failures, and facilitates
independent development, testing, and replacement of agents in LLM-based
MASs.

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:23

Moreover, dividing functionality into agent-based modules simplifies the
monitoring and analysis of individual modules and results in functional
modules that can be more easily reused in different application
contexts. Reliability (34, 36.2%) is also considered by designers of
LLM-based MASs for SE tasks. Fault Tolerance is most valued in the
design of MASs for Code Generation (9). The emphasis on Reliability
arises because designers expect LLM-based MASs to handle the inherent
unpredictability and error- proneness of generated artifacts to ensure
robust workflows. Since LLMs inherently exhibit random behavior and
occasional hallucinations, achieving perfect correctness is
unattainable. Consequently, designers place emphasis on incorporating
redundancy and error detection into generated artifacts to maintain
system-level functionality when individual agents produce inaccurate
outputs. This consideration is particularly emphasized in MASs for Code
Generation. Flexibility (24, 25.5%) is another QA considered by
designers of LLM-based MASs. Adaptability is the sub-QA considered by
more designers in the Flexibility category, and Adaptability is most
valued in LLM-based MASs for Code Generation (8). Emphasis on
Flexibility reflects the need for LLM-based MASs to adjust dynamically
to evolving requirements and contexts from users. Designers prioritize
Adaptability because LLM-based MASs must operate across evolving APIs
and prompt design, requiring agents to rapidly adjust behaviors,
representations, and tools used to provide correct functions. Leong et
al. \[19\] proposed a dynamic graph selection mechanism that enables the
MAS to automatically determine the agent communication topology based on
the given task (e.g., code generation), thereby enhancing Adaptability
of the MAS. Many designers of LLM-based MASs also consider Compatibility
(10, 10.6%) of their MASs. Interoperability is the more valued sub-QA of
Compatibility for Code Generation (6). Emphasis on Compatibility stems
from the necessity for LLM-based MAS to integrate seamlessly with
existing runtime environments. Interoperability enables semantically
aligned communication and end-to-end verification among agents. There
are interoperable toolchains, common intermediate representations (e.g.,
ASTs), and consistent data formatting in MASs for Code Generation, so it
is important to ensure Compatibility of MASs. Security (10, 10.6%) is
considered by designers of LLM-based MASs for SE tasks and accounts for
the same proportion as Compatibility. Confidentiality is the most
frequently considered sub- QA in the Security category. Confidentiality
is valued in the MASs for Code Generation (2), Fault Localization (2),
and End-to-End Software Development (2). Since agents collaboratively
inspect and modify intermediate artifacts produced by other agents, the
forwarding of context or invocation of tools may introduce security
issues, such as prompt leakage threats \[1\]. LLM-based MASs manipulate
user-provided prompts as well as intermediate outputs. The leakage of
such critical information may jeopardize user privacy and render the
MASs vulnerable to malicious attacks, making it crucial to prevent such
leakage in the MASs \[29\]. Designers of LLM-based MASs for SE tasks
also want to ensure Interaction Capability (9, 9.6%). Operability shares
the same proportion as User Engagement as the sub-QAs of Interaction
Capability. Operability is the most valued sub-QA for Code Generation
(4). Emphasis on Interaction Capability arises from the inherently
iterative nature of agent workflows, in which clear operability and
active user participation are essential for refining agent outputs. To
support such iterative processes, effective human--agent interaction
requires qualities that ensure both usability for human users and
controllability of MASs. Maintaining a balance between these qualities
ensures that agents remain accessible and user-friendly.

5.1.2 Mapping of SE Tasks, Design Patterns, and Design Rationale. Figure
4 shows the mapping relationship between the categories of SE Tasks,
Quality Attributes, Sub-Quality Attributes, Design Patterns, and Design
Rationale in LLM-based MASs for SE tasks.

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:24 Cai et al.

               Table 6. Mapping between Quality Attributes (vertical) and SE Tasks (horizontal)

                                                               CG     FL    ETESM      PR    ETESD      CR     ST   RE    CT     RM
                         Functional Correctness                43      8      7         8      6         4      6    2     1      1

Functional Suitability Functional Completeness 13 0 0 0 2 3 4 2 0 0
Functional Appropriateness 6 1 0 1 1 1 0 0 0 1 Resource Utilization 12 5
3 1 1 2 1 2 0 0 Performance Efficiency Time Behavior 8 2 4 2 4 2 3 0 1 1
Capacity 3 1 1 1 1 1 1 2 0 0 Modularity 20 4 5 3 3 5 3 2 1 0
Maintainability Analysability 3 0 0 0 0 1 0 0 0 0 Reusability 1 0 0 0 0
0 0 0 0 0 Fault Tolerance 9 0 1 2 4 3 1 1 0 0 Reliability Faultlessness
10 1 0 0 1 0 0 1 0 0 Adaptability 8 1 2 0 2 1 2 0 0 0 Flexibility
Scalability 7 0 1 3 1 0 0 0 0 0 Interoperability 6 1 0 0 0 1 0 0 0 0
Compatibility Co-Existence 4 1 1 0 0 0 1 0 0 0 Confidentiality 2 2 1 0 2
1 1 0 0 0 Security Integrity 1 0 0 0 0 0 0 0 0 0 Operability 4 0 0 0 1 0
0 0 0 0 Interaction Capability User Engagement 3 1 0 0 0 0 1 0 0 0 Full
names of each SE task: CG: Code Generation; FL: Fault Localization;
ETESM: End-to-End Software Maintenance; PR: Program Repair; ETESD:
End-to-End Software Development; CR: Code Review; ST: Software Testing;
RE: Requirements Engineering; CT: Code Translation; RM: Release
Management.

Fig. 4. Mapping between SE Tasks, Quality Attributes, Sub-Quality
Attributes, Design Patterns, and Design Rationale

From the results shown in Figure 4, we can see that most designers use
Role-Based Cooperation (18) and Self-Reflection (18) - the two most
common design patterns - to construct MASs for Code Generation, and the
most frequently employed design rationale is Improving the Quality of

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:25

Generated Code (25). Role-based cooperation allows multiple specialized
agents to focus on distinct sub-tasks of code generation, ensuring that
each part of the code is handled by the most suitable role.
Self-reflection enables these agents to evaluate their own outputs,
detect potential errors, and iteratively refine the code. These two
patterns improve the quality of generated code by combining focused
expertise on the specialized code generation task with continuous
quality assessment of the generated code. Designers adopt Role-Based
Cooperation (6) when building MASs for Fault Localization, and the most
frequent design rationale is Optimizing Software Resource Management
(5). Since assigning specialized roles supports the parallel exploration
of fault candidates, and management optimiza- tions of resources reduce
the cost of coordinating multiple diagnostic agents, many designers
prefer to apply role-based cooperation in MASs for fault localization.
Designers often employ Role-Based Cooperation (6) for building MASs that
support End-to-End Software Maintenance, and the most frequent design
rationale is Improving the Quality of Generated Code (3), Simulating
Human Processes of Solving SE Tasks (3), Optimizing Software Resource
Manage- ment (3), and Improving the Efficiency of Generating Software
Artifacts (3). Software maintenance requires a clear division of
specialized responsibilities. Assigning roles such as fault localizer,
patch generator, tester, and integrator helps modularize complex repair
workflows, and reduce interfer- ence among model behaviors. Designers
highlight code quality, human problem-solving processes, resource
management, and efficiency because these priorities collectively improve
the interpretabil- ity and traceability of the solutions to given
maintenance tasks, control the computational cost of solving the tasks,
and accelerate the generation of dependable artifacts. Designers often
use Role-Based Cooperation (2), Cross-Reflection (2), and RAG (2) when
construct- ing MASs for Program Repair, and the most frequently adopted
design rationale is Improving the Quality of Generated Code (3). Role
specialization divides the repair workflow into modular respon-
sibilities, such as synthesizer, tester, and validator. Cross-reflection
supports iterative peer critique that reveals and corrects errors in
generated code, and RAG grounds the generated content in external code
and test artifacts to enhance the factual accuracy and relevant recall
of the generated artifacts. Designers leverage Role-Based Cooperation
(6) when building MASs for End-to-End Software Development, and the most
frequently employed design rationale is Improving the Quality of
Generated Code (6). Role-based cooperation enables agents to focus on
targeted responsibilities and maintain clearer reasoning processes of
addressing development tasks, which in turn enhances the quality of the
generated code. Designers employ Role-Based Cooperation (2) to construct
MASs for Code Review, and the most frequently used design rationale is
Simulating Human Processes of Solving SE Tasks (4). Dividing
responsibilities among specialized agents allows the agents to simulate
human problem-solving processes in code review tasks, enabling agents to
collaboratively analyze, evaluate, and improve code in a manner similar
to how human reviewers check the code, making the MAS both efficient and
aligned with established SE practices. Designers are likely to adopt
Self-Reflection (3) when constructing MASs for Software Testing and the
most frequent design rationale is Improving the Quality of Generated
Code (3). Reflection mechanism enables agents to examine their
intermediate reasoning of seeking the solutions to the given testing
tasks, identify weaknesses in the generated code in the testing
progress, and revise the outputs of agents before finalizing results.
Designers employ Role-Based Cooperation (3) when building MASs for
Requirements Engineering, and the most commonly used design rationale is
Optimizing Software Resource Management (2) and Enhancing the Diversity
of Model Generation (2). Distributing responsibilities across
specialized agents helps manage software resources (e.g., memory,
tokens) more efficiently because each

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:26 Cai et al.

agent only requires role-specific information. This division of roles
encourages agents to elicit requirements from the perspectives of
various stakeholders, thereby increasing the diversity of the
requirements elicited by MASs. Designers use Role-Based Cooperation (1)
to construct MASs for Code Translation, and the most frequent design
rationale is Reducing the Difficulty of Task Resolution (1). Dividing
the overall task into specialized roles allows each agent to focus on a
narrower problem space in code translation. This structured
decomposition reduces the cognitive and operational complexity of
resolving code translation sub-tasks. Designers adopt Self-Reflection
(1) and Agent Adapter (1) to build MASs for Release Management (1), and
the most commonly employed design rationale is Reducing the Difficulty
of Task Resolution (1). Reflection mechanism confirms whether the
software is truly ready for release by repeatedly validating its state,
while adapters offer modular, environment-specific integration to the
runtime environment. Furthermore, designers decompose the process of
solving release management tasks into predefined operations, which can
reduce the difficulty of release management task resolution.

5.2 Implications In this section, we provide the implications of this
study based on the results presented in Section 4 and the relationships
among the results of the four RQs discussed in Section 5.1. These
implications are intended to serve as practical guidance for the design
and implementation of LLM-based MASs for SE tasks.

Implication 1. Designers need to place greater emphasis on the quality
of generated software artifacts when designing LLM-based MASs.

Designers of LLM-based MASs place significant emphasis on Functional
Correctness (91.5%), which is the QA most considered by designers of
LLM-based MASs. Functional Correctness directly affects whether the
generated artifacts meet specific needs of users and perform the
intended SE tasks correctly. Therefore, the emphasis on the quality of
generated artifacts should be reflected in the design choices of MASs.
Besides, Improving the Quality of Generated Code (44.7%) is the most
commonly adopted design rationale when constructing MASs for SE tasks.
Code Generation is the SE task most frequently addressed by LLM-based
MASs. Therefore, designers place special emphasis on the quality of the
generated code when designing such MASs. However, as more SE tasks are
being solved by specially constructed MASs, the quality of other types
of artifacts generated by MASs cannot be neglected. As MASs are
increasingly used to produce diverse software artifacts, designers must
ensure that these outputs conform to the expectations of the users. The
generated artifacts should follow the intents of the designers, interact
properly with existing components, and remain understandable for users.
For example, Nguyen et al. \[S5\] proposed an LLM-based MAS named
AGILECODER, which employed a dynamic code graph generator to construct
and maintain a dependency graph that captures relationships among files
and components. The MAS assigns different tasks to distinct roles,
enabling each agent to concentrate on its designated tasks, and uses
sprint-based iterations combined with execution feedback progressively
to remove defects and align the implementation with the acceptance
criteria, thereby improving the quality of the generated code.

Implication 2. Designers could use Role-Based Cooperation to improve the
Maintainability of LLM-based MASs.

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:27

As shown in Figure 4, Modularity is the most frequently considered
sub-QA in Maintainability. Meanwhile, Role-Based Cooperation has been
largely employed to improve the Modularity of MASs. Role-Based
Cooperation can be adopted in LLM-based MASs for SE tasks by allocating
specialized roles to agents, so that each agent implements distinct
working logic, prompt inputs, and tool interfaces based on assigned
roles, which facilitates independent development as well as targeted
testing and updating of individual agents, thereby enhancing Modularity
of MASs. Therefore, Role-Based Cooperation pattern not only improves the
interpretability of MAS design but also significantly enhances the
Maintainability of MASs. For example, Qin et al. \[S4\] proposed an
LLM-based MAS called AGENTFL, which incorporates four agents in
different roles (i.e., Test Code Reviewer, Source Code Reviewer,
Software Architect, and Software Test Engineer) to achieve high
Modularity and Maintainability of the MAS, enabling each agent to
specialize, evolve, and interact in a structured and extensible way.

Implication 3. Designers can draw inspiration from human-centered
software development practices to design their LLM-based MASs.

The study results show that Simulating Human Processes of Solving SE
Tasks (29.8%) is a common design rationale adopted by designers of
LLM-based MASs, which indicates that designers could leverage
human-centered software development methodologies when building
LLM-based MASs for SE tasks. Drawing on human-centered software
development practices, designers can apply established principles of
task decomposition, role specialization, agent coordination, and output
verification to improve the interpretability, verifiability, and
robustness of MASs. Designers may learn from patterns of human
cooperative development and human cognitive processes, such as task
decomposition and error detection strategies, and transform these
patterns into explicit role specialization and hierarchical task
structures. Although many challenges remain, including mismatches
between user expectations and agent capabilities, ambiguities in
communication protocols, and limited methods for validating the results
and quality of interactions among agents, these issues can be addressed
through iterative "human-in-the-loop" evaluation methods and
architectures inspired by human cognitive processes. For example, Lee et
al. \[S2\] designed their LLM-based MAS for software maintenance using a
methodology named Hierarchical Cooperation. They structured multiple
specialized agents into a layered coordination framework, where each
layer addresses faults of increasing complexity through progressively
sophisticated strategies like the human cognitive model of problem
solving. By emulating mature SE activities by human experts, the
complexity of designing LLM-based MASs for SE tasks can be reduced.
Agents are organized into a collaborative development team, where
complex tasks are decomposed into specialized sub-tasks and assigned to
dedicated agents, each of which performs its role, exploits its
strengths, and together drives the software development process in a
manner similar to humans.

Implication 4. Designers are beginning to leverage LLM-based MASs to
support the entire software lifecycle.

The result that End-to-End Software Maintenance (8.4%) and End-to-End
Software Development (7.4%) are addressed by LLM-based MASs suggests
that LLM-based MASs are increasingly adopted to support the entire
software lifecycle. A unified MAS retains contextual knowledge from
require- ments through to the final software products, ensuring that
design decisions, coding conventions, and test criteria remain coherent
across all phases. In our included studies, there are seven papers
proposing LLM-based MASs for End-to-End Software Development and eight
papers focusing on LLM-based MASs for End-to-End Software Maintenance.
The limited numbers of studies employing

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:28 Cai et al.

LLM-based MASs on end-to-end development and maintenance arise from
several factors. First, there is a lack of comprehensive evaluation
criteria that can meaningfully assess system behavior across
requirements engineering, architecture design, implementation, testing,
and maintenance. Without unified metrics, empirical comparison and
validation of generated outputs from each stage become difficult.
Second, standard benchmarks are unavailable for most of development
stages. Although benchmarks for code generation exist and recent
initiatives like DevBench \[20\] have begun to address multiple stages
of the software lifecycle, there is still no widely accepted benchmark
that can evaluate MASs across the entire development lifecycle in a
comprehensive manner. Third, ensuring consistency of generated artifacts
across stages is inherently difficult. Tools optimized for a specific SE
task often generate outputs whose formats or semantics do not match the
expectations of subsequent stages. Despite these obstacles, continued
research and tool development for individual SE tasks are gradually
providing the theoretical foundations and technical elements required
for end-to-end software development, and designers are increasingly
willing to build LLM-based MASs for the entire software lifecycle. For
example, Sami et al. \[S6\] introduced a unified platform that deploys
specialized AI agents tailored to specific SE tasks, includ- ing the
generation of user stories, prioritization of requirements, creation of
UML diagrams, code generation, and automated testing to address the lack
of a cohesive platform capable of delivering consistent and optimal
results across the phases of the development lifecycle.

Implication 5. The rationale for resource-oriented and
efficiency-oriented design reflects the considerations of designers to
minimize time and computational costs when completing relevant SE tasks.

The emphasis on Optimizing Software Resource Management (28.7%) and
Improving the Efficiency of Software Artifact Generation (24.5%)
underscores that designers cannot ignore the considerations of temporal
and spatial costs when designing MASs. Besides, Time Behavior (27) and
Resource Utilization (27) are considered by many designers of LLM-based
MASs. These two sub-QAs of Performance Efficiency have a direct impact
on the practicality and effectiveness of an MAS. Delayed responses from
MASs undermine user experience and can violate real-time needs for
interactive SE tasks, while inefficient resource usage raises
operational costs and may preclude deployment on resource-constrained
hardware. Therefore, designers of LLM-based MASs explore a range of
methods to reduce time and computational costs. For example, Chen et
al. \[S14\] introduced a novel MAS named CODER, which is augmented with
a task graph data structure to systematically resolve GitHub issues
within software repositories. By encoding each debug workflow as a
JSON-formatted task graph, CODER eliminates redundant plan synthesis.
All agents in the MAS follow a strictly executable plan, avoiding
iterative LLM prompts and context reloading that incur response latency
and API costs.

Implication 6. Designers should focus not only on the performance
efficiency of LLM-based MASs but also on their maintainability.

Our results show that 51.1% of LLM-based MASs explicitly consider
Performance Efficiency during design, while 50.0% of designers reported
prioritizing Maintainability. Besides, there are 21 LLM- based MASs
(22.3%) that are constructed under the consideration of both Performance
Efficiency and Maintainability. Considering performance efficiency and
maintainability as simultaneous design objectives for LLM-based MASs
fosters sustained operational efficiency. Designers can trade off
competing QAs in the design of LLM-based MASs by treating role
assignments and coordination strategies as first-class design decisions.
For example, assigning specialized agents with narrow,

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:29

well-defined responsibilities, enables the MAS to satisfy
performance-oriented metrics such as time behavior and resource
utilization for routine cases while reserving more expensive, higher-
assurance procedures for difficult cases (e.g., FixAgent proposed by Lee
et al. \[S2\] for debugging). For example, Shen et al. \[27\] conducted
an empirical study on LLM-based MASs for software development and
proposed an optimization methodology for these MASs using textual
feedback from critic agents. They introduced a role-based cooperation
workflow composed of a planner agent, a developer agent, and a reviewer
agent to improve Modularity (a sub-QA of Maintainability) of the MAS.
They also compared different prompt settings, and found that one-pass
and multi-pass prompting have no apparent performance differences in
generating outputs. However, one-pass prompting consumes fewer API
calls, making it more resource-efficient.

6 Threats on Validity In this section, we outline the potential threats
to the validity of our study. We identify the threats encountered during
the research and clarify the measures we employed to mitigate them.
Internal validity is not discussed, as our study does not involve any
experimental manipulation of variables and thus does not support causal
inference. Construct validity: Since data collection and data extraction
in our study were conducted manually, there is a potential risk of
individual bias in the data extraction results. To mitigate this risk, a
pilot data extraction was conducted before the formal data extraction,
which partially alleviated the threats to the construct validity of the
study. Furthermore, following both the pilot and formal data extraction,
the first author engaged discussions with the second and third authors
to ensure that all of the data items could be extracted from our dataset
and the data extraction results were aligned with four RQs. External
validity: In this study, external validity primarily concerns the
selection of data sources. To ensure the credibility of our data, our
data collection is based on two recent literature surveys on LLM-based
agent systems for SE tasks by Liu et al. \[22\] and Wang et al. \[32\].
To further enhance the comprehensiveness of the dataset, we additionally
included arXiv \[31\] as a data source, which is an open-access preprint
platform maintained by Cornell University and is widely recognized
within the academic community. Besides, arXiv features a dedicated
"Software Engineering" category, which facilitates the identification of
papers relevant to our RQs. Reliability: To mitigate potential
uncertainties associated with the adopted research method- ology, we
implemented several measures to enhance the reliability of the study.
Throughout the processes of data extraction and data analysis, extensive
discussions were held among the first, second, and third authors to
resolve any internal inconsistencies and to ensure the consistency and
accuracy of the results. Moreover, we have made our dataset \[5\]
publicly available to enable other researchers to replicate the study
and validate our findings.

7 Conclusions and Future Work In this study, we focused on the SE tasks
addressed by the specially designed LLM-based MASs, as well as the
quality attributes considered by the designers of LLM-based MASs to
address the SE tasks, the design patterns employed to build LLM-based
MASs for SE tasks, and the design rationale supporting the construction
of LLM-based MASs to facilitate SE tasks. We collected 94 papers that
met our criteria from two recent surveys on LLM-based agent systems for
SE tasks by Liu et al. \[22\] and Wang et al. \[32\], and the SE
category of arXiv \[31\]. The study results show that: Code Generation
is the most common SE task addressed by LLM-based MASs, Functional
Suitability is the QA which is mostly considered by designers of
LLM-based MASs for SE tasks, Role-Based Cooperation is the most
frequently used design pattern to develop LLM-based MASs to support

                                     ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:30 Cai et al.

SE tasks, and Improving the Quality of Generated Code is the most common
rationale behind the design of LLM-based MASs for SE tasks. Based on our
study results, we provide implications for designing LLM-based MASs for
SE tasks. For example, designers could use Role-Based Cooperation to
improve the Maintainability of LLM-based MASs. In addition, designers
can draw inspiration from human-centered software development activities
to design their MASs when developing LLM-based MASs. Moreover, design-
ers are beginning to leverage LLM-based MASs for supporting the entire
software development lifecycle. The rationale behind resource-oriented
and efficiency-oriented designs reflects designers' intent to minimize
temporal and spatial costs when completing relevant SE tasks.

Data Availability The dataset of this work has been made available at
\[5\].

Acknowledgments This work has been partially supported by the National
Natural Science Foundation of China (NSFC) with Grant No. 62402348 and
62172311, and the Major Science and Technology Project of Hubei Province
under Grant No. 2024BAA008.

References \[1\] Divyansh Agarwal, Alexander Fabbri, Ben Risher,
Philippe Laban, Shafiq Joty, and Chien-Sheng Wu. 2024. Prompt Leakage
effect and mitigation strategies for multi-turn LLM Applications. In
Proceedings of the 29th Conference on Empirical Methods in Natural
Language Processing (EMNLP). ACL, 1255--1275. \[2\] Chetan Arora, John
Grundy, and Mohamed Abdelrazek. 2023. Advancing Requirements Engineering
through Generative AI: Assessing the Role of LLMs. arXiv preprint
arXiv:2310.13976 (2023). \[3\] Jacob Austin, Augustus Odena, Maxwell
Nye, Maarten Bosma, Henryk Michalewski, David Dohan, Ellen Jiang, Carrie
Cai, Michael Terry, Quoc Le, and Charles Sutton. 2021. Program Synthesis
with Large Language Models. arXiv preprint arXiv:2108.07732 (2021).
\[4\] Islem Bouzenia and Michael Pradel. 2025. Understanding Software
Engineering Agents: A Study of Thought-Action- Result Trajectories.
arXiv preprint arXiv:2506.18824 (2025). \[5\] Yangxiao Cai, Ruiyin Li,
Peng Liang, Mojtaba Shahin, and Zengyang Li. 2025. Dataset of the Paper
"Designing LLM-based Multi-Agent Systems for Software Engineering Tasks:
Quality Attributes, Design Patterns and Rationale".
https://github.com/Caiyangxiao/MASDesign. \[6\] Mert Cemri, Melissa Z.
Pan, Shuyi Yang, Lakshya A. Agrawal, Bhavya Chopra, Rishabh Tiwari, Kurt
Keutzer, Aditya Parameswaran, Dan Klein, Kannan Ramchandran, Matei
Zaharia, Joseph E. Gonzalez, and Ion Stoica. 2025. Why Do Multi-Agent
LLM Systems Fail? arXiv preprint arXiv:2503.13657 (2025). \[7\]
Shuaihang Chen, Yuanxing Liu, Wei Han, Weinan Zhang, and Ting Liu. 2024.
A Survey on LLM-based Multi-Agent System: Recent Advances and New
Frontiers in Application. arXiv preprint arXiv:2412.17481 (2024). \[8\]
Weize Chen, Yusheng Su, Jingwei Zuo, Cheng Yang, Chenfei Yuan, Chi-Min
Chan, Heyang Yu, Yaxi Lu, Yi-Hsin Hung, Chen Qian, Yujia Qin, Xin Cong,
Ruobing Xie, Zhiyuan Liu, Maosong Sun, and Jie Zhou. 2024. AgentVerse:
Facilitating Multi-Agent Collaboration and Exploring Emergent Behaviors.
In Proceedings of the 12th International Conference on Learning
Representations (ICLR). ICLR, 1--43. \[9\] Yihong Dong, Xue Jiang, Zhi
Jin, and Ge Li. 2024. Self-Collaboration Code Generation via ChatGPT.
ACM Transactions on Software Engineering and Methodology 33, 7 (2024),
1--38. \[10\] Ali Dorri, Salil S. Kanhere, and Raja Jurdak. 2018.
Multi-Agent Systems: A Survey. IEEE Access 6 (2018), 28573--28593.
\[11\] Taicheng Guo, Xiuying Chen, Yaqi Wang, Ruidi Chang, Shichao Pei,
Nitesh V. Chawla, Olaf Wiest, and Xiangliang Zhang. 2024. Large Language
Model Based Multi-agents: A Survey of Progress and Challenges. In
Proceedings of the 33rd International Joint Conference on Artificial
Intelligence (IJCAI). IJCAI, 8048--8057. \[12\] Amine Ben Hassouna, Hana
Chaari, and Ines Belhaj. 2026. LLM-Agent-UMF: LLM-based Agent Unified
Modeling Framework for Seamless Design of Multi Active/Passive
Core-Agent Architectures. Information Fusion 127 (2026), 103865. \[13\]
Junda He, Christoph Treude, and David Lo. 2025. LLM-Based Multi-Agent
Systems for Software Engineering: Literature Review, Vision and the Road
Ahead. ACM Transactions on Software Engineering and Methodology 34, 5
(2025), Article No.: 124.

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:31

\[14\] Sirui Hong, Mingchen Zhuge, Jiaqi Chen, Xiawu Zheng, Yuheng
Cheng, Ceyao Zhang, Jinlin Wang, Zili Wang, Steven Ka Shing Yau, Zijuan
Lin, Liyang Zhou, Chenyu Ran, Lingfeng Xiao, Chenglin Wu, and Jürgen
Schmidhuber. 2023. MetaGPT: Meta Programming for A Multi-Agent
Collaborative Framework. arXiv preprint arXiv:2308.00352 (2023). \[15\]
Jie Huang and Kevin Chen-Chuan Chang. 2023. Towards Reasoning in Large
Language Models: A Survey. In Proceedings of the 61st Annual Meeting of
the Association for Computational Linguistics (ACL). ACL, 1049--1065.
\[16\] International Organization for Standardization and International
Electrotechnical Commission. 2023. ISO/IEC 25010:2023 Systems and
software engineering -- Systems and software Quality Requirements and
Evaluation (SQuaRE) -- System and software quality models. Technical
Report ISO/IEC 25010:2023. ISO/IEC, Geneva, Switzerland. \[17\] Dongming
Jin, Zhi Jin, Xiaohong Chen, and Chunhui Wang. 2024. MARE: Multi-Agents
Collaboration Framework for Requirements Engineering. arXiv preprint
arXiv:2405.03256 (2024). \[18\] R. Kazman, M. Klein, M. Barbacci, T.
Longstaff, H. Lipson, and J. Carriere. 1998. The architecture tradeoff
analysis method. In Proceedings of the 4th IEEE International Conference
on Engineering of Complex Computer Systems (ICECCS). 68--78. \[19\] Hui
Yi Leong, Yuheng Li, Yuqing Wu, Wenwen Ouyang, Wei Zhu, Jiechao Gao, and
Wei Han. 2025. AMAS: Adaptively Determining Communication Topology for
LLM-based Multi-agent System. In Proceedings of the 30th Conference on
Empirical Methods in Natural Language Processing: Industry Track
(EMNLP). ACL, 2061--2070. \[20\] Bowen Li, Wenhan Wu, Ziwei Tang, Lin
Shi, John Yang, Jinyang Li, Shunyu Yao, Chen Qian, Binyuan Hui, Qicheng
Zhang, et al. 2024. DevBench: A Comprehensive Benchmark for Software
Development. arXiv preprint arXiv:2403.08604 (2024). \[21\] Ruiyin Li,
Yiran Zhang, Xiyu Zhou, Peng Liang, Weisong Sun, Jifeng Xuan, Zhi Jin,
and Yang Liu. 2025. MAAD: Automate Software Architecture Design through
Knowledge-Driven Multi-Agent Collaboration. arXiv preprint
arXiv:2507.21382 (2025). \[22\] Junwei Liu, Kaixin Wang, Yixuan Chen,
Xin Peng, Zhenpeng Chen, Lingming Zhang, and Yiling Lou. 2024. Large
Language Model-Based Agents for Software Engineering: A Survey. arXiv
preprint arXiv:2409.02977 (2024). \[23\] Yue Liu, Sin Kit Lo, Qinghua
Lu, Liming Zhu, Dehai Zhao, Xiwei Xu, Stefan Harrer, and Jon Whittle.
2025. Agent Design Pattern Catalogue: A Collection of Architectural
Patterns for Foundation Model based Agents. Journal of Systems and
Software 220 (2025), 112278. \[24\] Ruwei Pan, Hongyu Zhang, and Chao
Liu. 2025. CodeCoR: An LLM-Based Self-Reflective Multi-Agent Framework
for Code Generation. arXiv preprint arXiv:2501.07811 (2025). \[25\] Chen
Qian, Wei Liu, Hongzhang Liu, Nuo Chen, Yufan Dang, Jiahao Li, Cheng
Yang, Weize Chen, Yusheng Su, Xin Cong, Juyuan Xu, Dahai Li, Zhiyuan
Liu, and Maosong Sun. 2024. ChatDev: Communicative Agents for Software
Development. In Proceedings of the 62nd Annual Meeting of the
Association for Computational Linguistics (ACL). ACL, 15174--15186.
\[26\] Anjana Sarkar and Soumyendu Sarkar. 2025. Survey of LLM Agent
Communication with MCP: A Software Design Pattern Centric Review. arXiv
preprint arXiv:2506.05364 (2025). \[27\] Ming Shen, Raphael Shu, Anurag
Pratik, James Gung, Yubin Ge, Monica Sunkara, and Yi Zhang. 2025.
Optimizing LLM-Based Multi-Agent System with Textual Feedback: A Case
Study on Software Development. arXiv preprint arXiv:2505.16086 (2025).
\[28\] Wentao Shi, Xiangnan He, Yang Zhang, Chongming Gao, Xinyue Li,
Jizhi Zhang, Qifan Wang, and Fuli Feng. 2024. Large Language Models are
Learnable Planners for Long-Term Recommendation. In Proceedings of the
47th International ACM SIGIR Conference on Research and Development in
Information Retrieval (SIGIR). ACM. \[29\] Linke Song, Zixuan Pang,
Wenhao Wang, Zihao Wang, Xiaofeng Wang, Hongbo Chen, Wei Song, Yier Jin,
Dan Meng, and Rui Hou. 2024. The Early Bird Catches the Leak: Unveiling
Timing Side Channels in LLM Serving Systems. IEEE Transactions on
Information Forensics and Security 20 (2024), 11431--11446. \[30\]
Klaas-Jan Stol, Paul Ralph, and Brian Fitzgerald. 2016. Grounded theory
in software engineering research: a critical review and guidelines. In
Proceedings of the 38th International Conference on Software Engineering
(ICSE). ACM, 120--131. \[31\] Cornell University. 2025. arXiv.
https://arxiv.org/list/cs.SE/recent. \[32\] Yanlin Wang, Wanjun Zhong,
Yanxian Huang, Ensheng Shi, Min Yang, Jiachi Chen, Hui Li, Yuchi Ma,
Qianxiang Wang, and Zibin Zheng. 2025. Agents in Software Engineering:
Survey, Landscape, and Vision. Automated Software Engineering 32 (2025),
Article No.: 70. \[33\] Bingyu Yan, Zhibo Zhou, Litian Zhang, Lian
Zhang, Ziyi Zhou, Dezhuang Miao, Zhoujun Li, Chaozhuo Li, and Xiaoming
Zhang. 2025. Beyond Self-Talk: A Communication-Centric Survey of
LLM-Based Multi-Agent Systems. arXiv preprint arXiv:2502.14321 (2025).
\[34\] Miao Yu, Fanci Meng, Xinyun Zhou, Shilong Wang, Junyuan Mao,
Linsey Pang, Tianlong Chen, Kun Wang, Xinfeng Li, Yongfeng Zhang, Bo An,
and Qingsong Wen. 2025. A Survey on Trustworthy LLM Agents: Threats and
Countermeasures. arXiv preprint arXiv:2503.09648 (2025).

                                        ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:32 Cai et al.

\[35\] Zhiqiang Yuan, Weitong Chen, Hanlin Wang, Kai Yu, Xin Peng, and
Yiling Lou. 2024. TRANSAGENT: An LLM-Based Multi-Agent System for Code
Translation. arXiv preprint arXiv:2409.19894 (2024).

A Included Studies Table 7. List of the included studies in this work

ID Author, Publication Title, and Venue Sarah Fakhoury, Markus Kuppe,
Shuvendu K. Lahiri, Tahina Ramananandro, Nikhil Swamy. 3DGen:
AI-Assisted Generation \[S1\] of Provably Correct Binary Format Parsers.
arXiv preprint arXiv:2404.10362 Cheryl Lee, Chunqiu Steven Xia, Longji
Yang, Jen-tse Huang, Zhouruixin Zhu, Lingming Zhang, Michael R. Lyu.
FixAgent: \[S2\] Hierarchical Multi-Agent Framework for Unified Software
Debugging . arXiv preprint arXiv:2404.17153 Lyuye Zhang, Kaixuan Li,
Kairan Sun, Daoyuan Wu, Ye Liu, Haoye Tian, Yang Liu. ACFIX: Guiding
LLMs with Mined \[S3\] Common RBAC Practices for Context-Aware Repair of
Access Control Vulnerabilities in Smart Contracts. arXiv preprint
arXiv:2403.06838 Yihao Qin, Shangwen Wang, Yiling Lou, Jinhao Dong,
Kaixin Wang, Xiaoling Li, Xiaoguang Mao. AGENTFL: Scaling LLM- \[S4\]
based Fault Localization to Project-Level Context. arXiv preprint
arXiv:2403.16362 Minh Huynh Nguyen, Thang Phan Chau, Phong X. Nguyen,
Nghi D. Q. Bui. AgileCoder: Dynamic Collaborative Agents for \[S5\]
Software Development based on Agile Methodology. arXiv preprint
arXiv:2406.11912 Zeeshan Rasheed, Malik Abdul Sami, Muhammad Waseem,
Kai-Kristian Kemell, Xiaofeng Wang, Anh Nguyen, Kari Systä, Pekka \[S6\]
Abrahamsson. AI-powered Code Review with LLMs: Early Results. arXiv
preprint arXiv:2404.18496 Bin Lei, Yuchen Li, Qiuwu Chen. AutoCoder:
Enhancing Code Large Language Model with AIEV-INSTRUCT. arXiv \[S7\]
preprint arXiv:2405.14906 Yuntong Zhang, Haifeng Ruan, Zhiyu Fan, Abhik
Roychoudhury. AutoCodeRover: Autonomous Program Improvement. In \[S8\]
Proceedings of the 33rd ACM SIGSOFT International Symposium on Software
Testing and Analysis (ISSTA), ACM, 1592 - 1604. Michele Tufano, Anisha
Agarwal, Jinu Jang, Roshanak Zilouchian Moghaddam, Neel Sundaresan.
AutoDev: Automated \[S9\] AI-Driven Development. arXiv preprint
arXiv:2403.08299. Chenyuan Yang, Xuheng Li, Md Rakib Hossain Misu,
Jianan Yao, Weidong Cui, Yeyun Gong, Chris Hawblitzel, Shuvendu Lahiri,
\[S10\] Jacob R. Lorch, Shuai Lu, Fan Yang, Ziqiao Zhou, Shan Lu.
AutoVerus: Automated Proof Generation for Rust Code. arXiv preprint
arXiv:2409.13082. Sanjiban Choudhury, Paloma Sodhi. Better than Your
Teacher: LLM Agents that learn from Privileged AI Feedback. arXiv
preprint \[S11\] arXiv:2410.05434 Kechi Zhang, Jia Li, Ge Li, Xianjie
Shi, Zhi Jin. CodeAgent: Enhancing Code Generation with Tool-Integrated
Agent \[S12\] Systems for Real-World Repo-level Coding Challenges. In
Proceedings of the 62nd Annual Meeting of the Association for
Computational Linguistics (ACL), ACL, 13643 - 13658 Zeeshan Rasheed,
Malik Abdul Sami, Kai-Kristian Kemell, Muhammad Waseem, Mika Saari, Kari
Systä, Pekka Abrahams- \[S13\] son. CodePori: Large Scale Model for
Autonomous Software Development by Using Multi-Agents. arXiv preprint
arXiv:2402.01411 Dong Chen, Shaoxin Lin, Muhan Zeng, Daoguang Zan,
Jian-Gang Wang, Anton Cheshkov, Jun Sun, Hao Yu, Guoliang Dong, \[S14\]
Artem Aliev, Jie Wang, Xiao Cheng, Guangtai Liang, Yuchi Ma, Pan Bian,
Tao Xie, Qianxiang Wang. CODER: ISSUE RESOLVING WITH MULTI-AGENT AND
TASK GRAPHS. arXiv preprint arXiv:2406.01304 Daoguang Zan, Ailun Yu, Wei
Liu, Dong Chen, Bo Shen, Wei Li, Yafen Yao, Yongshun Gong, Xiaolin Chen,
Bei Guan, Zhiguang \[S15\] Yang, Yongji Wang, Qianxiang Wang, Lizhen
Cui. CodeS: Natural Language to Code Repository via Multi-Layer Sketch.
arXiv preprint arXiv:2403.16443 Wei Ma, Daoyuan Wu, Yuqiang Sun, Tianwen
Wang, Shangqing Liu, Jian Zhang, Yue Xue, Yang Liu. Combining
Fine-tuning \[S16\] and LLM-based Agents for Intuitive Smart Contract
Auditing with Justifications. arXiv preprint arXiv:2403.16073 Kexun
Zhang, Weiran Yao, Zuxin Liu, Yihao Feng, Zhiwei Liu, Rithesh Murthy,
Tian Lan, Lei Li, Renze Lou, Jiacheng \[S17\] Xu, Bo Pang, Yingbo Zhou,
Shelby Heinecke, Silvio Savarese, Huan Wang, Caiming Xiong. DIVERSITY
EMPOWERS INTELLIGENCE:INTEGRAT-ING EXPERTISE OF SOFTWARE ENGINEERING
AGENTS. arXiv preprint arXiv:2408.07060 Mohammadmehdi Ataei, Hyunmin
Cheong, Daniele Grandi, Ye Wang, Nigel Morris, Alexander Tessier.
Elicitron: An LLM \[S18\] Agent-Based Simulation Framework for Design
Requirements Elicitation. arXiv preprint arXiv:2404.16045 Md Nakhla
Rafi, Dong Jae Kim, Tse-Hsun Chen, Shaowei Wang. Enhancing Fault
Localization Through Ordered Code \[S19\] Analysis with LLM Agents and
Self-Reflection. arXiv preprint arXiv:2409.13642 Simiao Zhang, Jiaping
Wang, Guoliang Dong, Jun Sun, Yueling Zhang, Geguang Pu. Experimenting a
New Programming \[S20\] Practice with LLMs. arXiv preprint
arXiv:2401.01062 Malik Abdul Sami, Muhammad Waseem, Zeeshan Rasheed,
Mika Saari, Kari Systä, Pekka Abrahamsson. Experimenting with \[S21\]
Multi-Agent Software Development: Towards a Unified Platform. arXiv
preprint arXiv:2406.05381 Arsham Gholamzadeh Khoee, Yinan Yu, Robert
Feldt, Andris Freimanis, Patrick Andersson Rhodin, Dhasarathy
Parthasarathy. \[S22\] GoNoGo: An Efficient LLM-based Multi-Agent System
for Streamlining Automotive Software Release Decision- Making. arXiv
preprint arXiv:2408.09785 Yingwei Ma, Qingping Yang, Rongyu Cao, Binhua
Li, Fei Huang, Yongbin Li. How to Understand Whole Software Repository?.
\[S23\] arXiv preprint arXiv:2406.01422 Chen Qian, Jiahao Li, Yufan
Dang, Wei Liu, YiFei Wang, Zihao Xie, Weize Chen, Cheng Yang, Yingli
Zhang, Zhiyuan Liu, \[S24\] Maosong Sun. Iterative Experience Refinement
of Software-Developing Agents. arXiv preprint arXiv:2405.04219 Richard
Fang, Rohan Bindu, Akul Gupta, Daniel Kang. LLM Agents can Autonomously
Exploit One-day Vulnerabilities. \[S25\] arXiv preprint arXiv:2404.08144
Zhiyuan Wei, Jing Sun, Zijiang Zhang, Xianhao Zhang. LLM-SmartAudit:
Advanced Smart Contract Vulnerability \[S26\] Detection. arXiv preprint
arXiv:2410.09381

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:33

ID Author, Publication Title, and Venue Mohamad Fakih, Rahul Dharmaji,
Yasamin Moghaddas, Gustavo Quiros Araya, Oluwatosin Ogundare, Mohammad
Abdullah Al Faruque. LLM4PLC: Harnessing Large Language Models for
Verifiable Programming of PLCs in Industrial Control \[S27\] Systems. In
Proceedings of the 46th International Conference on Software
Engineering: Software Engineering in Practice (ICSE-SEIP), 192 - 203 Wei
Tao, Yucheng Zhou, Yanlin Wang, Wenqiang Zhang, Hongyu Zhang, Yu Cheng.
MAGIS: LLM-Based Multi-Agent \[S28\] Framework for GitHub Issue
ReSolution. arXiv preprint arXiv:2403.17927 Md. Ashraful Islam, Mohammed
Eunus Ali, Md Rizwan Parvez. MapCoder: Multi-Agent Code Generation for
Competitive \[S29\] Problem Solving. In Proceedings of the 62nd Annual
Meeting of the Association for Computational Linguistics (ACL), 4912 -
4944 Dongming Jin, Zhi Jin, Xiaohong Chen, Chunhui Wang. MARE:
Multi-Agents Collaboration Framework for Requirements \[S30\]
Engineering. arXiv preprint arXiv:2405.03256 Yizhou Liu, Pengfei Gao,
Xinchen Wang, Jie Liu, Yexuan Shi, Zhao Zhang, Chao Peng. MarsCode
Agent: AI-native Automated \[S31\] Bug Fixing. arXiv preprint
arXiv:2409.00899 Daman Arora, Atharv Sonwane, Nalin Wadhwa, Abhav
Mehrotra, Saiteja Utpala, Ramakrishna Bairi, Aditya Kanade, Nagarajan
\[S32\] Natarajan. MASAI: Modular Architecture for Software-engineering
AI Agents. arXiv preprint arXiv:2406.11638 \[S33\] Junyou Li, Qin Zhang,
Yangbin Yu, Qiang Fu, Deheng Ye. More Agents Is All You Need. arXiv
preprint arXiv:2402.05120 Zhuoyun Du, Chen Qian, Wei Liu, Zihao Xie,
Yifei Wang, Yufan Dang, Weize Chen, Cheng Yang. Multi-Agent Software
\[S34\] Development through Cross-Team Collaboration. arXiv preprint
arXiv:2406.08979 Zhenyu Mao, Jialong Li, Dongming Jin, Munan Li, Kenji
Tei. Multi-role Consensus through LLMs Discussions for Vulner- \[S35\]
ability Detection. arXiv preprint arXiv:2403.14274 Haolin Jin, Zechao
Sun, Huaming Chen. RGD: Multi-LLM Based Agent Debugger via Refinement
and Generation \[S36\] Guidance. arXiv preprint arXiv:2410.01242 Chen
Qian, Zihao Xie, Yifei Wang, Wei Liu, Yufan Dang, Zhuoyun Du, Weize
Chen, Cheng Yang, Zhiyuan Liu, Maosong Sun. \[S37\] Scaling
Large-Language-Model-based Multi-Agent Collaboration. arXiv preprint
arXiv:2406.07155 Yoichi Ishibashi, Yoshimasa Nishimura. Self-Organized
Agents: A LLM Multi-Agent Framework toward Ultra Large-Scale \[S38\]
Code Generation and Optimization. arXiv preprint arXiv:2404.02183
Haifeng Ruan, Yuntong Zhang, Abhik Roychoudhury. SpecRover: Code Intent
Extraction via LLMs. arXiv preprint \[S39\] arXiv:2408.02232 John Yang,
Carlos E. Jimenez, Alexander Wettig, Kilian Lieret, Shunyu Yao, Karthik
Narasimhan, Ofir Press. SWE- \[S40\] AGENT: AGENT-COMPUTER INTERFACES
ENABLE AUTOMATED SOFTWARE ENGINEERING. arXiv preprint arXiv:2405.15793
\[S41\] Noble Saji Mathews, Meiyappan Nagappan. Test-Driven Development
for Code Generation. arXiv preprint arXiv:2402.13521 Feng Lin, Dong Jae
Kim, Tse-Husn (Peter)Chen. When LLM-based Code Generation Meets the
Software Development \[S42\] Process. arXiv preprint arXiv:2403.15852
Zhitao Wang, Wei Wang, Zirao Li, Long Wang, Can Yi, Xinjie Xu, Luyang
Cao, Hanjing Su, Shouzhi Chen, Jun Zhou. XUAT- \[S43\] Copilot:
Multi-Agent Collaborative System for Automated User Acceptance Testing
with Large Language Model. arXiv preprint arXiv:2401.02705 Xunzhu Tang,
Kisub Kim, Yewei Song, Cedric Lothritz, Bei Li, Saad Ezzini, Haoye Tian,
Jacques Klein, Tegawende F. Bissyande. \[S44\] CodeAgent: Autonomous
Communicative Agents for Code Review. In Proceedings of the 2024
Conference on Empirical Methods in Natural Language Processing (EMNLP),
11279 - 11313. Dawen Zhang, Xiwei Xu, Chen Wang, Zhenchang Xing, Robert
Mao. A Layered Architecture for Developing and Enhancing \[S45\]
Capabilities in Large Language Model-based Software Systems. arXiv
preprint arXiv:2411.12357 Sai Zhang, Zhenchang Xing, Ronghui Guo,
Fangzhou Xu, Lei Chen, Zhaoyuan Zhang, Xiaowang Zhang, Zhiyong Feng,
\[S46\] Zhiqiang Zhuang. Empowering Agile-Based Generative Software
Development through Human-AI Teamwork. ACM Transactions on Software
Engineering and Methodology, Volume 34, Issue 6, 1 - 46. Juyeon Yoon;
Robert Feldt; Shin Yoo. Intent-Driven Mobile GUI Testing with Autonomous
Large Language Model Agents. \[S47\] In Proceedings of the 17th IEEE
International Conference on Software Testing, Verification & Validation
(ICST), 129 - 139. Mohammadmehdi Ataei, Hyunmin Cheong, Daniele Grandi,
Ye Wang, Nigel Morris, Alexander Tessier. Elicitron: An LLM \[S48\]
Agent-Based Simulation Framework for Design Requirements Elicitation.
arXiv preprint arXiv:2404.16045 Zhe Liu, Cheng Li, Chunyang Chen, Junjie
Wang, Boyu Wu, Yawen Wang, Jun Hu, Qing Wang. Vision-driven Automated
\[S49\] Mobile GUI Testing via Multimodal Large Language Model. arXiv
preprint arXiv:2407.03037 Jiahong Xiang, Xiaoyang Xu, Fanchu Kong,
Mingyuan Wu, Zizheng Zhang, Haotian Zhang, Yuqun Zhang. How Far Can We
\[S50\] Go with Practical Function-Level Program Repair?. arXiv preprint
arXiv:2404.12833 Zixiao Zhao, Jing Sun, Zhiyuan Wei, Cheng-Hao Cai, Zhe
Hou, Jin Song Dong. VisionCoder: Empowering Multi-Agent \[S51\]
Auto-Programming for Image Processing with Hybrid LLMs. arXiv preprint
arXiv:2410.19245 Ahmed R. Sadik, Sebastian Brulin, Markus Olhofer,
Antonello Ceravola, Frank Joublin. LLM as a code generator in Agile
\[S52\] Model Driven Development. arXiv preprint arXiv:2410.18489 Yue
Hu, Yuzhu Cai, Yaxin Du, Xinyu Zhu, Xiangrui Liu, Zijie Yu, Yuchen Hou,
Shuo Tang, Siheng Chen. Self-Evolving Multi- \[S53\] Agent Collaboration
Networks for Software Development. arXiv preprint arXiv:2410.16946 Zihan
Liu, Ruinan Zeng, Dongxia Wang, Gengyun Peng, Jingyi Wang, Qiang Liu,
Peiyu Liu, Wenhai Wang. Agents4PLC: \[S54\] Automating Closed-loop PLC
Code Generation and Verification in Industrial Control Systems using
LLM-based Agents. arXiv preprint arXiv:2410.14209 Xuanming Zhang, Yuxuan
Chen, Yuan Yuan, Minlie Huang. Seeker: Enhancing Exception Handling in
Code with LLM- \[S55\] based Multi-Agent Approach. arXiv preprint
arXiv:2410.06949 Zhiqiang Yuan, Weitong Chen, Hanlin Wang, Kai Yu, Xin
Peng, Yiling Lou. TRANSAGENT: An LLM-Based Multi-Agent \[S56\] System
for Code Translation. arXiv preprint arXiv:2409.19894 Leilei Lin,
Yingming Zhou, Wenlong Chen, Chen Qian. Think-on-Process: Dynamic
Process Generation for Collaborative \[S57\] Development of Multi-Agent
System. arXiv preprint arXiv:2409.06568

                                         ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.

0:34 Cai et al.

ID Author, Publication Title, and Venue Huan Zhang, Wei Cheng, Yuhan Wu,
Wei Hu. A Pair Programming Framework for Code Generation via Multi-Plan
\[S58\] Exploration and Feedback-Driven Refinement. In Proceedings of
the 39th IEEE/ACM International Conference on Automated Software
Engineering (ASE), 1319 - 1331. Weiqing Yang, Hanbin Wang, Zhenghao Liu,
Xinze Li, Yukun Yan, Shuo Wang, Yu Gu, Minghe Yu, Zhiyuan Liu, Ge Yu.
\[S59\] Enhancing the Code Debugging Ability of LLMs via Communicative
Agent Based Data Refinement. arXiv preprint arXiv:2408.05006 Forough
Mehralian, Titus Barik, Jeff Nichols, Amanda Swearngin. Automated Code
Fix Suggestions for Accessibility Issues \[S60\] in Mobile Apps. arXiv
preprint arXiv:2408.03827 Dong Huang, Jie M.Zhang, Michael Luck, Qingwen
Bu, Yuhao Qing, Heming Cui. AgentCoder: Multi-Agent Code Generation
\[S61\] with Effective Testing and Self-optimisation. arXiv preprint
arXiv:2312.13010 Weize Chen, Yusheng Su, Jingwei Zuo, Cheng Yang,
Chenfei Yuan, Chi-Min Chan, Heyang Yu, Yaxi Lu, Yi-Hsin Hung, Chen Qian,
\[S62\] Yujia Qin, Xin Cong, Ruobing Xie, Zhiyuan Liu, Maosong Sun, Jie
Zhou. AgentVerse: Facilitating Multi-Agent Collaboration and Exploring
Emergent Behaviors. In Proceedings of 17th International Conference on
Learning Representations (ICLR). Guangyao Chen, Siwei Dong, Yu Shu, Ge
Zhang, Jaward Sesay, Börje F. Karlsson, Jie Fu, Yemin Shi. AutoAgents: A
Framework \[S63\] for Automatic Agent Generation. arXiv preprint
arXiv:2309.17288 Qingyun Wu, Gagan Bansal, Jieyu Zhang, Yiran Wu, Beibin
Li, Erkang Zhu, Li Jiang, Xiaoyun Zhang, Shaokun Zhang, Jiale Liu,
\[S64\] Ahmed Hassan Awadallah, Ryen W White, Doug Burger, Chi Wang.
AutoGen: Enabling Next-Gen LLM Applications via Multi-Agent
Conversation. arXiv preprint arXiv:2308.08155 Zeeshan Rasheed, Muhammad
Waseem, Kai-Kristian Kemell, Wang Xiaofeng, Anh Nguyen Duc, Kari Systä,
Pekka Abrahamsson. \[S65\] Autonomous Agents in Software Development: A
Vision Paper. arXiv preprint arXiv:2311.18440 Maryam Taeb, Amanda
Swearngin, Eldon Schoop, Ruijia Cheng, Yue Jiang, Jeffrey Nichols.
AXNav: Replaying Accessibility \[S66\] Tests from Natural Language. In
Proceedings of the 2024 CHI Conference on Human Factors in Computing
Systems (CHI), 1 - 16. Guohao Li, Hasan Abed Al Kader Hammoud, Hani
Itani, Dmitrii Khizbullin, Bernard Ghanem. CAMEL: communicative \[S67\]
agents for "mind" exploration of large language model society. In
Proceedings of the 37th International Conference on Neural Information
Processing Systems (NeurIPS), 51991 - 52008 Guang Yang, Yu Zhou, Xiang
Chen, Xiangyu Zhang, Terry Yue Zhuo, Taolue Chen. Chain-of-Thought in
Neural Code \[S68\] Generation: From and For Lightweight Language
Models. IEEE Transactions on Software Engineering, Volume 50, Issue 9,
2437 - 2457. Seungjun Moon, Hyungjoo Chae, Yongho Song, Taeyoon Kwon,
Dongjin Kang, Kai Tzu-iunn Ong, Seung-won Hwang, Jinyoung \[S69\] Yeo.
Coffee: Boost Your Code LLMs by Fixing Bugs with Feedback. arXiv
preprint arXiv:2307.07924 Nalin Wadhwa, Jui Pradhan, Atharv Sonwane,
Surya Prakash Sahu, Nagarajan Natarajan, Aditya Kanade, Suresh
Parthasarathy, \[S70\] Sriram Rajamani. CORE: Resolving Code Quality
Issues using LLMs. In Proceedings of the 31th ACM on Software
Engineering (FSE), 789 - 811. Zijun Liu, Yanzhe Zhang, Peng Li, Yang
Liu, Diyi Yang. A Dynamic LLM-Agent Network: An LLM-agent Collaboration
\[S71\] Framework with Agent Team Optimization. arXiv preprint
arXiv:2310.02170. Yu Hao, Weiteng Chen, Ziqiao Zhou, Weidong Cui. E&V:
Prompting Large Language Models to Perform Static Analysis \[S72\] by
Pseudo-code Execution and Verification. arXiv preprint arXiv:2312.08477
Chen Qian, Yufan Dang, Jiahao Li, Wei Liu, Zihao Xie, Yifei Wang, Weize
Chen, Cheng Yang, Xin Cong, Xiaoyin Che, Zhiyuan \[S73\] Liu, Maosong
Sun. Experiential Co-Learning of Software-Developing Agents. In
Proceedings of the 62nd Annual Meeting of the Association for
Computational Linguistics (ACL), 5628 - 5640 Martin Josifoski, Lars
Klein, Maxime Peyrard, Nicolas Baldwin, Yifei Li, Saibo Geng, Julian
Paul Schnitzler, Yuxing Yao, Jiheng \[S74\] Wei, Debjit Paul, Robert
West. Flows: Building Blocks of Reasoning and Collaborating AI. arXiv
preprint arXiv:2308.01285 Chunqiu Steven Xia, Matteo Paltenghi, Jia Le
Tian, Michael Pradel, Lingming Zhang. Fuzz4All: Universal Fuzzing with
Large \[S75\] Language Models. In Proceedings of the IEEE/ACM 46th
International Conference on Software Engineering (ICSE), 1 - 13. Binfeng
Xu, Xukun Liu, Hua Shen, Zeyu Han, Yuhan Li, Murong Yue, Zhiyuan Peng,
Yuchen Liu, Ziyu Yao, Dongkuan Xu. \[S76\] Gentopia.AI: A Collaborative
Platform for Tool-Augmented LLMs. In Proceedings of the 2023 Conference
on Empirical Methods in Natural Language Processing: System
Demonstrations (EMNLP), 237 - 245. Zhou Yang, Zhipeng Zhao, Chenyu Wang,
Jieke Shi, Dongsum Kim, Donggyun Han, David Lo. Gotcha! This Model Uses
My \[S77\] Code! Evaluating Membership Leakage Risks in Code Models.
arXiv preprint arXiv:2310.01166 Hanbin Wang, Zhenghao Liu, Shuo Wang,
Ganqu Cui, Ning Ding, Zhiyuan Liu, Ge Yu. INTERVENOR: Prompting the
Coding \[S78\] Ability of Large Language Models with the Interactive
Chain of Repair. In Proceedings of the 62nd Findings of the Association
for Computational Linguistics (ACL), 2081 - 2107. Yiheng Xu, Hongjin Su,
Chen Xing, Boyu Mi, Qian Liu, Weijia Shi, Binyuan Hui, Fan Zhou, Yitao
Liu, Tianbao Xie, Zhoujun \[S79\] Cheng, Siheng Zhao, Lingpeng Kong,
Bailin Wang, Caiming Xiong, Tao Yu. Lemur: Harmonizing Natural Language
and Code for Language Agents. In Proceedings of the 12th International
Conference on Representation Learning (ICLR). Zhe Liu, Chunyang Chen,
Junjie Wang, Mengzhuo Chen, Boyu Wu, Xing Che, Dandan Wang, Qing Wang.
Make LLM a Testing \[S80\] Expert: Bringing Human-like Interaction to
Mobile GUI Testing via Functionality-aware Decisions. In Proceedings of
the IEEE/ACM 46th International Conference on Software Engineering
(ICSE), 1 - 13. Sirui Hong, Mingchen Zhuge, Jonathan Chen, Xiawu Zheng,
Yuheng Cheng, Ceyao Zhang, Jinlin Wang, Zili Wang, Steven \[S81\] Ka
Shing Yau, Zijuan Lin, Liyang Zhou, Chenyu Ran, Lingfeng Xiao, Chenglin
Wu, Jürgen Schmidhuber. MetaGPT: Meta Programming for A Multi-Agent
Collaborative Framework. arXiv preprint arXiv:2308.00352. Yashar
Talebirad, Amirhossein Nadiri. Multi-Agent Collaboration: Harnessing the
Power of Intelligent LLM Agents. \[S82\] arXiv preprint
arXiv:2306.03314. Eric Zelikman, Qian Huang, Gabriel Poesia, Noah D.
Goodman, Nick Haber. Parsel: Algorithmic Reasoning with Language \[S83\]
Models by Composing Decompositions. In Proceedings of 37th Conference on
Neural Information Processing Systems (NeurIPS). Zhenchang Xing, Qing
Huang, Yu Cheng, Liming Zhu, Qinghua Lu, Xiwei Xu. Prompt Sapper:
LLM-Empowered Software \[S84\] Engineering Infrastructure for AI-Native
Services. arXiv preprint arXiv:2306.02230

ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication
date: 2025. Designing LLM-based Multi-Agent Systems for SE Tasks:
Quality Attributes, Design Patterns and Rationale 0:35

ID Author, Publication Title, and Venue Zefan Wang, Zichuan Liu,
Yingying Zhang, Aoxiao Zhong, Jihong Wang, Fengbin Yin, Lunting Fan,
Lingfei Wu, Qingsong Wen. \[S85\] RCAgent: Cloud Root Cause Analysis by
Autonomous Agents with Tool-Augmented Large Language Models. arXiv
preprint arXiv:2310.16340 \[S86\] Yihong Dong, Xue Jiang, Zhi Jin, Ge
Li. Self-collaboration Code Generation via ChatGPT. arXiv preprint
arXiv:2304.07590 Kechi Zhang, Zhuo Li, Jia Li, Ge Li, Zhi Jin.
Self-Edit: Fault-Aware Code Editor for Code Generation. In Proceedings
of the \[S87\] 61st Annual Meeting of the Association for Computational
Linguistics (ACL), 769 - 787. Gang Fan, Xiaoheng Xie, Xunjin Zheng,
Yinan Liang, Peng Di. Static Code Analysis in the AI Era: An In-depth
Exploration \[S88\] of the Concept, Function, and Potential of
Intelligent Code Analysis. arXiv preprint arXiv:2310.08837 Carlos E.
Jimenez, John Yang, Alexander Wettig, Shunyu Yao, Kexin Pei, Ofir Press,
Karthik Narasimhan. Swe-bench: Can \[S89\] language models resolve
real-world github issues?. In Proceedings of the 12th International
Conference on Representation Learning (ICLR). Xinyun Chen, Maxwell Lin,
Nathanael Schärli, Denny Zhou. Teaching Large Language Models to
Self-Debug. In Proceedings \[S90\] of the 12th International Conference
on Representation Learning (ICLR). Chenyuan Yang, Yinlin Deng, Runyu Lu,
Jiayi Yao, Jiawei Liu, Reyhaneh Jabbarvand, Lingming Zhang. White-box
Compiler \[S91\] FuzzingEmpowered by Large Language Models. arXiv
preprint arXiv:2310.15991. Theo X. Olausson, Jeevana Priya Inala,
Chenglong Wang, Jianfeng Gao, Armando Solar-Lezama. Is Self-Repair a
Silver Bullet \[S92\] for Code Generation?. In Proceedings of the 12th
International Conference on Representation Learning (ICLR). Chen Qian,
Wei Liu, Hongzhang Liu, Nuo Chen, Yufan Dang, Jiahao Li, Cheng Yang,
Weize Chen, Yusheng Su, Xin Cong, Juyuan \[S93\] Xu, Dahai Li, Zhiyuan
Liu, Maosong Sun. ChatDev: Communicative Agents for Software
Development. In Proceedings of the 62nd Annual Meeting of the
Association for Computational Linguistics (ACL), 15174 - 15186. Romal
Thoppilan, Daniel De Freitas, Jamie Hall, Noam Shazeer, Apoorv
Kulshreshtha, Heng-Tze Cheng, Alicia Jin, Taylor Bos, Leslie Baker, Yu
Du, YaGuang Li, Hongrae Lee, Huaixiu Steven Zheng, Amin Ghafouri,
Marcelo Menegali, Yanping Huang, Maxim Krikun, Dmitry Lepikhin, James
Qin, Dehao Chen, Yuanzhong Xu, Zhifeng Chen, Adam Roberts, Maarten
Bosma, Vincent Zhao, Yanqi Zhou, Chung-Ching Chang, Igor Krivokon, Will
Rusch, Marc Pickett, Pranesh Srinivasan, Laichee Man, Kathleen \[S94\]
Meier-Hellstern, Meredith Ringel Morris, Tulsee Doshi, Renelito Delos
Santos, Toju Duke, Johnny Soraker, Ben Zevenbergen, Vinodkumar
Prabhakaran, Mark Diaz, Ben Hutchinson, Kristen Olson, Alejandra Molina,
Erin Hoffman-John, Josh Lee, Lora Aroyo, Ravi Rajakumar, Alena Butryna,
Matthew Lamm, Viktoriya Kuzmina, Joe Fenton, Aaron Cohen, Rachel
Bernstein, Ray Kurzweil, Blaise Aguera-Arcas, Claire Cui, Marian Croak,
Ed Chi, Quoc Le. LaMDA: Language Models for Dialog Applications. arXiv
preprint arXiv:2201.08239.

                                         ACM Trans. Softw. Eng. Methodol., Vol. 0, No. 0, Article 0. Publication date: 2025.


