                                         Cascade: Detecting Inconsistencies between Code and
                                         Documentation with Automatic Test Generation
                                         TOBIAS KIECKER, Humboldt-Universität zu Berlin, Germany
                                         JAN ARNE SPARKA, Humboldt-Universität zu Berlin, Germany
                                         MARTIN REUTER, Humboldt-Universität zu Berlin, Germany
                                         ALBERT ZIEGLER, XBOW, Sweden
                                         LARS GRUNSKE, Humboldt-Universität zu Berlin, Germany

arXiv:2604.19400v1 \[cs.SE\] 21 Apr 2026

                                         Maintaining consistency between code and documentation is a crucial yet frequently overlooked aspect of
                                         software development. Even minor mismatches can confuse API users, introduce new bugs, and increase overall
                                         maintenance effort. This creates demand for automated solutions that can assist developers in identifying
                                         code-documentation inconsistencies. However, since automatic reports still require human confirmation, false
                                         positives carry serious consequences: wasting developer time and discouraging practical adoption.
                                            We introduce Cascade (Consistency Analysis for Source Code And Documentation through Execution), a
                                         novel tool for detecting inconsistencies with a strong emphasis on reducing false positives. Cascade leverages
                                         Large Language Models (LLMs) to generate unit tests directly from natural-language documentation. Since
                                         these tests are derived from the documentation, any failure during execution indicates a potential mismatch
                                         between the documented and actual behavior of the code. To minimize false positives, Cascade also generates
                                         code from the documentation to cross-check the generated tests. By design, an inconsistency is reported only
                                         when two conditions are met: the existing code fails a test, while the code generated from the documentation
                                         passes the same test.
                                            We evaluated Cascade on a novel dataset of 71 inconsistent and 814 consistent code-documentation
                                         pairs drawn from open-source Java projects. Further, we applied Cascade to additional Java, C#, and Rust
                                         repositories, where we uncovered 13 previously unknown inconsistencies, of which 10 have subsequently
                                         been fixed, demonstrating both Cascade’s precision and its applicability to real-world codebases.
                                         CCS Concepts: • Software and its engineering → Documentation; Empirical software validation; Software
                                         testing and debugging.
                                         Additional Key Words and Phrases: Documentation, Inconsistencies, Test Generation, Code Generation, LLM,
                                         AI4SE, Dataset
                                         ACM Reference Format:
                                         Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert Ziegler, and Lars Grunske. 2026. Cascade: Detecting
                                         Inconsistencies between Code and Documentation with Automatic Test Generation. Proc. ACM Softw. Eng. 3,
                                         FSE, Article FSE168 (July 2026), 23 pages. https://doi.org/10.1145/3808175

                                         1   Introduction
                                         Inconsistencies between code and its documentation are a long-standing issue in software develop-
                                         ment [30, 32, 39]. A common oversight for developers is to update code without corresponding
                                         updates of the documentation [31]. This can hinder the efficient use of libraries [43], increase the
                                         Authors’ Contact Information: Tobias Kiecker, Humboldt-Universität zu Berlin, Berlin, Germany, tobias.kiecker@hu-
                                         berlin.de; Jan Arne Sparka, Humboldt-Universität zu Berlin, Berlin, Germany, sparkaja@hu-berlin.de; Martin Reuter,
                                         Humboldt-Universität zu Berlin, Berlin, Germany, reuterma@student.hu-berlin.de; Albert Ziegler, XBOW, Uppsala, Sweden,
                                         albert@xbow.com; Lars Grunske, Humboldt-Universität zu Berlin, Berlin, Germany, grunske@informatik.hu-berlin.de.



                                         This work is licensed under a Creative Commons Attribution 4.0 International License.
                                         © 2026 Copyright held by the owner/author(s).
                                         ACM 2994-970X/2026/7-ARTFSE168
                                         https://doi.org/10.1145/3808175


                                                                              Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:2 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert Ziegler,
and Lars Grunske

1 /\* * 2 * Check if a CharSequence starts with any of an array of
specified strings . 3 \[...Shortened for better display...\] 4 \*
@return true if the CharSequence starts with any of the the prefixes ,
case insensitive , 5 \* or both null \[...\] 6 \*/ 7 public static
boolean startsWithAny ( final CharSequence string , final CharSequence
... searchStrings ) { 8 if ( isEmpty ( string ) \|\| ArrayUtils .
isEmpty ( searchStrings ) ) { 9 return false ; 10 } 11 for ( final
CharSequence searchString : searchStrings ) { 12 if ( startsWith (
string , searchString ) ) { 13 return true ; 14 } } 15 return false ; 16
}

Fig. 1. Method startsWithAny from the StringUtils class in apache
commons-lang. The docstring claims that the string matching is
case-insensitive, while in reality it is case-sensitive.

time required to understand a program \[46\], or decrease the
maintainability of software \[9, 20\]. Inconsistent documentation can
also lead to the introduction of bugs in other parts of the pro- gram
later in the development process \[49\]. Although good documentation
demonstrably benefits developers \[46\], the act of keeping it in sync
with evolving source code is repeatedly neglected \[50\].

Example. Figure 1 shows an example of an inconsistency in terms of a
semantic mismatch between documentation and code. The startsWithAny
string utility method from Apache's commons-lang checks whether a given
string starts with any string from a supplied list. The documentation
erroneously claims that the method is case-insensitive. So, for example,
it suggests that startsWithAny("HELLO World!", {"hell"}) would return
true. In reality, the method's implementation is case-sensitive, a fact
later confirmed by the developers in a commit1 that changed only this
single word in the Javadoc. The inconsistency likely arose from a
copy-paste error in- volving other case-insensitive methods in the same
class. The mistake is difficult to detect through manual inspection, as
the actual string comparison occurs several layers deeper in the call
hierarchy in the startsWith method (invoked in line 12). Static
approaches that just have the code and documentation as ground truth and
do not execute the method, e.g., with a test case, would miss the
problem. To detect these kinds of inconsistencies dynamic analysis is
needed.

Early work in detecting inconsistencies relied on specific language
compiler features \[26\], rule- based heuristics \[31\] or older Natural
Language Processing (NLP) techniques \[40\]. With the in- creasing
adoption of machine learning across all NLP tasks \[24\], recent work
has also applied it, for example in the deep-learning classifier by
Panthaplackel et al. \[28\]. LLMs have recently shown an unprecedented
ability to work with natural language, and this ability has been
harnessed for many different software engineering applications \[14, 23,
41\]. While also promising for the inconsistency detection task, these
models are notoriously unreliable. Minor changes in prompt wording can
lead to divergent \[47\] or outright hallucinated outputs \[13\]. They
sometimes even lack internal consistency \[47\]: asking an LLM a
semantically similar question in a different way can produce largely
different results.

1 github.com/apache/commons-lang/commit/d1a325560...

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:3

             A                                       B
                        Code                                     Code
                                  ?                       (↯)             ✗
                 Doc               Tests'                Doc               Tests'
                                                                  ✓?
               Generate Tests' based            If Tests' fail✗: indicator for a potential
                on the Documentation                inconsistency (↯) But only if:
              & Execute Tests' on Code                Tests' & Documentation
                                                                                               E
                                                           are consistent ✓?
                                                                                                    ↯!
                                                                                                         Code
                 Phase 1: Inconsistency Detection                                                                  ✗
                                                                                                   Doc           Tests'
                 Phase 2: False Positive Reduction
                                                                                                           ✓

               Generate Code' based                        If Tests' pass ✓:                 The new tests correctly showed
                on the Documentation                   Tests' & Documentation                an inconsistency ↯ between
              & Execute Tests' on Code'                   are consistent ✓!                     Code & Documentation
                                                                   ✓!
                 Doc               Tests'                Doc                Tests'
                                   ?                        ✓               ✓
                         Code'                                   Code'
             C                                       D

Fig. 2. Intuition behind Cascade. Phase 1 detects potential
inconsistencies under the assumption that tests and documentation are
aligned, and Phase 2 confirms this alignment.

Example. During our experiments, we asked an LLM (gpt-4.1-mini2 )
whether the example in Figure 1 contained an inconsistency. Most of the
time, it returned a clear no, completely missing the point in its
explanation and focusing only on the general structure and the usage
examples in the documentation. When asked the semantically similar, but
oppositely framed, question of whether the method and documentation were
consistent, it sometimes returned a no and in one cases gave the correct
explanation by (correctly) guessing that the underlying startsWith
method was case-sensitive. This highlights the volatility that pure LLM
approaches often show. To conclude, traditional techniques \[2, 39, 40\]
are narrowly scoped and LLM-based methods \[8, 16, 33\] are highly
volatile. Both shortcomings increase the risk of false alarms, a common
problem in static analysis. Static analysis tools, which are designed to
detect potential bugs in software, frequently generate high rates of
false positives \[35\]. This inefficiency can lead to a reluctance to
adopt such tools \[7\] due to the time wasted on investigating false
positives \[17\]. Developers are more likely to engage with tools that
are perceived to provide actionable insights with minimal noise \[42\].
Krishnamurthy et al. \[18\] supports the claim that high false positive
rates can deter even experienced developers from utilizing static
analysis tools. Given this evidence, we adopt a precision-first stance:
minimizing false positives is the primary goal, even at the cost of
recall. Tool. We introduce Cascade (Consistency Analysis for Source Code
And Documentation through Execution) to address the challenge of
identifying general code-documentation inconsis- tencies without
triggering excessive false positives. We prioritize precision over
recall. Cascade is intended to flag only inconsistencies that are
strongly supported by evidence, accepting that some true inconsistencies
might be missed. The high-level idea of Cascade is shown in Figure 2. A
Cas- cade leverages the natural language understanding capabilities of
LLMs to automatically generate executable unit tests including oracles
from method-level documentation (e.g., Javadoc). These tests aim to
capture the described behavior. B If at least one generated test case
fails when executed on the code, this strongly suggests a mismatch
between documentation and implementation. If the goal is high recall,
stopping at this point is acceptable. However, LLM's are imperfect and
can hallucinate or misinterpret intent and thus generate wrong test
cases. To mitigate this risk, Cascade performs a second validation
phase. C The same documentation is used to synthesize a new
implementation 2 platform.openai.com/docs/models/gpt-4.1-mini

                                             Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:4 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert Ziegler,
and Lars Grunske

of the method. This synthesized version is expected to pass the
documentation-derived tests if both were correctly generated and aligned
with the documented behavior. D We assume that LLM-based code generation
is typically more reliable than test generation \[5, 25\], and that the
joint success of independently generated code and tests on the same
specification increases confidence that both are correct representations
of the documentation. E Thus, an inconsistency is flagged only when the
following two conditions are met: (1) the original implementation fails
a generated test, and (2) the synthesized implementation passes the same
test. This dual check design significantly reduces false positives that
could arise from LLM errors or ambiguities in the documentation.

Dataset. To enable a meaningful evaluation of Cascade, we constructed a
novel dataset of method-documentation pairs that is, to our knowledge,
the first to consist of real-world confirmed semantic inconsistencies
within executable Java projects. Specifically, we mined and examined
commits where developers explicitly corrected inaccurate documentation,
and we verified that both the original and corrected code compile
successfully. This approach ensures that the dataset reflects authentic,
developer-acknowledged semantic code-documentation mismatches in real
software projects. To improve generalizability and better reflect
realistic class distributions, we additionally collected approximately
ten times as many consistent cases as inconsistent ones. In contrast,
existing code-documentation inconsistency datasets fall short in several
ways. Non-human-curated datasets that are mined based on heuristics,
such as those by Panthaplackel et al. \[29\], tend to label superficial
issues (e.g., typos or minor wording changes) as "inconsistent" and lack
executable code or context information. Lee et al. \[19\] used a
mutation-based dataset, that relies on synthetic error injection, while
others generate documentation with LLMs \[16\], potentially
misrepresenting natural developer behavior. These limitations make our
dataset uniquely suited for robust and realistic evaluation of tools
like Cascade. Overall, the main contributions of this paper are: • a
novel approach and tool Cascade that detects using newly generated test
cases to uncover inconsistencies between code and documentation and
newly generated code to prune false positives (Section 3); • a manually
curated dataset of commits from executable Java projects that have a
known inconsistency between code and documentation (Section 4); • an
evaluation of Cascade on this new dataset and on real-world projects of
different pro- gramming languages (Section 5), where we found previously
unknown and confirmed incon- sistencies.

2 Related Work A key aspect of high-quality documentation is its
consistency with the code it describes \[30\]. There are two types of
approaches to ensure this: preventing the introduction of
inconsistencies into the codebase (just-in-time) and detecting already
existing inconsistencies (post-hoc).

2.1 Avoiding Inconsistencies Just-in-time (JIT) techniques aim to update
documentation at the time of code changes. Panthap- lackel et al. \[28,
29\] proposed machine learning models to predict and classify comment
updates based on code diffs, and Rong et al. fine-tuned a code LLM for
the same purpose \[33\]. Liu et al. \[21, 22\] developed seq-to-seq
models for generating updated comments from code history. Stulova et
al.'s upDoc \[37\] maintains code-documentation mapping before and after
changes to highlight potential mismatches. Cascade aims at detecting
existing inconsistencies, thus these approaches \[21, 22, 28, 29, 37\]
are only adjacently related.

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:5

2.2 Detecting Inconsistencies Ensuring good consistency in a project can
also be achieved by analyzing projects in what is referred to as a
post-hoc setting \[28\]. It is generally not advisable to automatically
fix inconsistencies that are found, as developers, particularly in the
context of AI tools, often prefer tools that offer hints or advice
rather than perform actions without oversight \[6\]. Therefore, most
research in this area focuses on detecting inconsistencies rather than
resolving them. This is the context in which our approach, Cascade, is
situated. There have been several other notable approaches in this
domain. Early research on code-documentation consistency centered on
handcrafted rules and static analysis. Ouyang and Hua's tool ′ 𝑅 \[26\]
exploits Rust's built-in documentation tests, offering precise checks at
the cost of language flexibility. Similarly, Sondhi and Purandare \[36\]
match API documentation against a curated database of regular-expression
templates for string operations, while Ratol et al. \[31\] flag
parameter mismatches and unit-conversion errors through custom
heuristics. Tan et al.'s iComment \[39\] generalizes the idea by mining
logical constraints from C comments and statically verifying them. To go
beyond purely static checks, several systems generate or use concrete
executables. As a direct update to iComment, Tan et al. proposed
@tComment [40], which extracts rules regarding null-values from Java
comments and synthesizes test cases with Randoop \[27\] to expose
violations. JDoctor \[2\] adopts the same strategy for Javadoc pre- and
post-conditions, it is also limited to @param, @return and @throws tags.
More recently, Panthaplackel et al. \[29\] train neural classifiers to
detect mismatches between comments and methods \[28\] and Dau et
al. built DocChecker \[8\] to automatically handle the extraction and
classification on top of that model; Gao et al. \[12\] learn to remove
resolved 'TODO' annotations; and Kang et al. \[16\] focus on the
correctness of LLM generated docstrings \[16\]. While these
learning-based approaches generalize better than rule-based ones, they
still rely either on very specific features or on large labelled
corpora. LLM-prompting has opened a new direction. Lee et al.'s Metamon
\[19\] asks an LLM whether regression tests generated by EvoSuite \[11\]
are consistent with the documentation. However, their evaluation is also
confined to Java methods with @param and @return tags \[19\]. Zhang et
al.'s RustC4 combines LLM reasoning with Rust-specific static checks
\[48\]. And Rong et al. \[33\] fine-tuned a CodeLLaMA model for Javadoc
inconsistencies. Despite promising recall, LLM-based detectors suffer
from volatility: minor prompt changes or paraphrases can yield
contradictory answers \[13, 47\], inflating false positive rates. In
contrast to these approaches, Cascade is designed to operate on all
facets of code documenta- tion -- compared to template-based detectors
\[36\], Javadoc-tag specific approaches \[2, 19, 33, 40\] or specialized
'TODO'-comment removal \[12\]. It employs targeted, LLM-guided test-case
generation -- instead of the untargeted or evolutionary regression test
generation used by @tComment [40], JDoctor \[2\] or Metamon \[19\]).
Besides these technical differences, Cascade's primary goal is further
to significantly reduce false positives, making post-hoc inconsistency
detection practical for day-to-day development.

3 Cascade For each extracted function, Cascade predicts whether its
documentation is consistent with the implemented code, and outputs one
of two possible results: positive - an inconsistency is very likely or
negative - we did not find sufficient evidence for an inconsistency).
This entire procedure consists of two main phases, as described in
Algorithm 1. Phase 1: Inconsistency Detection. We first generate new
Tests T (line 2). In principle, the generation part of the analysis
could use any test synthesis approach that is able to run using only
documentation as the source for the generation. Specifically in this
implementation, we use Large

                                   Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:6 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert Ziegler,
and Lars Grunske

Language Models (LLMs) as generators, as these are currently the best
approaches to generate code and tests based on natural language
descriptions \[25, 34, 44\]. Several existing text-to-testcase
approaches were not suitable under our constraints: they Algorithm 1:
DetectInconsistency(doc, code) either do not target Java \[38\], do not
directly Input: doc --- documentation of a function generate executable
unit tests \[2\], or take nat- Input: code --- the function's current
implementation ural language artefacts other than function- Output:
verdict --- Positive (inconsistency) or Negative level documentation as
input \[3, 4, 10\]. Al- 1 Function DetectInconsistency(doc, code):
though Alagarsamy et al. \[1\] address text-to- 2 T ← GenerateTests(doc)
testcase generation, their approach is tightly // Execute new tests on
original code

                                                                                                                             Phase 1: Inconsistency Detection

coupled to a task-specific evaluation setup 3 res1 ← ExecuteTests(T,
code) if CompilerError ∈ 𝑟𝑒𝑠 1 then rather than a reusable, modular
component. 4 5 for 𝑖 ← 1 to 3 do Another closely related approach by
Kang et 6 T ← Repair(T, CompilerError) al. \[16\] does not provide any
available imple- 7 res1 ← ExecuteTests(T, code) mentation; however, our
test generation com- 8 if CompilerError ∉ 𝑟𝑒𝑠 1 then ponent is loosely
inspired by their prompting 9 break strategy. 10 if CompilerError ∈ 𝑟𝑒𝑠
1 then For any given function under tests, we first // uncompilable
after 3 tries prompt the LLM to generate a list of testable 11 return
Negative behavior from the documentation. These be- haviors are usually
returned in the form of 'if 12 if res1 .𝑓 𝑎𝑖𝑙𝑒𝑑 = ∅ then 13 return
Negative \[condition\] then \[behavior\]'. E.g., if the input ′ code ←
GenerateNewCode(doc) parameters have certain values, the method 14 //
re-run tests on new code throws a specific exception or if some other 15
res2 ← ExecuteTests(T, code′ ) method has been called before it should
return // classify test-outcome transition a positive value. From this
list, we create a 16 p2p ← 0, p2f ← 0, f2p ← 0, f2f ← 0

                                                                                                                      Phase 2: False Postive Reduction

test-class template with one test stub per item. 17 foreach 𝑡 ∈ T do
Each method includes a comment describing 18 if 𝑡 ∈ res1 .passed ∧ 𝑡 ∈
res2 .passed then the intended behavior. Finally, we prompt the 19 p2p
+= 1 LLM to complete the tests, providing the rel- 20 else if 𝑡 ∈ res1
.passed ∧ 𝑡 ∈ res2 .failed then p2f += 1 evant class context
(constructors, fields, other 21 22 else if 𝑡 ∈ res1 .failed ∧ 𝑡 ∈ res2
.passed then methods, etc.). The full multistage prompting 23 f2p += 1
is available in our supplementary material.3 24 else Next, we execute
this new test class on the 25 f2f += 1 original project and collect a
list of passed and if f2p \> 0 and p2f = 0 then failed tests (line 3).
If the new test class does 26 // Detected inconsistency not compile, we
automatically parse the com- 27 return Positive piler errors and ask the
LLM again in a type of 28 else repair loop to fix them (lines 4-9). If
the repair // No inconsistency found step is attempted three times and
the tests still 29 return Negative do not compile, we predict a negative
(No in- 30 consistency) (line 11) since we have not found any evidence
for an inconsistency. We are left with two possible outcomes: 1. All
generated tests pass If no generated test fails, we have no indicator
for an inconsistency. Note that, this outcome does not strictly confirm
consistency, as the discriminating test case might

3
github.com/TobiasKiecker/CASCADE/.../test/MultiStepJavaTestGenerator.py

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:7

simply be missing, due to imperfect generation. While there's also a
slight chance that some tests pass trivially (e.g., tautologies), a
manual review suggests that this is very rare. Thus, we predict a
negative (no inconsistency) and terminate the run (line 13). 2. At least
one generated test fails A failing test can indicate an inconsistency.
However, test generation from documentation can be flawed, and thus it
is possible that this generated test case is just wrong. The LLM
essentially has to solve the oracle problem for these methods and could
generate tests that are either always wrong or do not adhere to the
documentation at all. Therefore, we can only predict a positive with
reservations and continue with the verification step to reduce the
amount of false positives. Example. For our running example in Figure 1
this stage might produce a failing test case such as:
assertTrue(startsWithAny("HELLO world!", "hello")) if the method was
truly case- insensitive like described in the documentation this test
should have passed. However, this only holds true if the LLM extracted
the correct information from the documentation, thus further
verification of the test case is needed. Phase 2: False Positive
Reduction. To confirm that the potential inconsistency is real, we enter
Phase 2 and generate a new implementation of the documentation: 𝑐𝑜𝑑𝑒 ′
(line 14). Prior work shows that general code generation is usually more
reliable than direct test genera- tion \[5, 25\], thus this step filters
out broken tests. If a new test fails on both the regenerated code as
well as on the original, we cannot trust it. The code-generation prompt
is simpler than the test-generation prompt: we provide the original
class with the body of the method removed, retaining its signature and
documentation, and ask the LLM to implement the missing method. The
exact prompt can be found with the supplementary material and in the
code. We then run all generated tests from Phase 1 again on this newly
generated code (line 15) and collect the individual test results.
Combining the results of both phases, we can classify each individual
test case based on its two outcomes (lines 16-25): p2p pass to pass -
These test cases passed both on the original and on the new code. These
can be safely ignored. Either they are trivial or they do test some part
of the documentation that is consistent with both the old code and the
new. f2f fail to fail - Tests that failed on both the original code as
well as on the new code. These were most likely generated wrong. We
acknowledge that there are other cases e.g. there is an edge case that
is wrong in the old code and also not properly implemented in the new
code, but in this case, the test case is not helpful to us either. So,
we also ignore them. f2p fail to pass - Test cases that fail on the
original code but pass on the documentation aligned new code, are the
actual indicators for inconsistencies that we are looking for. These
tests show behavior that is described in the documentation (as shown by
two independently generated artifacts), but not reflected in the code.
p2f pass to fail - These are interesting cases that passed on the
original code but now failed on the new code. These can actually give us
an indicator for wrongly generated code. It shows that the new code is
missing at least some documentation-consistent functionality that the
original code had. Thus, if such a case exists, we cannot trust the new
code to actually follow the new documentation and accordingly, also not
trust the f2p test cases to really show an inconsistency. We disregard
the entire function and predict a negative instead. In summary, we
finally predict a positive result (an inconsistency) if there are no
test cases that changed from pass on the original code to fail on the
regenerated code (p2f) and at least one test case that changes from fail
to pass (f2p) (line 27). Under these conditions, we have simultaneous

                                   Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:8 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert Ziegler,
and Lars Grunske

evidence that, on one hand, the regenerated code is not generated
incorrectly (all retained tests pass) and on the other hand, the f2p
test exposed a mismatch in the original implementation. Hence, we can
confidently conclude that a genuine inconsistency exists.

Example. Assuming, for our running example in Figure 1, a wrong test
case would have been generated: assertFalse(startsWithAny("Hello world!"
, {"h" , "he", "world"})) be- cause the test generation LLM made the
mistake of thinking the target string has to start with all of the
strings in the list. This test would fail on the original code. But it
would also fail on the new generated code and thus we knew not to trust
this test case (f2f). On the other hand, the correct (failing) test case
from before assertTrue(startsWithAny("HELLO world!", {"hell"}) would
pass on the new code and we can predict an inconsistency with high
certainty (f2p). If for example, a test case like:
assertFalse(startsWithAny("Hello" , {"a"}) would suddenly fail on the
new code we would know that something went wrong during code generation
(e.g., the new code might just always return True) and we cannot trust
the test case as a predictor (p2f). Cascade is a post-hoc approach and
can be used on a project to find existing inconsistencies. It could be
used alongside other test suites overnight, leaving a human developer to
evaluate the results. This is why the goal to reduce the False Positives
is so important to decrease the burden on a developer.

4 Dataset 4.1 Previous Datasets Panthaplackel et al. \[29\] provide one
of the largest dataset in the area, which has been used for several
approaches. \[8, 28, 33\], mostly to train classical machine learning
classifiers. It contains pairs of functions and Javadoc comments
extracted from historical commits, but it offers neither project context
nor the exact commit hashes from which the methods were taken. As a
result, it is not possible to compile and run any new tests on these
projects. In addition, the "inconsistency" label is inferred from a very
simple heuristic: commits that modify only documentation, which
frequently captures trivial typo fixes or wording changes. Without
ground-truth confirmation by the developers, the labels remain
unreliable. Lee et al. \[19\] used Defects4J \[15\] as a base for their
evaluation. Defects4J was designed for bug detection research, not
documentation analysis. Assuming every buggy version violates the
documentation is often untrue: many bugs change internal edge cases
while leaving the API contract intact. They compound the issue by
injecting artificial mutants, producing code that is supposedly no
longer following its documentation. This can lead to nonsensical code
that would never occur in the real world. In addition, the well-studied
Defects4J bugs are widely discussed and described in literature, so LLMs
may have already memorized them, making any comparison with LLM-based
approaches inherently flawed. Kang et al. \[16\] focused on the
consistency of documentation generated by LLMs rather than written by
developers. While useful for studying hallucination and the ability of
LLMs to generate good documentation, it diverges from the diverse,
sometimes messy style of real-world comments and therefore would be an
unrealistic benchmark for Cascade. Wen et al. \[45\] tracked Java
commits that change comments and manually labeled a subset of them. Many
of their samples include parts where a new comment was added or outright
false positives \[37\]. However, we did use their taxonomy of
code-documentation changes to guide the inclusion and exclusion criteria
for our dataset.

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:9

                                      Table 1. Dataset Collection Statistics.


                                            #commits             #inconsistent func.           #consistent func.

author/project match exam. found runable paired extra
apache/commons-lang ∼1.1k 250 11 10 10 176 apache/commons-compress 973
250 8 3 3 9 apache/commons-math 789 250 16 13 13 163
apache/commons-collections 631 250 5 2 2 25 apache/commons-codec 454 250
6 4 4 24 assertj/assertj 446 250 4 2 2 1 google/guava 394 250 2 2 2 24
jfree/jfreechart 281 250 3 1 1 19 apache/commons-csv 244 244 8 4 4 10
apache/commons-cli 215 215 4 4 4 40 FasterXML/jackson-databind 212 212 3
2 2 16 JodaOrg/joda-time 160 160 10 8 8 80 google/gson 145 145 4 3 3 27
FasterXML/jackson-core 145 145 4 2 2 23 jhy/jsoup 97 97 8 8 8 80
graphhopper/jsprit 42 42 3 3 3 106 Other considered Projects4 1978 1214
8 0 - Total 7206 4474 107 71 71 743

4.2 Our Dataset None of the reviewed datasets simultaneously provides
(1) runnable source code, (2) documentation- level inconsistencies, and
(3) developer-validated semantic mismatches. We therefore curated a new
dataset of documentation-fix commits from large active Java projects.
Every instance compiles, every inconsistency was acknowledged and
corrected by the original author, and each fix warranted its own commit,
yielding a clean, executable ground truth dataset. Inconsistent Samples.
Statistics of our dataset collection can be seen in Table 1. We started
with the five largest projects used for evaluation by Blasi et
al. \[2\]. Their goal was to generate specifications from documentation
and they chose these projects for their focus on good documentation.
These projects were joined with ten other high-starred maven buildable
GitHub projects and the projects featured in Defects4J \[15\] Now, for
each of the 28 selected projects, we used GitHub Search to find commits
containing the term 'Javadoc' (#commits match in the table) and manually
examined every matching commit, up to a maximum of 250 per project
(#commits exam.). In total, this amounted to 4,474 commits manually
reviewed. For each commit, we individually checked all changed methods
to determine if only the Javadoc was changed and whether the change
constitutes a fix for an inconsistency. If it did, we marked down that
specific function in the previous commit as inconsistent. In this
previous commit the fix was not applied yet, and we could be highly
certain

4 Projects not included in the final dataset (examined numbers):
graphstream/gs-core (27), jgrapht/jgraph (178), apache/logging-log4j2
(250), apache/storm (75), Multibit-Legacy/multibit-hd (13),
mockito/mockito (250), awslabs/amazon- dynamodb-lock-client (1),
apache/commons-jxpath (78), google/closure-compiler (53),
FasterXML/jackson-dataformat-xml (28), junit-team/junit4 (195),
qos-ch/logback (66)

                                     Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:10 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert
Ziegler, and Lars Grunske

that at this point code and documentation had been considered
inconsistent. We explicitly excluded the following types of changes: •
Simple formatting changes and typos except for functionality-altering
ones (e.g., "case insen- sitive" instead of "case sensitive" from Figure
1). • Changes to links in the documentation (e.g., @see or @link tags).
• The addition of documentation where there was previously none. •
Simple renaming of parameters to fit the signature without any other
substantial changes to their description. We filtered out private
methods and abstract classes, which are rarely tested directly, as well
as constructors which often have their documentation integrated into the
class-level documentation. This left us with 107 methods across 55
commits from 16 projects #inconsistent func. found in Table 1). With a
commit date range spanning from 2004 to 2024, we covered 20 years of
Java development, encompassing various Java versions and conventions,
and different coding styles. Considerable effort went into making these
old versions of projects executable so that we could run the newly
generated tests. This was impossible for some of the commits if the
whole project was in a broken state. All changes were made with great
care to avoid introducing new errors or inconsistencies in the functions
under test. Unfortunately, we were not able to get every project to
compile and therefore had to exclude these functions. We thus were left
with 71 manually checked inconsistencies from runnable projects that
were included into the dataset (#inconsistent func. runable in Table 1).
Consistent Samples. Because we want to evaluate the effectiveness of
inconsistency-detection tools, we also need consistent code and
documentation to serve as ground truth negative examples. Our
dataset-collection process automatically provides the
developer-corrected version of each inconsistency (#consistent func.
paired in the table), since the commit we located explicitly contains
the fix. This gives us a balanced dataset; for every function we have
one version with correct documentation and one with incorrect
documentation, as identified by the project's developers. However, since
real-world data is not nessecarly balanced, we additionally wanted to
evaluate on a more realistic dataset. Therefore, we included further
consistent cases by extracting all other methods from the same class
that contained documentation and were not modified in the commit (with a
maximum of 20 per class) resulting in an additionall 743 consistent
functions (#consitent func. extra in the table). The rationale is that
if a dedicated fix was made to a specific documentation issue in that
class, the remaining unchanged methods are likely consistent. This is a
weaker heuristic than using explicitly fixed cases, but it provides a
sufficiently realistic approximation. Finally, we have a balanced core
dataset consisting of 142 method-Javadoc pairs, 71 with an inconsistency
and 71 without. Furthermore, we include 743 additional methods without
an inconsistency to enable evaluation under a more realistic data
distribution. We provide the dataset with the supplementary material.5

5 Experimental Design and Setup Our evaluation consists of three parts.
First, we assess the performance of Cascade on the novel dataset by
comparing it against several LLM baselines and two state-of-the-art
inconsistency classification tools. Second, we conduct an ablation study
on the same dataset to analyze the contribution of each component and
design choice within Cascade. Finally, we investigate the applicability
of Cascade to real-world software projects written in various
programming languages, and present examples of actual inconsistencies it
uncovered. 5 github.com/TobiasKiecker/CASCADE/.../dataset.zip

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:11

5.1 Research Questions This evaluation is guided by the following
research questions: • RQ1: Performance: How does Cascade compare to
other inconsistency detection ap- proaches in terms of classification
metrics such as precision, recall, and specificity? • RQ2: Ablation: How
do the individual components and design decisions in Cascade impact its
performance in detecting code-documentation inconsistencies? • RQ3:
Real-World Utility: How effective is Cascade at detecting
inconsistencies in large- scale, real-world software projects? These
questions reflect the goals of our evaluation: to establish Cascade's
relative effectiveness (RQ1), to understand the contribution of its
internal architecture (RQ2), and to validate its practical value beyond
controlled datasets (RQ3).

5.2 Experiments For the main experiment, we compare our approach against
three baselines: an LLM-Baseline, DocChecker \[8\] and C4RLLaMA \[33\].
All LLMs used for RQ1 and RQ2, (in the baselines and within Cascade)
were run with a temperature of 0 using the same model: gpt-4.1-mini.6
For RQ3, we had several different versions of Cascade running during its
development mainly usinggpt-4o-mini.7 Several tools have been proposed
to reveal inconsistencies between source code and its docu- mentation,
yet most cannot serve as practical baselines for our evaluation.
Language support disqualifies RustC4 \[48\] and ′ 𝑅 \[26\], which both
target Rust specifically, and Metamon \[19\], whose analysis pipeline is
bound to Java 8 and JUnit 4 due to its reliance on EvoSuite \[11\].
Reproducibility is another limiting factor: the approach of Kang et
al. \[16\] and RustC4 \[48\] lack any published implementation. The
supplementary material of Metamon \[19\] is tightly coupled to their own
dataset evaluation, making adaptation infeasible. Finally, scope is an
important aspect. @tComment [40] focuses only on defects regarding null
values, while JDoctor \[2\] and Metamon \[19\] focus only on @param,
@return, and @throws tags and therefore would miss inconsistencies
expressed elsewhere in the Javadoc block. After applying these criteria,
two candidates that (1) support modern Java, (2) are publicly available,
and (3) claim general-purpose coverage remain: DocChecker and C4RLLaMA.
DocChecker. Dau et al. \[8\] extend Panthaplackel et al.'s approach
\[28\] with a model trained from ground up specifically for
code--comment inconsistency detection (post-hoc). To make DocChecker
runnable, we re-trained their model from scratch and modified a few
lines in their provided library code. We verified the implementation on
their clean test split and even achieved better results in F1 and
accuracy than those reported in the original paper \[8\]. We made this
retrained model available with the supplementary material. 8 However, we
discovered another minor issue. For Java, the tool does not
automatically extract the Javadoc; instead, it uses the first comment
inside the function as the target documentation. To give DocChecker a
fair evaluation, we implemented two wrappers: DocChecker-block:
compresses the entire Javadoc into a single-line comment at the
beginning of the function and run DocChecker as is. DocChecker-single:
processes the Javadoc line by line, separately placing each line into
the first comment and invoking the predictor for each. If at least one
prediction indicates an inconsistency, we mark the sample as predicted
inconsistent. Due to the training dataset consisting of single line
comments only, this will result in a fairer evaluation. 6
platform.openai.com/docs/models/gpt-4.1-mini 7
platform.openai.com/docs/models/gpt-4o-mini 8
github.com/TobiasKiecker/CASCADE/.../DocChecker/pretrained_model

                                    Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:12 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert
Ziegler, and Lars Grunske

C4RLLaMA. Rong et al. \[33\] fine-tuned a pretrained LLM (CodeLLaMA-7B)
instead of training a model from ground up. We re-trained and
re-evaluated the model using their provided setup and scripts and
include the resulting weights in the supplementary material.9 To
interface with Javadoc, we mirror the wrappers from DocChecker:
C4RLLaMA-block: pass the complete Javadoc string as a block (stripped of
comment markers). C4RLLaMA-single: invoke the predictor individually for
each Javadoc line and mark the method inconsistent if any line is
flagged. This aligns with the underlying dataset, which contains
single-line comment edits \[29\]. LLM Baselines. Instead of finetuning a
pretrained LLM, it is also possible to use a general purpose LLM
directly. We define several LLM-based baselines for detecting
inconsistencies between code and documentation, Notably, LLMs tend to
exhibit inconsistency in their own outputs and are prone to
hallucinations, e.g., when guessing what unfamiliar function calls
within a method under test do. To systematically assess and mitigate
this unreliability, we query the LLM in four distinct single-call
settings. Two of these focus on direct questions with limited context:
(1) asking whether the method and its documentation are consistent
(LLM-S𝑐 ), and (2) asking whether there is an inconsistency between them
(LLM-S𝑖 ). These are very close semantically but phrased inversely. One
would expect that a method flagged consistent by the first call would
not have an inconsistency found in the second, and vice versa. The other
two baselines repeat the same binary questions but include more advanced
contextual information (LLM-A𝑐 and LLM-A𝑖 ). This extra context consists
of the full class in which the method is defined, along with its
associated documentation and other methods. This is the same information
that we use in Cascade for the test generation. This results in four
single-query baselines (LLM-S𝑐 , LLM-S𝑖 , LLM-A𝑐 and LLM-A𝑖 Again, given
the known variability in LLM responses, we additionally define four
ensemble baselines that vote over the outputs of the four single-call
outputs: at least one flags inconsistency (Voting ≥1 ), at least two
(Voting ≥2 ), at least three (Voting ≥3 ), and unanimity (Voting=4 ).
These eight variations collectively capture the variability and try to
mitigate the limitations of directly using LLMs for this task, to ensure
a fair comparison. We are thus left with four main approaches: Baselines
with a generic multipurpose LLM, ensemble votings over these LLMs, a
code-LLM fine-tuned for inconsistency detection (C4RLLaMA) and a model
trained from ground up for this task (DocChecker)

5.3 Metrics All Subjects: Cascade, the different LLM-baselines,
DocChecker as well as C4RLLaMA predict for a given method whether it
contains an inconsistency. An inconsistent method is predicted as a
positive, while any method where no clear inconsistency can be
determined, is predicted as a negative. If a method truly contains an
inconsistency and the tool correctly predicts it as such, it is a true
positive (TP). If the tool flags an actually consistent method as
inconsistent, it is a false positive (FP). Conversely, if a method is
consistent and correctly identified as such, it is a true negative (TN),
and if an inconsistency is missed, it is a false negative (FN). We
evaluate the different approaches using the following standard metrics
for classification problems.

                   𝑇𝑃                     𝑇𝑃                     𝑇𝑁                2 · 𝑝𝑟𝑒𝑐 · 𝑟𝑒𝑐
          𝑟𝑒𝑐 =                𝑝𝑟𝑒𝑐 =                  𝑠𝑝𝑒𝑐 =                𝐹1 =
                 𝑇𝑃 + 𝐹𝑁               𝑇𝑃 + 𝐹𝑃                𝑇 𝑁 + 𝐹𝑃              𝑝𝑟𝑒𝑐 + 𝑟𝑒𝑐

Recall (rec.) measures the proportion of actual inconsistencies in the
project that the tool correctly identifies. High recall would be
essential if the goal was to detect as many existing inconsistencies as
possible. Precision (prec.) measures the proportion of samples flagged
by the tool as inconsistent that are actually true inconsistencies. High
precision is crucial to ensure developers are not overwhelmed 9
github.com/TobiasKiecker/CASCADE/.../C4RLLaMA/weights

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:13

Table 2. Results of the benchmark for a balanced 50%/50% split (71
inconsistent/71 consistent) and an imbalanced 10%/90% split (71
inconsistent/639 consistent). For the imbalanced setting, medians over
1,000 randomly sampled subsets are reported. All values are rounded to
two decimals.

                                             50%/50% Split                               10%/90% Split
                                  𝑝𝑟𝑒𝑐. 𝑠𝑝𝑒𝑐. 𝑟𝑒𝑐.           PFP      𝐹1       𝑝𝑟𝑒𝑐. 𝑠𝑝𝑒𝑐. 𝑟𝑒𝑐.          PFP       𝐹1
           LLM-S𝑐                    .53      .42      .67    .26 .59             .15      .58     .67     .26     .24

general LLM-S𝑖 .56 .58 .54 .37 .55 .10 .47 .54 .37 .17 LLMs LLM-A𝑐 .55
.64 .46 .53 .50 .20 .80 .46 .53 .28 LLM-A𝑖 .59 .81 .29 .65 .39 .11 .75
.29 .65 .16 Voting ≥1 .54 .32 .81 .26 .65 .12 .34 .81 .26 .21 Voting ≥2
.54 .44 .67 .32 .60 .14 .53 .67 .32 .23 LLM voting Voting ≥3 .61 .76 .37
.69 .46 .17 .80 .37 .69 .23 Voting=4 .54 .92 .10 .57 .17 .11 .91 .10 .57
.11 block .48 .19 .77 .02 .59 .08 .06 .77 .02 .15 DocChecker single
lines .49 .03 .96 0 .65 .10 .01 .96 0 .17 block .45 .63 .31 .41 .37 .12
.75 .31 .41 .18 C4RLLaMA single lines .53 .64 .41 .48 .46 .13 .69 .41
.48 .19 Cascade .88 .97 .21 .87 .35 .39 .96 .21 .87 .28

with false positives. Specificity (spec.) measures the proportion of
consistent code-documentation pairs that are correctly identified as
consistent. While it is not a standard metric in most classification
evaluations, it is particularly important in our setting to ensure that
Cascade does not incorrectly flag too many correct methods as
inconsistent. 𝐹 1 -score is the harmonic mean of precision and recall.
It provides a single metric that balances both false positives and false
negatives, making it useful when both high precision and high recall are
desired. One feature of our dataset is that it contains a core set of
paired samples. For these method- documentation pairs that are
inconsistent, we provide a corrected, consistent version. This structure
enables us to calculate a pair-wise metric: Pair-wise Fix Precision
(PFP). We define PFP as the fraction of true positive predictions (i.e.,
inconsistent versions correctly classified as inconsistent) for which
the corresponding fixed version is also classified correctly as
consistent. A high PFP indicates that the tool not only detects an
inconsistency but also recognizes its resolution. In other words, if a
function is correctly flagged as inconsistent, its patched counterpart
is likewise classified as consistent.

6 Results and Evaluation 6.1 RQ1: Performance Table 2 reports precision
(𝑝𝑟𝑒𝑐.), recall (𝑟𝑒𝑐.), specificity (𝑠𝑝𝑒𝑐.), pair-wise fix precision
(PFP), and 𝐹 1 -score for all configurations of the three evaluated
approaches. In addition, results are presented for two different dataset
splits. The first split is balanced (50%/50%), consisting of 71
inconsistent samples and their 71 paired consistent counterparts. The
second split reflects a more realistic class distribution (10%/90%) of
71 inconsistent and 639 consistent samples. For the 10%/90% setting, the
consistent samples include the 71 paired counterparts of the
inconsistent instances, as well as 568 additional samples drawn from a
pool of 743 available consistent instances. We classified every sample
with every tool adn version, and for the split, we generate 1,000 random
subsets of consistent samples and report the median performance across
runs. It should be noted that recall

                                   Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:14 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert
Ziegler, and Lars Grunske

and PFP remain constant across different dataset splits. Both metrics
depend solely on the number of true positives. Since the set of 71
inconsistent samples is fixed and no additional true positives can be
identified by increasing the number of consistent samples, these values
do not change across splits. The first notable observation is the poor
performance of DocChecker. Both variants exhibit worse than random
discriminative power with a precision below 50%. DocChecker does achieve
the highest recall of all tools for both splits. However, a value of
0.96 is reached simply by flagging almost everything as inconsistent,
which is not helpful for developers. In the original paper for C4RLLaMA
a strong improvement over DocChecker is reported \[33\]. Here, we can
also see that it is generally performing better in many metrics,
especially for the 10%/90% split. Comparing the two C4RLLaMA variants,
the line-by-line documentation processing (single lines) improves all
metrics over the block-based version. However, a precision of .53 is
still well below the results achieved by Cascade or even basic,
non-fine-tuned LLMs. Also notable is the consistently low Pair-wise Fix
Precision (PFP) for both DocChecker and C4RLLaMA. This suggests that
these specialized models may be overspecialized on their training data.
The low PFP indicates that they tend to classify both the consistent and
inconsistent version of the same method as inconsistent, revealing that
they may not correctly detect inconsistencies but instead latched onto
some unrelated code patterns. In contrast, Cascade 's test-case-based
approach should handle this problem more effectively. Looking at the
baseline LLM runs, one interesting behavior is that prompt direction
affects the single-shot LLMs more than the amount of context. Asking
"Are code and documentation consistent?" (LLM-S𝑐 and LLM-A𝑐 ) generally
yields more positive answers than asking "Is there an inconsistency?"
(LLM-S𝑖 and LLM-A𝑖 ). Since the baselines return not only a 'yes' or
'no' but also an explanation, we are able to do a manual inspection of
what leads to these results. When queried for consistency, the model
often focuses on general style or potentially missing things like error
handling, and thus more eagerly reports an inconsistency. When queried
directly for inconsistencies, it often requires a specific word or line
that is wrong. This stricter threshold explains why both 'inconsistency'
prompts have higher precision but lower recall than the repsective
'consistency' prompts. Adding more context in the advanced prompts
(LLM-A𝑖 and LLM-A𝑐 ) generally shows only a small improvement accross
both prompting directions and dataset splits, however, the recal drops
strongly indicating that the extra information leads to less reported
cases in general. Presumably because, the model sometimes gets
distracted and drifts into more general issues. All in all, no
individual LLM-baseline can be trusted completely, which is why we
employed voting. Ensembling mitigates the volatility of individual LLMs.
Voting ≥3 as the best of the four variants surpasses Cascade's PFP score
(0.92 vs. 0.86) but still has lower precision and specificity. It is
also interesting to see that the different baselines report different
samples as inconsistent; otherwise, the voting could not return more
true positives (and false positives) than any single baseline does. This
again shows the flakiness of individual LLM results, and while it is
possible to somewhat mitigate those issues by ensemble voting, it cannot
consistently beat a more strict test-based method such as Cascade. An
important observation concerns stability under class imbalance. In
real-world software projects, inconsistencies between documentation and
implementation are typically rare, but their exact amount is unknown.
Estimating it reliably would require either extremly large-scale manual
inspection or a sufficiently accurate detection approach, which we are
attempting to build here. Still, evaluation under skewed class
distributions is more representative of practical deployment scenarios
than a purely balanced benchmark. Figure 3 shows trends accros
increasingly unbalanced dataset splits for four approaches: Cascade, the
best-performing LLM-based voting variant (Voting ≥3 ), the
best-performing DocChecker configuration (single-line), and the
best-performing C4RLLaMA

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:15

                0.9
                                                                                    C4RLLaMA                                                                                             C4RLLaMA
                0.8                                                                 DocChecker                       0.6                                                                 DocChecker
                                                                                    LLM-Voting 3                                                                                         LLM-Voting 3
                0.7                                                                 CASCADE                                                                                              CASCADE
                                                                                                                     0.5
                0.6

Prec (median)

                                                                                                       F1 (median)
                0.5                                                                                                  0.4
                0.4
                0.3                                                                                                  0.3
                0.2
                                                                                                                     0.2
                0.1
                      50% (71)   60% (107)          70% (166)           80% (284)          90% (639)                       50% (71)   60% (107)          70% (166)           80% (284)          90% (639)
                                  Percentage of consistent samples (total amount)                                                      Percentage of consistent samples (total amount)

                       (a) Precision across different dataset splits                                                         (b) 𝐹 1 -score across different dataset splits

Fig. 3. Median (line) and max and min values (shaded area) over 1,000
sampled subsets is shown. Inconsisten- cies stay fixed at 71.

configuration (single-line) ('best-performing' based on precision on the
50%/50% split). For the data displayed in Figure 3, we fix the 71
inconsistent instances and their consistent counterparts and
progressively increase the number of consistent samples to simulate
different distributions. The x-axis in both subfigures represents the
proportion of inconsistent to consistent samples. The evaluation ranges
from a balanced 50%/50% split (71 inconsistent and 71 consistent
samples) to increasingly imbalanced settings, up to 10%/90% (71
inconsistent and 639 consistent samples). The consistent samples are
drawn from the 743 available consistent instances. For every class
ratio, we generate 1,000 random subsets of consistent samples and report
the median performance. The shaded area around each curve indicates the
minimum and maximum values observed across these 1,000 runs. Subfigure
3a shows that precision decreases for all approaches as the dataset
becomes increasingly imbalanced. This behavior is expected. While the
number of true positives is bounded by the fixed set of 71 inconsistent
samples, the number of false positives can increase as more consistent
samples are added. Since all evaluated approaches produce false
positives, precision declines monotonically across splits. Cascade
achieves the highest precision across all class distributions. However,
it also exhibits higher variability compared to the other methods. This
can be explained by the fact that Cascade produces only 31 false
positives across the full set of 814 consistent samples. Consequently,
whether specific false positives are included or excluded in a randomly
sampled subset has a relatively large impact on precision. In contrast,
DocChecker shows almost no variability, as it consistently overreports.
Its number of false positives is sufficiently large so that changes in
the sampled consistent subset have negligible relative impact. In
Subfigure 3b the 𝐹 1 -score is shown. Due to the precision first design
and the resulting low recall, Cascade performs worst on the balanced
split. However, as the dataset becomes more representative of real-world
conditions (i.e., increasingly skewed toward consistent samples), the 𝐹
1 -scores of the other approaches drop substantially. Cascade remains
comparatively stable and achieves the highest 𝐹 1 -score for the 10%/90%
split. Although the absolute value remains modest (approximately 0.28),
it exceeds the performance of all other methods under this more
realistic class distribution. The quantitative results in Table 4
support this observation. Only one additional approach (LLM-A𝑐 )
achieves a comparable 𝐹 1 -score; however, it exhibits lower precision,
lower specificity, and a worse PFP-rate. Cascade excels in precision and
specificity, with expectedly lower recall; which aligns with our design
goals. This trade-off is deliberate: the system is tuned to minimize
false positives, prioritizing trust in every flagged inconsistency. This
design rationale is further supported by the results

                                                                   Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:16 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert
Ziegler, and Lars Grunske

                Table 3. Results based on the different stages of Cascade on the 50%/50% split


                                      prec. spec. rec. PFP 𝐹 1            TP FP TN FN
                          Phase 1       .60     .63 .59      .54 .59       41 27       45 29
                          Phase 2       .85     .96 .24      .88 .38       17 3        69 53
                          full          .88     .97 .21      .87 .35       15 2        70 55

under the imbalanced 10%/90% split, which more closely reflects
realistic project conditions. In this imbalanced setting, methods with
higher false positive rates degrade substantially because the majority
of methods are consistent. In contrast, Cascade remains stable due to
its conservative predictions. Although recall is limited, the low false
positive rate prevents an excess of incorrect reports. Overall, when
judged on the primary objectives, Cascade is generally performing best.
LLM- voting offers a recall/PFP trade-off that may appeal to
defect-finding tasks under higher recall constraints but still yields
flaky results, whereas the approaches based on classical machine
learning either drown developers in false positives or miss subtle
inconsistencies entirely. For settings where false alarms are costly and
the trustworthiness of each predicted sample is important, Cascade
represents the most effective choice among the evaluated techniques.

Answering RQ1: Cascade flags code-documentation inconsistencies in the
benchmark (Sec- tion 4) with a very low number of false positives, and
thus outperforms the baselines in the primary objectives precision
(0.88) and specificity (0.97) for a balanced dataset, as well as in 𝐹 1
-score for a realistic dataset.

6.2 RQ2: Ablation Our primary goal is to detect as many inconsistencies
as possible while minimizing the number of false positives. This
represents a classic trade-off in classification tasks: increasing
precision often results in lower recall, and vice versa. In Cascade's
design (Section 3), we introduced multiple steps aimed at optimizing
this trade-off. In Table 3, we show three different configurations of
the tool with the evaluation metrics defined earlier (see Section 5.3).
Namely, the prediction values from the confusion matrix (TP, FP, TN,
FN), precision (prec.), specificity (spec.), recall (rec.) and the
Pair-wise Fix Precision (PFP). Without the second phase enabled (Phase
1), Cascade reports an inconsistency as soon as any generated test
fails. This configuration catches 41 out of 71 real inconsistencies
(recall of 0.59) but at the cost of 27 false positives, which drags
precision down to 0.60 and specificity to 0.63. With this score, it
would still be on par or better in terms of recall with the LLM
baselines (see Table 2) and beat many of them in precision as well.
However, our declared goal is to reduce the false positives burden for
developers so to get rid of as many of the false positives as possible
and thus we introduced Phase 2. The basic version of Phase 2 predicts an
inconsistency as soon as any test flips from failing to passing
(#f2p\>0). This means we do not have the added check that there are no
test cases that passed before and failed now. This final version (full)
eliminates most of the wrong reports, lifting precision to 0.85 and
specificity to 0.96 at the cost of recall. This confirms our design
intuition that the failing tests alone are not enough of an indicator
because with the generated code we actually filter out wrong generated
tests.

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:17

We manually evaluated the two single false positives predicted by
Cascade. and they both came from cases wehre the generated code and
tests made the same false asumption over something underspecified in the
documentation. False negatives, by contrast, mostly arise from tests
that do not compile or from missing discrimi- nating cases. We expect
these limitations to diminish as LLM quality and test generation
techniques improve in the future. The final check, if the amount of p2f
tests is 0, actually helps to sort out wrongly generated code, as
intended (Cascade 𝑓 𝑢𝑙𝑙 ). If there is at least one test case that
passed before and now fails on the new code, we cannot really trust this
new code on the passing test cases. This step removes one of the two
remaining false positives, slightly improving precision (0.82 to 0.88)
with only a marginal decrease in recall (0.26 to 0.21). The full version
thus eliminated all but one false positive which has been analyzed in
the previous section. An analysis of the different classification types
reveals that for a given method, roughly 5-20 tests are generated
(average of 8.4). The average numbers for the results classes are:
p2p:5.9; f2f:2; p2f:0.3 and f2p:0.4. At most, three f2p (usually 1-2)
cases exist which are testing exactly the one thing that is wrong in the
documentation. During Cascade's development, we found two main reasons
for non-compiling tests: uncaught declared exceptions and the LLM
hallucinating non-existent functions or fields. This will most likely
improve with better base LLMs. Overall, Phase 2 accounts for the bulk of
the precision improvement by discarding spurious failures, while the
additional requirement p2f=0 prunes misclassifications from wrong
generated code. The resulting Cascade 𝑓 𝑢𝑙𝑙 configuration leaves a
single false positive and increases precision to 0.88 with a decrease in
recall (0.26 to 0.21). Depending on project goals, no-Phase-2 is
preferable when maximizing recall, whereas Phase-2-no-p2f=0 trades a few
found cases for a substantial drop in false alarms. Answering RQ2:
Cascade's different steps serve the purpose of False Positive reduction,
in turn enhancing precision, at the cost of recall.

6.3 RQ3: Inconsistencies in the Wild During the development of Cascade,
we applied multiple versions of the tool to real-world Java projects. To
assess the generalizability of our approach, we also developed C# and
Rust versions, adapting the tool to each language by implementing custom
extractors and executors, and tailoring the prompts to generate
appropriate unit tests. We checked the latest versions of 15 of the
projects from our dataset collection for Java, 13 high starred GitHub
projects for C#, and 6 Projects from Zhang et al. \[48\] for Rust. We
did not report very minor possible inconsistencies. First, some
inconsistencies resulted from incomplete documentation of exceptional
behavior. For example, while the documentation did not specify which
exception is thrown for invalid input, the implementation raised a
reasonable but different exception than assumed by Cascade. Although
technically inconsistent, such cases reflect underspecification rather
than clear semantic contradictions and were therefore not considered
substantial enough to be reported. Second, we observed instances of
undocumented behavior without observable semantic impact. For example, a
method in a Stringbuilder class was documented to ignore null values but
additionally explicitly ignored empty strings (""). While this behavior
deviates from the specification, it does not affect the resulting
observable program behavior and is therefore practically irrelevant. To
again avoid unnecessary overhead on maintainers, we restricted reporting
to inconsistencies with clear semantic impact.

                                   Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:18 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert
Ziegler, and Lars Grunske

                        Table 4. An overview of the real world issues found by Cascade


                                                                                               TP
     Language        author/project                     checked      FP
                                                                           Total       Minor    Reported    Fix.
                     apache/commons-lang                     986      2      2           1          1         1
                     apache/commons-text                     575      3      4           2          2         2
     Java
                     Atmosphere/atmosphere                   543      3      2           0          2         2
                     jfree/jfreechart                       4823      9      10          8          2         -
                     jellyfin/jellyfin                        93      7      2           1          1         1
     C#              bchavez/Bogus                           211      1      1           0          1         1
                     icsharpcode/SharpZipLib                  91     13      4           3          1         -
                     avhz/RustQuant                          186      2      2           0          2         2
     Rust
                     bitshifter/glam-rs                      248      4      3           2          1         1

Through these cross-language experiments, we identified 13 previously
undocumented real inconsistencies, which we reported to the respective
maintainers.10 Table 4 summarizes the results for the real-world
evaluation. The column checked reports the number of functions analyzed.
We considered only public, non-constructor, non-abstract methods with
available documentation. FP denotes the number of produced false
positives. These primarily resulted from cases in which both the
generated tests and the generated code assumptions were incorrect. Such
cases were identified and filtered out through manual inspection. TP
total represents the total number of confirmed true positives. We
further distinguish between minor cases and those severe enough to
warant a report. Reported cases include the remaining confirmed
inconsistencies that were communicated to project maintainers via GitHub
pull-requests, GitHub issues or external bug trackers (whatever the
specific project maintainers prefered) and fixed (Fix.) denotes the
number of issues that have since been resolved, either through our
submitted pull requests or through independent fixes by the original
developers. In one instance, maintainers argued that the reported
behavior did not constitute a genuine inconsistency. This case involved
a hash function with behavior slightly deviating from the documentation
but still satisfying the general Java hash contract. We therefore
reclassified it as minor. The remaining unacknowledged cases were
primarily in repositories with limited maintenance activity. The
observed drop in precision compared to the results of RQ1 and RQ2 can
likely be attributed to two main factors. First, the real-world
evaluation used an older and less capable model (gpt-4o-mini instead of
gpt-4.1-mini), primarily for cost reasons, as the analyzed projects were
substantially larger than the curated dataset. Second, many real-world
projects exhibit low documentation quality. Since our approach targets
inconsistencies between documentation and implementation, poorly
specified or low-quality documentation inherently limits the achievable
precision, as it becomes difficult to determine whether deviations
constitute genuine inconsistencies. We now discuss two illustrative
examples for the additinal languages, as they reveal noteworthy insights
about Cascade. Our running example in Figure 1 is already an
illustrative example of one of the Java inconsistencies we found and
reported.

10 Java: Commons Lang-173, Commons Text-234 (2 reported),
Atmosphere#2514, Atmosphere#2515, JFreeChart#417 (2

reported); C#: jellyfin#13360, Bogus#581, SharpZipLib#887; Rust:
RustQuant#296 (2 reported), glam-rs#622.

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:19

1 /// Generate a random ulong between MinValue and MaxValue . 2 ///
Parameter - min : Min value , inclusive . Default ulong . MinValue . 3
/// Parameter - max : Max value , inclusive . Default ulong . MaxValue .
4 public ulong ULong ( ulong min = ulong . MinValue , 5 ulong max =
ulong . MaxValue ) 6 { return Convert . ToUInt64 ( Double () \* ( max -
min ) + min ) ; }

Fig. 4. C# example: Line 6 contains the expression that causes the
mistake. The conversion should only be applied to the result of the
multiplication. It should not include the addition of min.

C#. For C# we had no prior work to start with, so we looked at high
starred projects on GitHub11 . Bogus is an open-source data generator
for C# that is widely used and included in several Microsoft projects.
It provides a method called ULong that generates a random unsigned long
value between a given min and max shown in Figure 4. Cascade discovered
that the method consistently crashes with an arithmetic overflow when
min is close to the max value of long, due to a floating point rounding
error. This behavior violates the expected functionality described in
the documentation, which promises reliable generation of values across
the full range of an unsigned long. To reveal the problem, Cascade
generated tests with high min values, which resulted in predictable
runtime exceptions. The conversion of the randomized value to a long was
happening too late in the equation. With its proposed code, the tool
assisted us in identifying the root cause of the problem, highlighting
its potential as a valuable developer assistant. Rust. We selected the
Rust repositories from the same set that Zhang et al. \[48\] used to
evaluate their Rust-focused inconsistency detector. RustQuant is an
open-source library for quantitative finance and financial modeling.
Cascade discovered an inconsistency in the set_value function
illustrated in Figure 5, which updates an internal quote value and
returns a double precision floating point number. While the
documentation does suggest that a value is being set, it omits that the
function returns the difference between the old and new values instead
of the new value itself, which is usually expected for setters. To
detect the inconsistency, Cascade generated multiple tests that were
expecting the return value to match the input value. This is a notable
case, because our approach revealed an omitted aspect of correct
behavior, leading to a meaningful documentation improvement rather than
identifying a blatantly incorrect claim.

1 /// Set the quote value . 2 pub fn set_value (& mut self , value :
Option \< f64 \>) -\> f64 { 3 let diff = match (& self . value , & value
) { 4 ( Some ( old_value ) , Some ( new_value ) ) = \> new_value -
old_value , 5 \_ =\> 0.0 , 6 }; 7 if diff != 0.0 { self . value = value
; } 8 diff 9 }

Fig. 5. Rust example: The return statement in line 8 causes the
unexpected behavior. The documentation does not state that the
difference to the old value is returned.

11 jellyfin/jellyfin, bchavez/Bogus, icsharpcode/SharpZipLib,
Humanizr/Humanizer, dotnet/aspnetcore, FluentValidation/Flu-

entValidation, LuckyPennySoftware/AutoMapper, JoshClose/CsvHelper,
BrighterCommand/Brighter, adamralph/bullseye, Tyrrrz/CliWrap,
sipsorcery-org/sipsorcery, thecodrr/BreadPlayer

                                      Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:20 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert
Ziegler, and Lars Grunske

Answering RQ3: Cascade is able to find 13 real-world inconsistencies in
10 different projects and across 3 programming languages (Java, C#,
Rust).

6.4 Threats to Validity Internal Validity. One threat to internal
validity comes from the hand-curated benchmark: the functions, commits,
and documentation snippets were selected by the authors and could embed
unconscious bias. To counter this, we followed an established taxonomy
of inconsistency types \[45\] and thoroughly disclosed our selection
process and protocol in Section 4). For RQ1, our re-implementation and
training of DocChecker and C4RLLaMA might under- perform if our
reproduction were flawed. We mitigated this risk by following their
exact training pipeline and evaluating on the dataset reported in their
papers, with acceptable performance. Further, we adjusted the data so
that DocChecker can actually extract and use the correct documentation
for java code in two different ways; all to give it a better chance at
succeeding. External Validity. A threat to external validity stems from
the choice of target projects used in both the dataset and the
real-world evaluations. These projects may not be representative of
broader software development contexts. To mitigate this risk, we
selected mature libraries that have undergone extensive development and
if possible were used in the evaluation by other related approaches
before us \[2, 48\]. This choice was made for both the dataset and the
real-world experiments to enhance generalizability. A related concern is
that, by construction, the benchmark contains only cases where the docu-
mentation is wrong; in the wild, the fault could also lie in the code.
Our real world experiments uncovered several of these instances where
the code contained the mistake. Showing that Cascade's test-generation
strategy can detect both faulty documentation and buggy code. Construct
Validity. Cascade is purposely optimized for high precision and
specificity in order to minimize the burden for developers from too many
false positives. A direct consequence of that is a lower recall ceiling.
Although this trade-off causes inconsistencies to be missed, it
accurately reflects the practical threshold at which developers are
willing to act on tool output. Section 6.2 (RQ2) shows that the
precision-recall trade-off can be shifted, for example by disabling
Phase 2, giving users control over this balance.

7 Conclusion In this work, we presented Cascade, a novel tool for
detecting semantic inconsistencies between source code and its
natural-language documentation. By leveraging Large Language Models to
generate both unit tests and alternative implementations from
documentation, Cascade employs a dual check validation strategy to
substantially reduce false positives; a persistent limitation in prior
tools. We compared Cascade with LLM baselines (gpt-4.1-mini) and
state-of-the-art tools \[8, 33\] on a dataset with real-world
inconsistencies. In this evaluation, Cascade achieves the highest
precision (0.88) and specificity (0.97). Our evaluation across multiple
languages (Java, C#, Rust) further underscores Cascade's adapt- ability
and applicability to modern, heterogeneous codebases. Notably, Cascade
surfaced 13 pre- viously undocumented inconsistencies in widely used
open-source projects, of which 10 were subsequently acknowledged by
maintainers and fixed. This real-world impact highlights Cascade's
potential, not only as a research tool, but also as a practical
assistant in software maintenance.

Data Availability The data and code of Cascade is availabe here:
https://doi.org/10.5281/zenodo.19483108

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:21

References \[1\] Saranya Alagarsamy, Chakkrit Tantithamthavorn, Wannita
Takerngsaksiri, Chetan Arora, and Aldeida Aleti. 2025. Enhancing large
language models for text-to-testcase generation. J. Syst. Softw. 230
(2025), 112531. doi:10.1016/J.JSS. 2025.112531 \[2\] Arianna Blasi,
Alberto Goffi, Konstantin Kuznetsov, Alessandra Gorla, Michael D. Ernst,
Mauro Pezzè, and Sergio Del- gado Castellanos. 2018. Translating code
comments to procedure specifications. In Proceedings of the 27th ACM
SIGSOFT International Symposium on Software Testing and Analysis, ISSTA
2018, Amsterdam, The Netherlands, July 16-21, 2018, Frank Tip and Eric
Bodden (Eds.). ACM, 242--253. doi:10.1145/3213846.3213872 \[3\]
Ravishankar Boddu, Lan Guo, Supratik Mukhopadhyay, and Bojan Cukic.
2004. RETNA: From Requirements to Testing in a Natural Way. In 12th IEEE
International Conference on Requirements Engineering (RE 2004), 6-10
September 2004, Kyoto, Japan. IEEE Computer Society, 262--271.
doi:10.1109/RE.2004.46 \[4\] Gustavo Carvalho, Diogo Falcão, Flávia de
Almeida Barros, Augusto Sampaio, Alexandre Mota, Leonardo Motta, and
Mark R. Blackburn. 2014. NAT2TESTSCR : Test case generation from natural
language requirements based on SCR specifications. Sci. Comput. Program.
95 (2014), 275--297. doi:10.1016/J.SCICO.2014.06.007 \[5\] Bei Chen,
Fengji Zhang, Anh Nguyen, Daoguang Zan, Zeqi Lin, Jian-Guang Lou, and
Weizhu Chen. 2023. CodeT: Code Generation with Generated Tests. In The
Eleventh International Conference on Learning Representations, ICLR
2023, Kigali, Rwanda, May 1-5, 2023. OpenReview.net.
https://openreview.net/forum?id=ktrw68Cmu9c \[6\] Rudrajit Choudhuri,
Bianca Trinkenreich, Rahul Pandita, Eirini Kalliamvakou, Igor
Steinmacher, Marco Aurélio Gerosa, Christopher Sanchez, and Anita Sarma.
2025. What Guides Our Choices? Modeling Developers' Trust and Behavioral
Intentions Towards Genai. In 47th IEEE/ACM International Conference on
Software Engineering, ICSE 2025, Ottawa, ON, Canada, April 26 - May 6,
2025. IEEE, 1691--1703. doi:10.1109/ICSE55347.2025.00087 \[7\] Roland
Croft, Dominic Newlands, Ziyu Chen, and Muhammad Ali Babar. 2021. An
Empirical Study of Rule-Based and Learning-Based Approaches for Static
Application Security Testing. In ESEM '21: ACM / IEEE International
Symposium on Empirical Software Engineering and Measurement, Bari,
Italy, October 11-15, 2021, Filippo Lanubile, Marcos Kalinowski, and
Maria Teresa Baldassarre (Eds.). ACM, 8:1--8:12.
doi:10.1145/3475716.3475781 \[8\] Anh T. V. Dau, Nghi D. Q. Bui, and Jin
L. C. Guo. 2023. Bootstrapping Code-Text Pretrained Language Model to
Detect Inconsistency Between Code and Comment. CoRR abs/2306.06347
(2023). arXiv:2306.06347 doi:10.48550/ARXIV.2306. 06347 \[9\] Sergio
Cozzetti B. de Souza, Nicolas Anquetil, and Káthia Marçal de Oliveira.
2005. A study of the documentation essential to software maintenance. In
Proceedings of the 23rd Annual International Conference on Design of
Communica- tion: documenting & Designing for Pervasive Information,
SIGDOC 2005, Coventry, UK, September 21-23, 2005, Scott R. Tilley and
Robert M. Newman (Eds.). ACM, 68--75. doi:10.1145/1085313.1085331 \[10\]
Jannik Fischbach, Julian Frattini, Andreas Vogelsang, Daniel Méndez,
Michael Unterkalmsteiner, Andreas Wehrle, Pablo Restrepo Henao, Parisa
Yousefi, Tedi Juricic, Jeannette Radduenz, and Carsten Wiecher. 2023.
Automatic creation of acceptance tests by extracting conditionals from
requirements: NLP approach and case study. J. Syst. Softw. 197 (2023),
111549. doi:10.1016/J.JSS.2022.111549 \[11\] Gordon Fraser and Andrea
Arcuri. 2011. EvoSuite: automatic test suite generation for
object-oriented software. In SIGSOFT/FSE'11 19th ACM SIGSOFT Symposium
on the Foundations of Software Engineering (FSE-19) and ESEC'11: 13th
European Software Engineering Conference (ESEC-13), Szeged, Hungary,
September 5-9, 2011, Tibor Gyimóthy and Andreas Zeller (Eds.). ACM,
416--419. doi:10.1145/2025113.2025179 \[12\] Zhipeng Gao, Xin Xia, David
Lo, John C. Grundy, and Thomas Zimmermann. 2021. Automating the removal
of obsolete TODO comments. In ESEC/FSE '21: 29th ACM Joint European
Software Engineering Conference and Symposium on the Foundations of
Software Engineering, Athens, Greece, August 23-28, 2021, Diomidis
Spinellis, Georgios Gousios, Marsha Chechik, and Massimiliano Di Penta
(Eds.). ACM, 218--229. doi:10.1145/3468264.3468553 \[13\] Lei Huang,
Weijiang Yu, Weitao Ma, Weihong Zhong, Zhangyin Feng, Haotian Wang,
Qianglong Chen, Weihua Peng, Xiaocheng Feng, Bing Qin, and Ting Liu.
2025. A Survey on Hallucination in Large Language Models: Principles,
Taxonomy, Challenges, and Open Questions. ACM Trans. Inf. Syst. 43, 2
(2025), 42:1--42:55. doi:10.1145/3703155 \[14\] Carlos E. Jimenez, John
Yang, Alexander Wettig, Shunyu Yao, Kexin Pei, Ofir Press, and Karthik
R. Narasimhan. 2024. SWE-bench: Can Language Models Resolve Real-world
Github Issues?. In The Twelfth International Conference on Learning
Representations, ICLR 2024, Vienna, Austria, May 7-11, 2024.
OpenReview.net. https://openreview.net/forum? id=VTF8yNQM66 \[15\] René
Just, Darioush Jalali, and Michael D. Ernst. 2014. Defects4J: a database
of existing faults to enable controlled testing studies for Java
programs. In International Symposium on Software Testing and Analysis,
ISSTA '14, San Jose, CA, USA - July 21 - 26, 2014, Corina S. Pasareanu
and Darko Marinov (Eds.). ACM, 437--440. doi:10.1145/2610384.2628055
\[16\] Sungmin Kang, Louis Milliken, and Shin Yoo. 2024. Identifying
Inaccurate Descriptions in LLM-generated Code Comments via Test
Execution. CoRR abs/2406.14836 (2024). arXiv:2406.14836
doi:10.48550/ARXIV.2406.14836

                                       Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.

FSE168:22 Tobias Kiecker, Jan Arne Sparka, Martin Reuter, Albert
Ziegler, and Lars Grunske

\[17\] Anant Kharkar, Roshanak Zilouchian Moghaddam, Matthew Jin, Xiaoyu
Liu, Xin Shi, Colin B. Clement, and Neel Sundaresan. 2022. Learning to
Reduce False Positives in Analytic Bug Detectors. In 44th IEEE/ACM 44th
International Conference on Software Engineering, ICSE 2022, Pittsburgh,
PA, USA, May 25-27, 2022. ACM, 1307--1316. doi:10.1145/ 3510003.3510153
\[18\] Rohan Krishnamurthy, Thomas S. Heinze, Carina Haupt, Andreas
Schreiber, and Michael Meinel. 2019. Scientific developers v/s static
analysis tools: vision and position paper. In Proceedings of the 12th
International Workshop on Cooperative and Human Aspects of Software
Engineering, CHASE@ICSE 2019, Montréal, QC, Canada, 27 May 2019, Yvonne
Dittrich, Fabian Fagerholm, Rashina Hoda, David Socha, and Igor
Steinmacher (Eds.). IEEE / ACM, 89--90. doi:10.1109/CHASE.2019.00029
\[19\] Hyeonseok Lee, Gabin An, and Shin Yoo. 2025. Metamon: Finding
Inconsistencies between Program Documentation and Behavior using
Metamorphic LLM Queries. In IEEE/ACM International Workshop on Large
Language Models for Code, LLM4Code@ICSE 2025, Ottawa, ON, Canada, May 3,
2025. IEEE, 120--127. doi:10.1109/LLM4CODE66737.2025.00020 \[20\] Jörg
Lenhard, Martin Blom, and Sebastian Herold. 2019. Exploring the
suitability of source code metrics for indicating architectural
inconsistencies. Softw. Qual. J. 27, 1 (2019), 241--274.
doi:10.1007/S11219-018-9404-Z \[21\] Zhongxin Liu, Xin Xia, David Lo,
Meng Yan, and Shanping Li. 2023. Just-In-Time Obsolete Comment Detection
and Update. IEEE Trans. Software Eng. 49, 1 (2023), 1--23.
doi:10.1109/TSE.2021.3138909 \[22\] Zhongxin Liu, Xin Xia, Meng Yan, and
Shanping Li. 2020. Automating Just-In-Time Comment Updating. In 35th
IEEE/ACM International Conference on Automated Software Engineering, ASE
2020, Melbourne, Australia, September 21-25, 2020. IEEE, 585--597.
doi:10.1145/3324884.3416581 \[23\] David Lo. 2023. Trustworthy and
Synergistic Artificial Intelligence for Software Engineering: Vision and
Roadmaps. In IEEE/ACM International Conference on Software Engineering:
Future of Software Engineering, ICSE-FoSE 2023, Melbourne, Australia,
May 14-20, 2023. IEEE, 69--85. doi:10.1109/ICSE-FOSE59343.2023.00010
\[24\] Tatwadarshi P. Nagarhalli, Vinod Vaze, and N. K. Rana. 2021.
Impact of Machine Learning in Natural Language Processing: A Review. In
2021 Third International Conference on Intelligent Communication
Technologies and Virtual Mobile Networks (ICICV). 1529--1534.
doi:10.1109/ICICV50876.2021.9388380 \[25\] Ansong Ni, Srini Iyer,
Dragomir Radev, Veselin Stoyanov, Wen-Tau Yih, Sida I. Wang, and Xi
Victoria Lin. 2023. LEVER: Learning to Verify Language-to-Code
Generation with Execution. In International Conference on Machine
Learning, ICML 2023, 23-29 July 2023, Honolulu, Hawaii, USA (Proceedings
of Machine Learning Research), Andreas Krause, Emma Brunskill, Kyunghyun
Cho, Barbara Engelhardt, Sivan Sabato, and Jonathan Scarlett (Eds.).
PMLR, 26106--26128. https://proceedings.mlr.press/v202/ni23b.html \[26\]
Wanrong Ouyang and Baojian Hua. 2021. 'R: Towards Detecting and
Understanding Code-Document Violations in Rust. In IEEE International
Symposium on Software Reliability Engineering, ISSRE 2021 - Workshops,
Wuhan, China, October 25-28, 2021. IEEE, 189--197.
doi:10.1109/ISSREW53611.2021.00063 \[27\] Carlos Pacheco and Michael D.
Ernst. 2007. Randoop: feedback-directed random testing for Java. In
Companion to the 22nd Annual ACM SIGPLAN Conference on Object-Oriented
Programming, Systems, Languages, and Applications, OOPSLA 2007, October
21-25, 2007, Montreal, Quebec, Canada, Richard P. Gabriel, David F.
Bacon, Cristina Videira Lopes, and Guy L. Steele Jr. (Eds.). ACM,
815--816. doi:10.1145/1297846.1297902 \[28\] Sheena Panthaplackel, Junyi
Jessy Li, Milos Gligoric, and Raymond J. Mooney. 2021. Deep Just-In-Time
Inconsistency Detection Between Comments and Source Code. In
Thirty-Fifth AAAI Conference on Artificial Intelligence, AAAI 2021,
Thirty-Third Conference on Innovative Applications of Artificial
Intelligence, IAAI 2021, The Eleventh Symposium on Educational Advances
in Artificial Intelligence, EAAI 2021, Virtual Event, February 2-9,
2021. AAAI Press, 427--435. doi:10.1609/AAAI.V35I1.16119 \[29\] Sheena
Panthaplackel, Pengyu Nie, Milos Gligoric, Junyi Jessy Li, and Raymond
J. Mooney. 2020. Learning to Update Natural Language Comments Based on
Code Changes. In Proceedings of the 58th Annual Meeting of the
Association for Computational Linguistics, ACL 2020, Online, July 5-10,
2020, Dan Jurafsky, Joyce Chai, Natalie Schluter, and Joel R. Tetreault
(Eds.). Association for Computational Linguistics, 1853--1868.
doi:10.18653/V1/2020.ACL-MAIN.168 \[30\] Pooja Rani, Arianna Blasi,
Nataliia Stulova, Sebastiano Panichella, Alessandra Gorla, and Oscar
Nierstrasz. 2023. A decade of code comment quality assessment: A
systematic literature review. J. Syst. Softw. 195 (2023), 111515.
doi:10.1016/J.JSS.2022.111515 \[31\] Inderjot Kaur Ratol and Martin P.
Robillard. 2017. Detecting fragile comments. In Proceedings of the 32nd
IEEE/ACM International Conference on Automated Software Engineering, ASE
2017, Urbana, IL, USA, October 30 - November 03, 2017, Grigore Rosu,
Massimiliano Di Penta, and Tien N. Nguyen (Eds.). IEEE Computer Society,
112--122. doi:10.1109/ASE. 2017.8115624 \[32\] Steven P. Reiss. 2006.
Incremental Maintenance of Software Artifacts. IEEE Trans. Software Eng.
32, 9 (2006), 682--697. doi:10.1109/TSE.2006.91 \[33\] Guoping Rong,
Yongda Yu, Song Liu, Xin Tan, Tianyi Zhang, Haifeng Shen, and Jidong Hu.
2025. Code Comment Inconsistency Detection and Rectification Using a
Large Language Model. In 47th IEEE/ACM International Conference

Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication
date: July 2026. Cascade : Detecting Inconsistencies between Code and
Documentation with Automatic Test Generation FSE168:23

     on Software Engineering, ICSE 2025, Ottawa, ON, Canada, April 26 - May 6, 2025. IEEE, 1832–1843. doi:10.1109/ICSE55347.
     2025.00035

\[34\] Max Schäfer, Sarah Nadi, Aryaz Eghbali, and Frank Tip. 2024. An
Empirical Evaluation of Using Large Language Models for Automated Unit
Test Generation. IEEE Trans. Software Eng. 50, 1 (2024), 85--105.
doi:10.1109/TSE.2023.3334955 \[35\] Haihao Shen, Jianhong Fang, and
Jianjun Zhao. 2011. EFindBugs: Effective Error Ranking for FindBugs. In
Fourth IEEE International Conference on Software Testing, Verification
and Validation, ICST 2011, Berlin, Germany, March 21-25, 2011. IEEE
Computer Society, 299--308. doi:10.1109/ICST.2011.51 \[36\] Devika
Sondhi and Rahul Purandare. 2019. SEGATE: Unveiling Semantic
Inconsistencies between Code and Specifica- tion of String Inputs. In
34th IEEE/ACM International Conference on Automated Software
Engineering, ASE 2019, San Diego, CA, USA, November 11-15, 2019. IEEE,
200--212. doi:10.1109/ASE.2019.00028 \[37\] Nataliia Stulova, Arianna
Blasi, Alessandra Gorla, and Oscar Nierstrasz. 2020. Towards Detecting
Inconsistent Comments in Java Source Code Automatically. In 20th IEEE
International Working Conference on Source Code Analysis and
Manipulation, SCAM 2020, Adelaide, Australia, September 28 - October 2,
2020. IEEE, 65--69. doi:10.1109/SCAM51674. 2020.00012 \[38\] Wannita
Takerngsaksiri, Rujikorn Charakorn, Chakkrit Tantithamthavorn, and
Yuan-Fang Li. 2025. Pytester: Deep reinforcement learning for
text-to-testcase generation. J. Syst. Softw. 224 (2025), 112381.
doi:10.1016/J.JSS.2025.112381 \[39\] Lin Tan, Ding Yuan, Gopal Krishna,
and Yuanyuan Zhou. 2007. /*icomment: bugs or bad comments?*/. In
Proceedings of the 21st ACM Symposium on Operating Systems Principles
2007, SOSP 2007, Stevenson, Washington, USA, October 14-17, 2007, Thomas
C. Bressoud and M. Frans Kaashoek (Eds.). ACM, 145--158.
doi:10.1145/1294261.1294276 \[40\] Shin Hwei Tan, Darko Marinov, Lin
Tan, and Gary T. Leavens. 2012. @tComment: Testing Javadoc Comments to
Detect Comment-Code Inconsistencies. In Fifth IEEE International
Conference on Software Testing, Verification and Validation, ICST 2012,
Montreal, QC, Canada, April 17-21, 2012, Giuliano Antoniol, Antonia
Bertolino, and Yvan Labiche (Eds.). IEEE Computer Society, 260--269.
doi:10.1109/ICST.2012.106 \[41\] Runchu Tian, Yining Ye, Yujia Qin, Xin
Cong, Yankai Lin, Yinxu Pan, Yesai Wu, Haotian Hui, Weichuan Liu,
Zhiyuan Liu, and Maosong Sun. 2024. DebugBench: Evaluating Debugging
Capability of Large Language Models. In Findings of the Association for
Computational Linguistics, ACL 2024, Bangkok, Thailand and virtual
meeting, August 11-16, 2024 (Findings of ACL), Lun-Wei Ku, Andre
Martins, and Vivek Srikumar (Eds.). Association for Computational
Linguistics, 4173--4198. doi:10.18653/V1/2024.FINDINGS-ACL.247 \[42\]
Kristín Fjóla Tómasdóttir, Mauricio Finavaro Aniche, and Arie van
Deursen. 2020. The Adoption of JavaScript Linters in Practice: A Case
Study on ESLint. IEEE Trans. Software Eng. 46, 8 (2020), 863--891.
doi:10.1109/TSE.2018.2871058 \[43\] Gias Uddin and Martin P. Robillard.
2015. How API Documentation Fails. IEEE Softw. 32, 4 (2015), 68--75.
doi:10.1109/ MS.2014.80 \[44\] Yue Wang, Weishi Wang, Shafiq R. Joty,
and Steven C. H. Hoi. 2021. CodeT5: Identifier-aware Unified Pre-trained
Encoder-Decoder Models for Code Understanding and Generation. In
Proceedings of the 2021 Conference on Em- pirical Methods in Natural
Language Processing, EMNLP 2021, Virtual Event / Punta Cana, Dominican
Republic, 7-11 November, 2021, Marie-Francine Moens, Xuanjing Huang,
Lucia Specia, and Scott Wen-tau Yih (Eds.). Association for
Computational Linguistics, 8696--8708.
doi:10.18653/V1/2021.EMNLP-MAIN.685 \[45\] Fengcai Wen, Csaba Nagy,
Gabriele Bavota, and Michele Lanza. 2019. A large-scale empirical study
on code-comment inconsistencies. In Proceedings of the 27th
International Conference on Program Comprehension, ICPC 2019, Montreal,
QC, Canada, May 25-31, 2019, Yann-Gaël Guéhéneuc, Foutse Khomh, and
Federica Sarro (Eds.). IEEE / ACM, 53--64. doi:10.1109/ICPC.2019.00019
\[46\] Xin Xia, Lingfeng Bao, David Lo, Zhenchang Xing, Ahmed E. Hassan,
and Shanping Li. 2018. Measuring program comprehension: a large-scale
field study with professionals. (2018), 584. doi:10.1145/3180155.3182538
\[47\] Wentao Ye, Mingfeng Ou, Tianyi Li, Yipeng Chen, Xuetao Ma, Yifan
Yanggong, Sai Wu, Jie Fu, Gang Chen, Haobo Wang, and Junbo Zhao. 2023.
Assessing Hidden Risks of LLMs: An Empirical Study on Robustness,
Consistency, and Credibility. CoRR abs/2305.10235 (2023).
arXiv:2305.10235 doi:10.48550/ARXIV.2305.10235 \[48\] Yichi Zhang, Zixi
Liu, Yang Feng, and Baowen Xu. 2024. Leveraging Large Language Model to
Assist Detecting Rust Code Comment Inconsistency. In Proceedings of the
39th IEEE/ACM International Conference on Automated Software
Engineering, ASE 2024, Sacramento, CA, USA, October 27 - November 1,
2024, Vladimir Filkov, Baishakhi Ray, and Minghui Zhou (Eds.). ACM,
356--366. doi:10.1145/3691620.3695010 \[49\] Hao Zhong, Lu Zhang, Tao
Xie, and Hong Mei. 2009. Inferring Resource Specifications from Natural
Language API Documentation. In ASE 2009, 24th IEEE/ACM International
Conference on Automated Software Engineering, Auckland, New Zealand,
November 16-20, 2009. IEEE Computer Society, 307--318.
doi:10.1109/ASE.2009.94 \[50\] Yuxiang Zhu and Minxue Pan. 2019.
Automatic Code Summarization: A Systematic Literature Review. CoRR
abs/1909.04352 (2019). arXiv:1909.04352 http://arxiv.org/abs/1909.04352

Received 2026-02-25; accepted 2026-03-24

                                       Proc. ACM Softw. Eng., Vol. 3, No. FSE, Article FSE168. Publication date: July 2026.


